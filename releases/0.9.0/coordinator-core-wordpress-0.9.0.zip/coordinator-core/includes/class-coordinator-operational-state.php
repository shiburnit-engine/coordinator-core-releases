<?php
/**
 * Project-neutral operational-state storage and validation.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Operational_State {
	public const OPTION = 'coordinator_core_status_v1';

	private const STATUSES = array( 'working', 'waiting', 'needs_you', 'failed', 'completed' );

	public static function boot(): void {
		add_action( 'admin_post_coordinator_save_operational_state', array( self::class, 'handle_admin_save' ) );
	}

	public static function get(): ?array {
		$stored = get_option( self::OPTION, null );
		$source = apply_filters( 'coordinator_core_continue_work_summary', $stored );
		$source = apply_filters( 'coordinator_core_operational_state', $source );

		return self::normalize( $source );
	}

	public static function normalize( $record ): ?array {
		if ( ! is_array( $record ) || 1 !== ( $record['schema_version'] ?? null ) ) {
			return null;
		}

		$project_key = self::text( $record['project_key'] ?? '' );
		$project_name = self::text( $record['project_name'] ?? '' );
		$status = self::text( $record['status'] ?? 'waiting' );
		$progress = $record['progress']['percent_complete'] ?? null;
		$next_action = self::text( $record['exact_next_action'] ?? '' );
		$continue = $record['continue_work'] ?? array();

		if ( '' === $project_key || '' === $next_action || ! in_array( $status, self::STATUSES, true ) || ! is_numeric( $progress ) || (float) $progress < 0 || (float) $progress > 100 || ! is_array( $continue ) ) {
			return null;
		}

		$enabled = true === ( $continue['enabled'] ?? false );
		$url = is_string( $continue['url'] ?? null ) ? trim( $continue['url'] ) : '';
		if ( $enabled && false === filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return null;
		}

		return array(
			'schema_version' => 1,
			'project_key' => $project_key,
			'project_name' => '' !== $project_name ? $project_name : $project_key,
			'status' => $status,
			'phase' => self::text( $record['phase'] ?? '' ),
			'stage' => self::text( $record['stage'] ?? '' ),
			'progress' => array( 'percent_complete' => (float) $progress ),
			'current_work' => self::text( $record['current_work'] ?? '' ),
			'blockers' => self::text_list( $record['blockers'] ?? array() ),
			'exact_next_action' => $next_action,
			'updated_at' => self::text( $record['updated_at'] ?? '' ),
			'continue_work' => array(
				'enabled' => $enabled,
				'url' => $enabled ? $url : '',
				'label' => '' !== self::text( $continue['label'] ?? '' ) ? self::text( $continue['label'] ) : 'Continue Work',
				'reason' => self::text( $continue['reason'] ?? '' ),
			),
		);
	}

	public static function from_admin_input( array $input ): ?array {
		$blockers = preg_split( '/\r\n|\r|\n/', (string) ( $input['blockers'] ?? '' ) );
		$raw_continue_url = trim( (string) ( $input['continue_url'] ?? '' ) );
		$continue_url = esc_url_raw( $raw_continue_url );
		if ( '' !== $raw_continue_url && '' === $continue_url ) {
			return null;
		}
		$record = array(
			'schema_version' => 1,
			'project_key' => sanitize_key( (string) ( $input['project_key'] ?? '' ) ),
			'project_name' => sanitize_text_field( (string) ( $input['project_name'] ?? '' ) ),
			'status' => sanitize_key( (string) ( $input['status'] ?? 'waiting' ) ),
			'phase' => sanitize_text_field( (string) ( $input['phase'] ?? '' ) ),
			'stage' => sanitize_text_field( (string) ( $input['stage'] ?? '' ) ),
			'progress' => array( 'percent_complete' => (float) ( $input['percent_complete'] ?? -1 ) ),
			'current_work' => sanitize_textarea_field( (string) ( $input['current_work'] ?? '' ) ),
			'blockers' => is_array( $blockers ) ? array_map( 'sanitize_text_field', $blockers ) : array(),
			'exact_next_action' => sanitize_textarea_field( (string) ( $input['exact_next_action'] ?? '' ) ),
			'updated_at' => gmdate( 'c' ),
			'continue_work' => array(
				'enabled' => '' !== $continue_url,
				'url' => $continue_url,
				'label' => sanitize_text_field( (string) ( $input['continue_label'] ?? 'Continue Work' ) ),
				'reason' => sanitize_text_field( (string) ( $input['continue_reason'] ?? '' ) ),
			),
		);

		return self::normalize( $record );
	}

	public static function handle_admin_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to update Coordinator.', 'coordinator-core' ) );
		}
		check_admin_referer( 'coordinator_save_operational_state' );
		$record = self::from_admin_input( wp_unslash( $_POST ) );
		if ( null === $record ) {
			wp_safe_redirect( add_query_arg( 'coordinator_error', 'invalid_state', admin_url( 'admin.php?page=coordinator-core' ) ) );
			exit;
		}
		update_option( self::OPTION, $record, false );
		wp_safe_redirect( add_query_arg( 'coordinator_updated', '1', admin_url( 'admin.php?page=coordinator-core' ) ) );
		exit;
	}

	private static function text( $value ): string {
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function text_list( $values ): array {
		if ( ! is_array( $values ) ) {
			return array();
		}
		return array_values( array_filter( array_map( array( self::class, 'text' ), $values ), static fn( string $value ): bool => '' !== $value ) );
	}
}
