<?php
/**
 * Authentication boundary for the read-only WordPress Connector.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Authentication {
	public const READ_SCOPE = 'coordinator:read';

	public static function can_read() {
		if ( ! self::is_secure_request() ) {
			return false;
		}

		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return Coordinator_OAuth_Foundation::authenticate_bearer_token();
	}

	public static function is_secure_request(): bool {
		return is_ssl();
	}

	public static function handshake_response() {
		$user         = wp_get_current_user();
		$token_record = Coordinator_OAuth_Foundation::authenticate_bearer_token();
		$actor_id     = current_user_can( 'manage_options' ) ? (int) $user->ID : ( is_array( $token_record ) ? (int) $token_record['user_id'] : 0 );

		return rest_ensure_response(
			array(
				'service'                    => 'coordinator-core-connector',
				'version'                    => COORDINATOR_CORE_VERSION,
				'connected'                  => true,
				'authenticated'              => true,
				'authorization_boundary'     => current_user_can( 'manage_options' ) ? 'wordpress-native' : 'oauth-2.1-bearer',
				'accepted_methods'           => array( 'cookie-session', 'application-password', 'oauth-2.1-bearer' ),
				'required_capability'         => 'manage_options',
				'granted_scopes'              => array( self::READ_SCOPE ),
				'transport_security'          => 'https-required',
				'actor'                       => array(
					'id' => $actor_id,
				),
				'mcp_authorization_target'    => 'oauth-2.1-authorization-code-pkce-s256',
				'mcp_oauth_ready'             => true,
				'writes_enabled'              => false,
			)
		);
	}
}
