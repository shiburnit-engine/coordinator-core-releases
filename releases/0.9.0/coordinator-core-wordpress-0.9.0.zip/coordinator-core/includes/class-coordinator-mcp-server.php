<?php
/**
 * Stateless, read-only MCP Streamable HTTP server.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_MCP_Server {
	private const REST_NAMESPACE  = 'coordinator-core/v1';
	private const LATEST_PROTOCOL = '2025-11-25';
	private const PROTOCOLS       = array( '2025-11-25', '2025-06-18', '2025-03-26' );

	public static function register_rest_route(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/mcp',
			array(
				'methods'             => array( WP_REST_Server::READABLE, WP_REST_Server::CREATABLE ),
				'callback'            => array( self::class, 'handle_request' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public static function handle_request( WP_REST_Request $request ) {
		if ( ! Coordinator_Authentication::is_secure_request() ) {
			return self::http_error( 403, 'HTTPS is required.' );
		}

		if ( ! self::origin_is_allowed( (string) $request->get_header( 'origin' ) ) ) {
			return self::http_error( 403, 'The request Origin is not allowed.' );
		}

		if ( 'GET' === strtoupper( $request->get_method() ) ) {
			return self::http_error( 405, 'Server-sent event streams are not supported by this stateless endpoint.', array( 'Allow' => 'POST' ) );
		}

		if ( ! self::accepts_mcp_response( (string) $request->get_header( 'accept' ) ) ) {
			return self::http_error( 406, 'Accept must include application/json and text/event-stream.' );
		}

		$message = $request->get_json_params();
		if ( ! is_array( $message ) || array_is_list( $message ) || '2.0' !== ( $message['jsonrpc'] ?? null ) || ! is_string( $message['method'] ?? null ) ) {
			return self::jsonrpc_error( $message['id'] ?? null, -32600, 'Invalid Request', 400 );
		}

		$method = $message['method'];
		if ( 'initialize' !== $method && ! str_starts_with( $method, 'notifications/' ) ) {
			$protocol = trim( (string) $request->get_header( 'mcp-protocol-version' ) );
			$protocol = '' === $protocol ? '2025-03-26' : $protocol;
			if ( ! in_array( $protocol, self::PROTOCOLS, true ) ) {
				return self::jsonrpc_error( $message['id'] ?? null, -32600, 'Unsupported MCP-Protocol-Version.', 400 );
			}
		}

		$authorization = Coordinator_Authentication::can_read();
		if ( true !== $authorization && ! is_array( $authorization ) ) {
			return self::authorization_required( $message['id'] ?? null );
		}

		if ( str_starts_with( $method, 'notifications/' ) ) {
			return new WP_REST_Response( null, 202 );
		}

		switch ( $method ) {
			case 'initialize':
				return self::jsonrpc_result( $message['id'] ?? null, self::initialize_result( $message['params'] ?? array() ) );
			case 'ping':
				return self::jsonrpc_result( $message['id'] ?? null, (object) array() );
			case 'tools/list':
				return self::jsonrpc_result( $message['id'] ?? null, array( 'tools' => self::tool_definitions() ) );
			case 'tools/call':
				return self::call_tool( $message['id'] ?? null, $message['params'] ?? null, $authorization );
			default:
				return self::jsonrpc_error( $message['id'] ?? null, -32601, 'Method not found', 404 );
		}
	}

	private static function initialize_result( $params ): array {
		$requested = is_array( $params ) && is_string( $params['protocolVersion'] ?? null ) ? $params['protocolVersion'] : '';
		$protocol  = in_array( $requested, self::PROTOCOLS, true ) ? $requested : self::LATEST_PROTOCOL;

		return array(
			'protocolVersion' => $protocol,
			'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
			'serverInfo'      => array( 'name' => 'Coordinator Core', 'version' => COORDINATOR_CORE_VERSION ),
			'instructions'    => 'Read-only coordination tools. All write actions are disabled.',
		);
	}

	private static function tool_definitions(): array {
		$input       = array( 'type' => 'object', 'properties' => (object) array(), 'additionalProperties' => false );
		$annotations = array( 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false );
		$security    = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE ) ) );

		return array(
			array(
				'name' => 'get_profile', 'title' => 'Get authenticated profile',
				'description' => 'Returns the stable, privacy-preserving identity of the authenticated Coordinator administrator.',
				'inputSchema' => $input,
				'outputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'string' ), 'name' => array( 'type' => 'string' ) ), 'required' => array( 'id' ), 'additionalProperties' => false ),
				'annotations' => $annotations, 'securitySchemes' => $security, '_meta' => array( 'openai/profile' => true ),
			),
			array(
				'name' => 'get_coordinator_status', 'title' => 'Get Coordinator status',
				'description' => 'Returns the current Coordinator Core health and read-only connection status.',
				'inputSchema' => $input, 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'get_site_inventory', 'title' => 'Get WordPress site inventory',
				'description' => 'Returns WordPress, PHP, theme, and plugin inventory without changing the site.',
				'inputSchema' => $input, 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'get_continue_work', 'title' => 'Get Continue Work status',
				'description' => 'Returns the validated Continue Work summary or a safe waiting state.',
				'inputSchema' => $input, 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
		);
	}

	private static function call_tool( $id, $params, $authorization ) {
		if ( ! is_array( $params ) || ! is_string( $params['name'] ?? null ) || ( isset( $params['arguments'] ) && ( ! is_array( $params['arguments'] ) || array() !== $params['arguments'] ) ) ) {
			return self::jsonrpc_error( $id, -32602, 'Invalid tool arguments.', 400 );
		}

		switch ( $params['name'] ) {
			case 'get_profile':
				$data = self::profile_data( $authorization );
				break;
			case 'get_coordinator_status':
				$data = self::response_data( Coordinator_Core::health_response() );
				break;
			case 'get_site_inventory':
				$data = self::response_data( Coordinator_Connector::site_inventory_response() );
				break;
			case 'get_continue_work':
				$data = self::response_data( Coordinator_Core::continue_work_response() );
				break;
			default:
				return self::jsonrpc_error( $id, -32602, 'Unknown tool.', 400 );
		}

		return self::jsonrpc_result(
			$id,
			array(
				'structuredContent' => $data,
				'content'           => array( array( 'type' => 'text', 'text' => wp_json_encode( $data, JSON_UNESCAPED_SLASHES ) ) ),
				'isError'           => false,
			)
		);
	}

	private static function profile_data( $authorization ): array {
		$user_id = current_user_can( 'manage_options' ) ? (int) wp_get_current_user()->ID : (int) ( $authorization['user_id'] ?? 0 );
		$user    = get_userdata( $user_id );
		$data    = array( 'id' => 'prf_' . substr( hash_hmac( 'sha256', site_url( '/' ) . '|' . $user_id, wp_salt( 'auth' ) ), 0, 32 ) );

		if ( $user && is_string( $user->display_name ?? null ) && '' !== trim( $user->display_name ) ) {
			$data['name'] = sanitize_text_field( $user->display_name );
		}

		return $data;
	}

	private static function response_data( $response ): array {
		$data = $response instanceof WP_REST_Response ? $response->get_data() : $response;
		return is_array( $data ) ? $data : array();
	}

	private static function origin_is_allowed( string $origin ): bool {
		if ( '' === trim( $origin ) ) {
			return true;
		}

		$allowed = array( self::origin_from_url( site_url( '/' ) ), 'https://chatgpt.com' );
		return in_array( self::origin_from_url( $origin ), $allowed, true );
	}

	private static function origin_from_url( string $url ): string {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}
		return strtolower( $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' ) );
	}

	private static function accepts_mcp_response( string $accept ): bool {
		$accept = strtolower( $accept );
		return str_contains( $accept, 'application/json' ) && str_contains( $accept, 'text/event-stream' );
	}

	private static function authorization_required( $id ) {
		$challenge = 'Bearer resource_metadata="' . self::resource_metadata_url() . '", error="invalid_token", error_description="A valid coordinator:read access token is required"';
		$result    = array(
			'content' => array( array( 'type' => 'text', 'text' => 'Authorization is required.' ) ),
			'isError' => true,
			'_meta'   => array( 'mcp/www_authenticate' => array( $challenge ) ),
		);
		$response = self::jsonrpc_result( $id, $result, 401 );
		$response->header( 'WWW-Authenticate', $challenge );
		return $response;
	}

	private static function resource_metadata_url(): string {
		return site_url( '/.well-known/oauth-protected-resource' . wp_parse_url( rest_url( self::REST_NAMESPACE . '/mcp' ), PHP_URL_PATH ) );
	}

	private static function jsonrpc_result( $id, $result, int $status = 200 ): WP_REST_Response {
		return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => $id, 'result' => $result ), $status );
	}

	private static function jsonrpc_error( $id, int $code, string $message, int $status ): WP_REST_Response {
		return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => $code, 'message' => $message ) ), $status );
	}

	private static function http_error( int $status, string $message, array $headers = array() ): WP_REST_Response {
		$response = new WP_REST_Response( array( 'error' => $message ), $status );
		foreach ( $headers as $name => $value ) {
			$response->header( $name, $value );
		}
		return $response;
	}
}
