<?php
/**
 * Plugin Name:       Coordinator Core
 * Description:       Project-neutral coordination, recovery, and Continue Work tools.
 * Version:           0.9.0
 * Requires at least: 6.6
 * Requires PHP:      8.1
 * Author:            Coordinator Core
 * License:           GPL-2.0-or-later
 * Text Domain:       coordinator-core
 * Update URI:        false
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'COORDINATOR_CORE_VERSION', '0.9.0' );
define( 'COORDINATOR_CORE_FILE', __FILE__ );
define( 'COORDINATOR_CORE_DIR', plugin_dir_path( __FILE__ ) );

require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-operational-state.php';
require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-updater.php';
require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-core.php';
require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-authentication.php';
require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-oauth-foundation.php';
require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-mcp-server.php';
require_once COORDINATOR_CORE_DIR . 'includes/class-coordinator-connector.php';

Coordinator_Core::boot();
Coordinator_Connector::boot();
