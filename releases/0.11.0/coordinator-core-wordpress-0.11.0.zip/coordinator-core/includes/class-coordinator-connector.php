<?php
/**
 * Read-only WordPress Connector foundation.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Connector {
	private const REST_NAMESPACE = 'coordinator-core/v1';

	public static function boot(): void {
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
		add_action( 'rest_api_init', array( Coordinator_OAuth_Foundation::class, 'register_rest_routes' ) );
		add_action( 'rest_api_init', array( Coordinator_MCP_Server::class, 'register_rest_route' ) );
	}

	public static function register_rest_routes(): void {
		$read_only_routes = array(
			'/connector/capabilities'  => 'capabilities_response',
			'/connector/site-inventory' => 'site_inventory_response',
			'/connector/handshake'     => 'handshake_response',
		);

		foreach ( $read_only_routes as $route => $callback ) {
			register_rest_route(
				self::REST_NAMESPACE,
				$route,
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( self::class, $callback ),
					'permission_callback' => array( self::class, 'can_read_connector' ),
				)
			);
		}
	}

	public static function can_read_connector() {
		return Coordinator_Authentication::can_read();
	}

	public static function handshake_response() {
		return Coordinator_Authentication::handshake_response();
	}

	public static function capabilities_response() {
		return rest_ensure_response(
			array(
				'service'                  => 'coordinator-core-connector',
				'version'                  => COORDINATOR_CORE_VERSION,
				'mode'                     => 'mcp-streamable-http-scoped',
				'authentication'           => 'wordpress-native-or-oauth-2.1-bearer',
				'read_scope'               => Coordinator_Authentication::READ_SCOPE,
				'operational_state_write_scope' => Coordinator_Authentication::WRITE_OPERATIONAL_STATE_SCOPE,
				'mcp_authorization_target' => 'oauth-2.1-authorization-code-pkce-s256',
				'mcp_oauth_discovery'      => true,
				'mcp_oauth_ready'          => true,
				'mcp_endpoint_ready'       => true,
				'permission'               => 'administrator',
				'reads'                    => array(
					'connector-capabilities',
					'site-inventory',
					'continue-work-status',
					'connection-handshake',
					'mcp-tools-list',
					'mcp-tools-call',
				),
				'writes_enabled'           => false,
				'scoped_writes'            => array( 'operational-state' ),
			)
		);
	}

	public static function site_inventory_response() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = array();
		foreach ( get_plugins() as $plugin_file => $plugin_data ) {
			$plugins[] = array(
				'name'    => sanitize_text_field( (string) ( $plugin_data['Name'] ?? $plugin_file ) ),
				'version' => sanitize_text_field( (string) ( $plugin_data['Version'] ?? '' ) ),
				'status'  => is_plugin_active( $plugin_file ) ? 'active' : 'inactive',
			);
		}

		usort(
			$plugins,
			static fn( array $left, array $right ): int => strcasecmp( $left['name'], $right['name'] )
		);

		$theme = wp_get_theme();

		return rest_ensure_response(
			array(
				'service'          => 'coordinator-core-connector',
				'connector_mode'   => 'mcp-streamable-http-scoped',
				'wordpress'        => (string) get_bloginfo( 'version' ),
				'php'              => PHP_VERSION,
				'site_url'         => site_url( '/' ),
				'active_theme'     => array(
					'name'    => sanitize_text_field( (string) $theme->get( 'Name' ) ),
					'version' => sanitize_text_field( (string) $theme->get( 'Version' ) ),
				),
				'plugins'          => $plugins,
				'writes_enabled'   => false,
				'generated_at_utc' => gmdate( 'c' ),
			)
		);
	}
}
