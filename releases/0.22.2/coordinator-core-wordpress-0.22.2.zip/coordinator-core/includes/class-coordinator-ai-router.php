<?php
/**
 * Protected connection from Coordinator Core to the bounded AI router.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_AI_Router {
	public const OPTION = 'coordinator_core_ai_router_v1';

	private const TASK_TYPES = array( 'summarize', 'classify', 'draft', 'review' );
	private const MODELS     = array( 'gpt-5.6-luna', 'gpt-5.6-terra' );

	public static function boot(): void {
		add_action( 'admin_post_coordinator_save_ai_router', array( self::class, 'handle_admin_save' ) );
		add_action( 'admin_post_coordinator_preview_ai_job', array( self::class, 'handle_admin_preview_job' ) );
		add_action( 'admin_post_coordinator_run_ai_job', array( self::class, 'handle_admin_run_job' ) );
	}

	public static function status(): array {
		$config = self::stored_configuration();

		return array(
			'configured'       => '' !== ( $config['endpoint'] ?? '' ) && '' !== ( $config['token_ciphertext'] ?? '' ),
			'endpoint'         => (string) ( $config['endpoint'] ?? '' ),
			'token_configured' => '' !== ( $config['token_ciphertext'] ?? '' ),
			'allowed_tasks'    => self::TASK_TYPES,
			'allowed_models'   => self::MODELS,
			'advisory_only'    => true,
		);
	}

	public static function save_configuration( string $endpoint, string $token = '' ) {
		$endpoint = self::normalize_endpoint( $endpoint );
		if ( '' === $endpoint ) {
			return new WP_Error( 'invalid_router_endpoint', 'The AI router endpoint must be a valid HTTPS URL.' );
		}

		$config = self::stored_configuration();
		if ( '' !== $token ) {
			if ( ! preg_match( '/^[A-Za-z0-9_-]{43,128}$/', $token ) ) {
				return new WP_Error( 'invalid_router_token', 'The AI router token must be a 43 to 128 character URL-safe secret.' );
			}
			$encrypted = self::encrypt_token( $token );
			if ( is_wp_error( $encrypted ) ) {
				return $encrypted;
			}
			$config['token_nonce']      = $encrypted['nonce'];
			$config['token_ciphertext'] = $encrypted['ciphertext'];
		}

		if ( '' === ( $config['token_ciphertext'] ?? '' ) ) {
			return new WP_Error( 'missing_router_token', 'Generate and save an AI router access token.' );
		}

		$config['schema_version'] = 1;
		$config['endpoint']       = $endpoint;
		$config['updated_at']     = gmdate( 'c' );
		update_option( self::OPTION, $config, false );

		return self::status();
	}

	public static function preview_job( array $job ) {
		return self::request( '/v1/jobs/preview', $job, false );
	}

	public static function run_job( array $job ) {
		return self::request( '/v1/jobs/run', $job, true );
	}

	public static function preview_github_delivery( array $delivery ) {
		return self::request_github_delivery( '/v1/github/preview', $delivery, false, true );
	}

	public static function dispatch_github_delivery( array $delivery ) {
		return self::request_github_delivery( '/v1/github/dispatch', $delivery, true, true );
	}

	public static function github_delivery_status( string $job_id ) {
		return self::request_github_delivery(
			'/v1/github/status',
			array( 'job_id' => $job_id ),
			false,
			false
		);
	}

	public static function merge_github_delivery( string $job_id, bool $confirmed = false ) {
		return self::request_github_delivery(
			'/v1/github/merge',
			array(
				'job_id'    => $job_id,
				'confirmed' => $confirmed,
			),
			true,
			false
		);
	}

	public static function release_github_delivery( string $job_id, bool $confirmed = false ) {
		return self::request_github_delivery(
			'/v1/github/release',
			array(
				'job_id'    => $job_id,
				'confirmed' => $confirmed,
			),
			true,
			false
		);
	}

	public static function github_release_status( string $job_id ) {
		return self::request_github_delivery(
			'/v1/github/release/status',
			array( 'job_id' => $job_id ),
			false,
			false
		);
	}

	public static function handle_admin_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_save_ai_router' );

		$endpoint = esc_url_raw( wp_unslash( $_POST['coordinator_ai_router_endpoint'] ?? '' ) );
		$token    = sanitize_text_field( wp_unslash( $_POST['coordinator_ai_router_token'] ?? '' ) );
		$saved    = self::save_configuration( $endpoint, $token );
		if ( is_wp_error( $saved ) ) {
			wp_die( esc_html( $saved->get_error_message() ), '', array( 'response' => 400 ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'                       => 'coordinator-core',
					'coordinator_router_updated' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	public static function handle_admin_preview_job(): void {
		self::require_admin( 'coordinator_preview_ai_job' );
		$job    = self::job_from_admin_post();
		$result = self::preview_job( $job );
		self::store_console_state( $job, $result, 'preview' );
		self::redirect_to_console();
	}

	public static function handle_admin_run_job(): void {
		self::require_admin( 'coordinator_run_ai_job' );
		$state = get_transient( self::console_transient_key() );
		if ( ! is_array( $state ) || 'preview' !== ( $state['stage'] ?? '' ) || ! empty( $state['error'] ) || ! is_array( $state['result'] ?? null ) || ! is_array( $state['job'] ?? null ) || '1' !== sanitize_text_field( wp_unslash( $_POST['coordinator_ai_confirmed'] ?? '' ) ) ) {
			wp_die( esc_html__( 'Preview the job and explicitly confirm the paid run first.', 'coordinator-core' ), '', array( 'response' => 400 ) );
		}

		$job              = $state['job'];
		$job['confirmed'] = true;
		$result           = self::run_job( $job );
		self::store_console_state( $state['job'], $result, 'run' );
		self::redirect_to_console();
	}

	public static function render_admin_section(): void {
		$status  = self::status();
		$updated = '1' === sanitize_text_field( wp_unslash( $_GET['coordinator_router_updated'] ?? '' ) );
		?>
		<hr>
		<h2><?php echo esc_html__( 'Bounded AI Router', 'coordinator-core' ); ?></h2>
		<p><?php echo esc_html__( 'Delegates only summarize, classify, draft, and review jobs. The remote router enforces model allowlists, per-job and monthly budgets, confirmation, idempotency, and advisory-only output.', 'coordinator-core' ); ?></p>
		<?php if ( $updated ) : ?>
			<div class="notice notice-success inline"><p><?php echo esc_html__( 'AI router connection saved.', 'coordinator-core' ); ?></p></div>
		<?php endif; ?>
		<p><strong><?php echo esc_html__( 'Connection:', 'coordinator-core' ); ?></strong> <?php echo esc_html( $status['configured'] ? __( 'Configured', 'coordinator-core' ) : __( 'Not configured', 'coordinator-core' ) ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="coordinator_save_ai_router">
			<?php wp_nonce_field( 'coordinator_save_ai_router' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="coordinator_ai_router_endpoint"><?php echo esc_html__( 'Router endpoint', 'coordinator-core' ); ?></label></th>
					<td><input class="large-text" id="coordinator_ai_router_endpoint" name="coordinator_ai_router_endpoint" type="url" required placeholder="https://router.example.workers.dev" value="<?php echo esc_attr( (string) $status['endpoint'] ); ?>"></td>
				</tr>
				<tr>
					<th><label for="coordinator_ai_router_token"><?php echo esc_html__( 'Router access token', 'coordinator-core' ); ?></label></th>
					<td>
						<input class="large-text code" id="coordinator_ai_router_token" name="coordinator_ai_router_token" type="password" autocomplete="new-password" minlength="43" maxlength="128" placeholder="<?php echo esc_attr( $status['token_configured'] ? __( 'Leave blank to keep the saved token', 'coordinator-core' ) : __( 'Generate a new token', 'coordinator-core' ) ); ?>">
						<p>
							<button class="button" id="coordinator_generate_router_token" type="button"><?php echo esc_html__( 'Generate secure token', 'coordinator-core' ); ?></button>
							<button class="button" id="coordinator_copy_router_token" type="button"><?php echo esc_html__( 'Copy generated token', 'coordinator-core' ); ?></button>
						</p>
						<p class="description"><?php echo esc_html__( 'Copy a newly generated token before saving, then add the same value to Cloudflare as ROUTER_ACCESS_TOKEN. Saved tokens are encrypted and never displayed again.', 'coordinator-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button( esc_html__( 'Save AI Router Connection', 'coordinator-core' ) ); ?>
		</form>
		<script>
		(function () {
			const field = document.getElementById('coordinator_ai_router_token');
			const generate = document.getElementById('coordinator_generate_router_token');
			const copy = document.getElementById('coordinator_copy_router_token');
			if (!field || !generate || !copy || !window.crypto) {
				return;
			}
			generate.addEventListener('click', function () {
				const bytes = new Uint8Array(32);
				window.crypto.getRandomValues(bytes);
				let binary = '';
				bytes.forEach(function (value) { binary += String.fromCharCode(value); });
				field.value = window.btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
				field.type = 'text';
			});
			copy.addEventListener('click', function () {
				if (field.value && navigator.clipboard) {
					navigator.clipboard.writeText(field.value);
				}
			});
		}());
		</script>
		<?php
		self::render_job_console( $status );
	}

	private static function render_job_console( array $status ): void {
		$user  = wp_get_current_user();
		$state = get_transient( self::console_transient_key() );
		$job   = is_array( $state ) && is_array( $state['job'] ?? null ) ? $state['job'] : array(
			'task_type'        => 'draft',
			'model'            => 'gpt-5.6-luna',
			'instructions'     => '',
			'input'            => '',
			'max_output_tokens'=> 512,
			'idempotency_key'  => 'wp-console-' . (int) $user->ID . '-' . gmdate( 'YmdHis' ),
		);
		?>
		<hr>
		<h2><?php echo esc_html__( 'AI Job Console', 'coordinator-core' ); ?></h2>
		<p><?php echo esc_html__( 'Run a bounded advisory AI job directly from WordPress, including when ChatGPT is unavailable. Previewing is free; every paid run still requires an explicit confirmation.', 'coordinator-core' ); ?></p>
		<?php if ( ! $status['configured'] ) : ?>
			<div class="notice notice-warning inline"><p><?php echo esc_html__( 'Save the AI router connection before using the console.', 'coordinator-core' ); ?></p></div>
			<?php return; ?>
		<?php endif; ?>
		<?php if ( is_array( $state ) && '' !== (string) ( $state['error'] ?? '' ) ) : ?>
			<div class="notice notice-error inline"><p><?php echo esc_html( (string) $state['error'] ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="coordinator_preview_ai_job">
			<?php wp_nonce_field( 'coordinator_preview_ai_job' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th><label for="coordinator_ai_task_type"><?php echo esc_html__( 'Task', 'coordinator-core' ); ?></label></th>
					<td><select id="coordinator_ai_task_type" name="coordinator_ai_task_type">
						<?php foreach ( self::TASK_TYPES as $task_type ) : ?>
							<option value="<?php echo esc_attr( $task_type ); ?>" <?php selected( $job['task_type'], $task_type ); ?>><?php echo esc_html( ucfirst( $task_type ) ); ?></option>
						<?php endforeach; ?>
					</select></td>
				</tr>
				<tr>
					<th><label for="coordinator_ai_model"><?php echo esc_html__( 'Model', 'coordinator-core' ); ?></label></th>
					<td><select id="coordinator_ai_model" name="coordinator_ai_model">
						<?php foreach ( self::MODELS as $model ) : ?>
							<option value="<?php echo esc_attr( $model ); ?>" <?php selected( $job['model'], $model ); ?>><?php echo esc_html( $model ); ?></option>
						<?php endforeach; ?>
					</select></td>
				</tr>
				<tr>
					<th><label for="coordinator_ai_instructions"><?php echo esc_html__( 'Instructions', 'coordinator-core' ); ?></label></th>
					<td><textarea class="large-text" rows="4" maxlength="4000" required id="coordinator_ai_instructions" name="coordinator_ai_instructions"><?php echo esc_textarea( (string) $job['instructions'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="coordinator_ai_input"><?php echo esc_html__( 'Input', 'coordinator-core' ); ?></label></th>
					<td><textarea class="large-text code" rows="10" maxlength="50000" required id="coordinator_ai_input" name="coordinator_ai_input"><?php echo esc_textarea( (string) $job['input'] ); ?></textarea></td>
				</tr>
				<tr>
					<th><label for="coordinator_ai_max_output_tokens"><?php echo esc_html__( 'Maximum output tokens', 'coordinator-core' ); ?></label></th>
					<td><input id="coordinator_ai_max_output_tokens" name="coordinator_ai_max_output_tokens" type="number" min="64" max="4000" required value="<?php echo esc_attr( (string) $job['max_output_tokens'] ); ?>"></td>
				</tr>
				<tr>
					<th><label for="coordinator_ai_idempotency_key"><?php echo esc_html__( 'Job key', 'coordinator-core' ); ?></label></th>
					<td><input class="regular-text code" id="coordinator_ai_idempotency_key" name="coordinator_ai_idempotency_key" type="text" minlength="16" maxlength="128" pattern="[A-Za-z0-9._:-]{16,128}" required value="<?php echo esc_attr( (string) $job['idempotency_key'] ); ?>"><p class="description"><?php echo esc_html__( 'Keep this key unchanged when safely retrying the same job.', 'coordinator-core' ); ?></p></td>
				</tr>
			</table>
			<?php submit_button( esc_html__( 'Preview Cost and Routing', 'coordinator-core' ) ); ?>
		</form>
		<?php if ( is_array( $state ) && 'preview' === ( $state['stage'] ?? '' ) && empty( $state['error'] ) && is_array( $state['result'] ?? null ) ) : ?>
			<h3><?php echo esc_html__( 'Preview', 'coordinator-core' ); ?></h3>
			<pre style="max-width:100%;overflow:auto;white-space:pre-wrap"><?php echo esc_html( wp_json_encode( $state['result'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></pre>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="coordinator_run_ai_job">
				<?php wp_nonce_field( 'coordinator_run_ai_job' ); ?>
				<label><input type="checkbox" name="coordinator_ai_confirmed" value="1" required> <?php echo esc_html__( 'I confirm this paid advisory AI run.', 'coordinator-core' ); ?></label>
				<?php submit_button( esc_html__( 'Run Confirmed AI Job', 'coordinator-core' ) ); ?>
			</form>
		<?php elseif ( is_array( $state ) && 'run' === ( $state['stage'] ?? '' ) && empty( $state['error'] ) && is_array( $state['result'] ?? null ) ) : ?>
			<h3><?php echo esc_html__( 'AI Result', 'coordinator-core' ); ?></h3>
			<pre style="max-width:100%;overflow:auto;white-space:pre-wrap"><?php echo esc_html( wp_json_encode( $state['result'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></pre>
		<?php endif; ?>
		<?php
	}

	private static function require_admin( string $nonce_action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	private static function job_from_admin_post(): array {
		return array(
			'task_type'         => sanitize_key( wp_unslash( $_POST['coordinator_ai_task_type'] ?? '' ) ),
			'model'             => sanitize_text_field( wp_unslash( $_POST['coordinator_ai_model'] ?? '' ) ),
			'instructions'      => self::posted_string( 'coordinator_ai_instructions' ),
			'input'             => self::posted_string( 'coordinator_ai_input' ),
			'max_output_tokens' => (int) ( $_POST['coordinator_ai_max_output_tokens'] ?? 0 ),
			'idempotency_key'   => sanitize_text_field( wp_unslash( $_POST['coordinator_ai_idempotency_key'] ?? '' ) ),
		);
	}

	private static function posted_string( string $key ): string {
		$value = wp_unslash( $_POST[ $key ] ?? '' );
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function console_transient_key(): string {
		$user = wp_get_current_user();
		return 'coordinator_ai_console_' . (int) $user->ID;
	}

	private static function store_console_state( array $job, $result, string $stage ): void {
		$state = array(
			'job'    => $job,
			'stage'  => $stage,
			'result' => is_wp_error( $result ) ? null : $result,
			'error'  => is_wp_error( $result ) ? $result->get_error_message() : '',
		);
		set_transient( self::console_transient_key(), $state, 10 * MINUTE_IN_SECONDS );
	}

	private static function redirect_to_console(): void {
		wp_safe_redirect( add_query_arg( 'page', 'coordinator-core', admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function request_github_delivery( string $path, array $delivery, bool $require_confirmation, bool $require_plan ) {
		$allowed = array( 'job_id', 'goal', 'plan' );
		if ( $require_confirmation ) {
			$allowed[] = 'confirmed';
		}
		if ( array() !== array_diff( array_keys( $delivery ), $allowed ) ) {
			return new WP_Error( 'invalid_github_delivery', 'The GitHub delivery request contains unsupported fields.' );
		}

		$job_id    = sanitize_text_field( (string) ( $delivery['job_id'] ?? '' ) );
		$goal      = trim( (string) ( $delivery['goal'] ?? '' ) );
		$plan      = trim( (string) ( $delivery['plan'] ?? '' ) );
		$confirmed = true === ( $delivery['confirmed'] ?? false );
		if ( ! preg_match( '/^wb_[a-f0-9]{20}$/', $job_id ) ) {
			return new WP_Error( 'invalid_github_delivery', 'The Workbench job ID is invalid.' );
		}
		if ( $require_plan && ( '' === $goal || strlen( $goal ) > 4000 || '' === $plan || strlen( $plan ) > 30000 ) ) {
			return new WP_Error( 'invalid_github_delivery', 'The approved Workbench goal or plan is invalid.' );
		}
		if ( $require_confirmation && ! $confirmed ) {
			return new WP_Error( 'github_confirmation_required', 'Explicit GitHub delivery confirmation is required.' );
		}

		$payload = array( 'job_id' => $job_id );
		if ( $require_plan ) {
			$payload['goal'] = $goal;
			$payload['plan'] = $plan;
		}
		if ( $require_confirmation ) {
			$payload['confirmed'] = true;
		}
		return self::post_json( $path, $payload );
	}

	private static function post_json( string $path, array $payload ) {
		$config = self::stored_configuration();
		$token  = self::decrypt_token( $config );
		if ( '' === ( $config['endpoint'] ?? '' ) || is_wp_error( $token ) || '' === $token ) {
			return new WP_Error( 'router_not_configured', 'The bounded AI router is not configured.' );
		}

		$response = wp_safe_remote_post(
			rtrim( (string) $config['endpoint'], '/' ) . $path,
			array(
				'timeout'     => 60,
				'redirection' => 0,
				'headers'     => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'        => wp_json_encode( $payload, JSON_UNESCAPED_SLASHES ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'router_unavailable', 'The bounded AI router could not be reached.' );
		}
		$status = wp_remote_retrieve_response_code( $response );
		$data   = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'router_invalid_response', 'The bounded AI router returned an invalid response.' );
		}
		if ( $status < 200 || $status >= 300 ) {
			$message = sanitize_text_field( (string) ( $data['error'] ?? 'The bounded AI router rejected the request.' ) );
			return new WP_Error( 'router_rejected', $message, array( 'status' => $status ) );
		}
		return $data;
	}

	private static function request( string $path, array $job, bool $require_confirmation ) {
		$config = self::stored_configuration();
		$token  = self::decrypt_token( $config );
		if ( '' === ( $config['endpoint'] ?? '' ) || is_wp_error( $token ) || '' === $token ) {
			return new WP_Error( 'router_not_configured', 'The bounded AI router is not configured.' );
		}

		$validated = self::normalize_job( $job, $require_confirmation );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}

		$response = wp_safe_remote_post(
			rtrim( (string) $config['endpoint'], '/' ) . $path,
			array(
				'timeout'     => 60,
				'redirection' => 0,
				'headers'     => array(
					'Authorization' => 'Bearer ' . $token,
					'Content-Type'  => 'application/json',
					'Accept'        => 'application/json',
				),
				'body'        => wp_json_encode( $validated, JSON_UNESCAPED_SLASHES ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'router_unavailable', 'The bounded AI router could not be reached.' );
		}

		$status = wp_remote_retrieve_response_code( $response );
		$data   = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'router_invalid_response', 'The bounded AI router returned an invalid response.' );
		}
		if ( $status < 200 || $status >= 300 ) {
			$message = sanitize_text_field( (string) ( $data['error'] ?? 'The bounded AI router rejected the request.' ) );
			return new WP_Error( 'router_rejected', $message, array( 'status' => $status ) );
		}

		return $data;
	}

	private static function normalize_job( array $job, bool $require_confirmation ) {
		$allowed = array( 'task_type', 'instructions', 'input', 'model', 'max_output_tokens', 'idempotency_key' );
		if ( $require_confirmation ) {
			$allowed[] = 'confirmed';
		}
		if ( array() !== array_diff( array_keys( $job ), $allowed ) ) {
			return new WP_Error( 'invalid_router_job', 'The AI job contains unsupported fields.' );
		}

		$task_type      = sanitize_key( (string) ( $job['task_type'] ?? '' ) );
		$instructions   = trim( (string) ( $job['instructions'] ?? '' ) );
		$input          = trim( (string) ( $job['input'] ?? '' ) );
		$model          = sanitize_text_field( (string) ( $job['model'] ?? 'gpt-5.6-luna' ) );
		$max_output     = (int) ( $job['max_output_tokens'] ?? 0 );
		$idempotency    = sanitize_text_field( (string) ( $job['idempotency_key'] ?? '' ) );
		$confirmed      = true === ( $job['confirmed'] ?? false );

		if ( ! in_array( $task_type, self::TASK_TYPES, true ) || ! in_array( $model, self::MODELS, true ) ) {
			return new WP_Error( 'invalid_router_job', 'The AI job task or model is not allowed.' );
		}
		if ( '' === $instructions || strlen( $instructions ) > 4000 || '' === $input || strlen( $input ) > 50000 ) {
			return new WP_Error( 'invalid_router_job', 'The AI job instructions or input are invalid.' );
		}
		if ( $max_output < 64 || $max_output > 4000 || ! preg_match( '/^[A-Za-z0-9._:-]{16,128}$/', $idempotency ) ) {
			return new WP_Error( 'invalid_router_job', 'The AI job output limit or idempotency key is invalid.' );
		}
		if ( $require_confirmation && ! $confirmed ) {
			return new WP_Error( 'router_confirmation_required', 'Explicit confirmation is required before an AI job can run.' );
		}

		$normalized = array(
			'task_type'        => $task_type,
			'instructions'     => $instructions,
			'input'            => $input,
			'model'            => $model,
			'max_output_tokens'=> $max_output,
			'idempotency_key'  => $idempotency,
		);
		if ( $require_confirmation ) {
			$normalized['confirmed'] = true;
		}

		return $normalized;
	}

	private static function normalize_endpoint( string $endpoint ): string {
		$endpoint = untrailingslashit( esc_url_raw( trim( $endpoint ) ) );
		$parts    = wp_parse_url( $endpoint );
		if ( ! is_array( $parts ) || 'https' !== strtolower( (string) ( $parts['scheme'] ?? '' ) ) || empty( $parts['host'] ) || ! empty( $parts['user'] ) || ! empty( $parts['pass'] ) || ! empty( $parts['query'] ) || ! empty( $parts['fragment'] ) ) {
			return '';
		}
		return $endpoint;
	}

	private static function stored_configuration(): array {
		$config = get_option( self::OPTION, array() );
		return is_array( $config ) ? $config : array();
	}

	private static function encrypt_token( string $token ) {
		if ( ! function_exists( 'sodium_crypto_secretbox' ) ) {
			return new WP_Error( 'router_encryption_unavailable', 'Secure token encryption is unavailable on this server.' );
		}
		$nonce      = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$ciphertext = sodium_crypto_secretbox( $token, $nonce, self::encryption_key() );

		return array(
			'nonce'      => base64_encode( $nonce ),
			'ciphertext' => base64_encode( $ciphertext ),
		);
	}

	private static function decrypt_token( array $config ) {
		if ( ! function_exists( 'sodium_crypto_secretbox_open' ) ) {
			return new WP_Error( 'router_encryption_unavailable', 'Secure token encryption is unavailable on this server.' );
		}
		$nonce      = base64_decode( (string) ( $config['token_nonce'] ?? '' ), true );
		$ciphertext = base64_decode( (string) ( $config['token_ciphertext'] ?? '' ), true );
		if ( false === $nonce || false === $ciphertext || SODIUM_CRYPTO_SECRETBOX_NONCEBYTES !== strlen( $nonce ) ) {
			return new WP_Error( 'router_token_invalid', 'The saved AI router token is invalid.' );
		}
		$token = sodium_crypto_secretbox_open( $ciphertext, $nonce, self::encryption_key() );
		return false === $token ? new WP_Error( 'router_token_invalid', 'The saved AI router token could not be decrypted.' ) : $token;
	}

	private static function encryption_key(): string {
		return hash( 'sha256', wp_salt( 'auth' ) . '|' . wp_salt( 'secure_auth' ), true );
	}
}
