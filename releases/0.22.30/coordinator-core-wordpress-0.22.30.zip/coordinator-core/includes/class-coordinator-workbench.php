<?php
/**
 * Persistent administrator Workbench for guided Coordinator jobs.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Workbench {
	public const OPTION = 'coordinator_core_workbench_v1';

	private const HISTORY_LIMIT = 20;
	private const TOTAL_STEPS = 12;
	private const AUTONOMOUS_TICK_HOOK = 'coordinator_workbench_autonomous_tick';
	private const AUTONOMOUS_LOCK = 'coordinator_workbench_autonomous_lock';
	private const AUTONOMOUS_STALE_SECONDS = 180;
	private const EMERGENCY_BRAKE_OPTION = 'coordinator_workbench_emergency_brake_v1';
	private const STAGES = array(
		'planning',
		'awaiting_plan_approval',
		'plan_ready',
		'waiting_for_github',
		'github_preview_ready',
		'github_dispatch_queued',
		'github_pr_open',
		'coding_ready',
		'coding_running',
		'diagnosing',
		'researching',
		'github_ci_passed',
		'awaiting_merge',
		'merged',
		'release_dispatched',
		'release_ready',
		'publication_dispatched',
		'release_published',
		'wordpress_update_ready',
		'verified',
	);

	public static function boot(): void {
		add_action( 'admin_post_coordinator_workbench_action', array( self::class, 'handle_admin_action' ) );
		add_action( self::AUTONOMOUS_TICK_HOOK, array( self::class, 'handle_autonomous_tick' ) );
		add_action( 'init', array( self::class, 'resume_autonomous_job' ) );
	}

	public static function emergency_brake_engaged(): bool {
		$state = get_option( self::EMERGENCY_BRAKE_OPTION, array() );
		return is_array( $state ) && ! empty( $state['engaged'] );
	}

	public static function set_emergency_brake( bool $engaged, int $user_id ): bool {
		if ( ! Coordinator_Budget_Authority::is_initial_admin( $user_id ) ) { return false; }
		$previous = get_option( self::EMERGENCY_BRAKE_OPTION, array() );
		$state = array( 'schema_version' => 1, 'engaged' => $engaged, 'updated_at' => gmdate( 'c' ), 'updated_by' => $user_id, 'previous' => is_array( $previous ) ? $previous : array() );
		update_option( self::EMERGENCY_BRAKE_OPTION, $state, false );
		if ( ! $engaged ) { self::schedule_autonomous_tick( 5 ); }
		return true;
	}

	private static function clear_emergency_job( int $user_id ): bool {
		if ( ! Coordinator_Budget_Authority::is_initial_admin( $user_id ) || ! self::emergency_brake_engaged() ) { return false; }
		$state = self::get_state();
		$job = $state['active_job'];
		if ( is_array( $job ) ) {
			$job['archived_at'] = gmdate( 'c' );
			self::add_event( $job, 'Initial Admin cleared the stopped job after using the emergency brake. The snapshot remains in history for audit and loop diagnosis.' );
			array_unshift( $state['history'], $job );
			$state['history'] = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
		}
		$state['active_job'] = null;
		self::save_state( $state );
		return true;
	}

	public static function resume_autonomous_job(): void {
		if ( self::emergency_brake_engaged() ) { return; }
		$state = self::get_state();
		$job = $state['active_job'];
		if ( is_array( $job ) && self::autonomous_stage( (string) $job['stage'] ) && ! self::research_confirmation_pending( $job ) ) {
			self::schedule_autonomous_tick( 5 );
		}
	}

	private static function research_confirmation_pending( array $job ): bool {
		return 'researching' === self::clean_text( $job['stage'] ?? '' )
			&& 'awaiting_confirmation' === self::clean_text( $job['supervisor_research_status'] ?? '' )
			&& is_array( $job['supervisor_research_preview'] ?? null );
	}

	private static function autonomous_stage( string $stage ): bool {
		return in_array( $stage, array(
			'github_dispatch_queued', 'github_pr_open', 'coding_ready', 'coding_running', 'researching',
			'github_ci_passed', 'awaiting_merge', 'merged', 'release_dispatched',
			'release_ready', 'publication_dispatched', 'release_published', 'wordpress_update_ready'
		), true );
	}

	private static function schedule_autonomous_tick( int $delay = 15 ): void {
		if ( ! function_exists( 'wp_next_scheduled' ) || ! function_exists( 'wp_schedule_single_event' ) ) {
			return;
		}
		if ( false === wp_next_scheduled( self::AUTONOMOUS_TICK_HOOK ) ) {
			wp_schedule_single_event( time() + max( 5, $delay ), self::AUTONOMOUS_TICK_HOOK );
		}
	}

	public static function handle_autonomous_tick(): void {
		if ( self::emergency_brake_engaged() ) { return; }
		if ( get_transient( self::AUTONOMOUS_LOCK ) ) {
			self::schedule_autonomous_tick( 30 );
			return;
		}
		set_transient( self::AUTONOMOUS_LOCK, '1', 120 );
		try {
			$state = self::get_state();
			$job = $state['active_job'];
			if ( ! is_array( $job ) || ! self::autonomous_stage( (string) $job['stage'] ) || self::research_confirmation_pending( $job ) ) {
				return;
			}
			$job['activity_state'] = 'working';
			$job['activity_message'] = self::stage_activity( self::next_action( (string) $job['stage'] ) );
			self::add_event( $job, 'Reading Workbench execution state...' );
			self::add_event( $job, 'Updating autonomous heartbeat...' );
			$job['last_heartbeat_at'] = gmdate( 'c' );
			$job['tick_started_at'] = gmdate( 'c' );
			$job['updated_at'] = gmdate( 'c' );
			$state['active_job'] = $job;
			self::save_state( $state );
			$state = self::get_state();
			$job = $state['active_job'];
			self::add_event( $job, 'Saving current activity state...' );
			$state['active_job'] = $job;
			self::save_state( $state );

			$result = self::run_build_stage( $state, $job );
			if ( is_wp_error( $result ) ) {
				$state = self::get_state();
				$job = $state['active_job'];
				if ( is_array( $job ) ) {
					$job['activity_state'] = 'error';
					$job['activity_message'] = $result->get_error_message();
					$job['last_heartbeat_at'] = gmdate( 'c' );
					$job['updated_at'] = gmdate( 'c' );
					$state['active_job'] = $job;
					self::save_state( $state );
				}
				self::schedule_autonomous_tick( 60 );
				return;
			}
			$state = self::get_state();
			$job = $state['active_job'];
			if ( is_array( $job ) ) {
				$job['last_heartbeat_at'] = gmdate( 'c' );
				$job['updated_at'] = gmdate( 'c' );
				if ( self::autonomous_stage( (string) $job['stage'] ) && ! self::research_confirmation_pending( $job ) ) {
					$job['activity_state'] = 'waiting';
					$job['activity_message'] = self::stage_activity( self::next_action( (string) $job['stage'] ) );
					self::add_event( $job, 'Current operation finished. Checking the next automatic action...' );
					self::schedule_autonomous_tick( 15 );
				} else {
					$job['activity_state'] = 'needs_you';
					$job['activity_message'] = self::research_confirmation_pending( $job )
						? __( 'The bounded research preview is ready. Paid research is waiting for your confirmation and budget controls.', 'coordinator-core' )
						: self::stage_activity( self::next_action( (string) $job['stage'] ) );
				}
				$state['active_job'] = $job;
				self::save_state( $state );
			}
		} finally {
			delete_transient( self::AUTONOMOUS_LOCK );
		}
	}

	public static function status(): array {
		$state = self::get_state();
		$job   = $state['active_job'];

		return array(
			'enabled'            => true,
			'mode'               => 'github-delivery-v1',
			'active_job'         => is_array( $job ),
			'active_job_id'      => is_array( $job ) ? (string) $job['id'] : '',
			'stage'              => is_array( $job ) ? (string) $job['stage'] : 'ready',
			'next_action'        => is_array( $job ) ? self::next_action( (string) $job['stage'] ) : 'start',
			'activity'           => is_array( $job ) ? self::runtime_status( $job ) : array( 'state' => 'ready', 'message' => 'No active job.', 'last_heartbeat_at' => '', 'stalled' => false ),
			'history_count'      => count( $state['history'] ),
			'github_write_mode'  => 'approval-gateway',
			'installation_mode'  => 'signed-updater',
		);
	}

	public static function get_state(): array {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) || 1 !== ( $stored['schema_version'] ?? null ) ) {
			return self::empty_state();
		}

		$active = self::normalize_job( $stored['active_job'] ?? null );
		$history = array();
		foreach ( (array) ( $stored['history'] ?? array() ) as $job ) {
			$normalized = self::normalize_job( $job );
			if ( null !== $normalized ) {
				$history[] = $normalized;
			}
		}

		return array(
			'schema_version' => 1,
			'active_job'     => $active,
			'history'        => array_slice( $history, 0, self::HISTORY_LIMIT ),
			'updated_at'     => self::clean_text( $stored['updated_at'] ?? '' ),
		);
	}

	public static function start_job( string $goal, int $user_id ) {
		$goal = trim( $goal );
		if ( '' === $goal || strlen( $goal ) > 4000 ) {
			return new WP_Error( 'workbench_invalid_goal', 'Enter a build goal of 1 to 4,000 characters.' );
		}
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'workbench_forbidden', 'Administrator permission is required.' );
		}

		$state = self::get_state();
		if ( is_array( $state['active_job'] ) ) {
			return new WP_Error( 'workbench_job_active', 'Finish or archive the active Workbench job first.' );
		}

		$now = gmdate( 'c' );
		$job = array(
			'id'                 => 'wb_' . substr( hash( 'sha256', $goal . '|' . $user_id . '|' . $now . '|' . count( $state['history'] ) ), 0, 20 ),
			'goal'               => $goal,
			'stage'              => 'planning',
			'created_at'         => $now,
			'updated_at'         => $now,
			'actor_id'           => $user_id,
			'provider'           => '',
			'estimated_cost_usd' => null,
			'actual_cost_usd'    => null,
			'plan'               => '',
			'preview'            => null,
			'github_preview'     => null,
			'github_delivery'    => null,
			'coding_execution'   => null,
			'activity_state'     => 'needs_you',
			'activity_message'   => 'Workbench job created and is waiting for the next safe action.',
			'last_heartbeat_at'  => $now,
			'tick_started_at'    => '',
			'last_error'         => '',
			'events'             => array(
				array(
					'at'      => $now,
					'stage'   => 'planning',
					'message' => 'Workbench job created. No paid AI call has run.',
				),
			),
		);

		$state['active_job'] = $job;
		self::save_state( $state );
		return $job;
	}

	public static function advance_job( string $action, bool $confirmed, int $user_id ) {
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'workbench_forbidden', 'Administrator permission is required.' );
		}

		if ( self::emergency_brake_engaged() ) {
			return new WP_Error( 'workbench_emergency_brake', 'Coordinator emergency brake is engaged. The active job is frozen until the Initial Admin releases it.' );
		}

		$state = self::get_state();
		$job   = $state['active_job'];
		if ( ! is_array( $job ) ) {
			return new WP_Error( 'workbench_job_missing', 'There is no active Workbench job.' );
		}

		if ( 'preview_plan' === $action && 'planning' === $job['stage'] ) {
			$request = self::router_job( $job );
			$result  = Coordinator_AI_Router::preview_job( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['preview']            = $result;
			$job['estimated_cost_usd'] = isset( $result['estimated_max_cost_usd'] ) ? (float) $result['estimated_max_cost_usd'] : null;
			$job['stage']              = 'awaiting_plan_approval';
			$job['last_error']         = '';
			self::add_event( $job, 'AI plan cost and routing preview completed. No paid call ran.' );
		} elseif ( 'run_plan' === $action && 'awaiting_plan_approval' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_confirmation_required', 'Confirm the paid advisory planning job first.' );
			}
			$request              = self::router_job( $job );
			$request['confirmed'] = true;
			$result               = Coordinator_AI_Router::run_job( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['plan']            = trim( (string) ( $result['output'] ?? '' ) );
			$job['provider']        = self::clean_text( $result['provider'] ?? '' );
			$job['actual_cost_usd'] = isset( $result['actual_cost_usd'] ) ? (float) $result['actual_cost_usd'] : null;
			$job['stage']           = 'plan_ready';
			$job['last_error']      = '';
			self::add_event( $job, 'Advisory implementation plan generated and saved for review.' );
		} elseif ( 'accept_plan' === $action && 'plan_ready' === $job['stage'] ) {
			$job['stage']      = 'waiting_for_github';
			$job['last_error'] = '';
			self::add_event( $job, 'Plan approved and queued for protected GitHub delivery preview.' );
		} elseif ( 'preview_github' === $action && 'waiting_for_github' === $job['stage'] ) {
			$result = Coordinator_AI_Router::preview_github_delivery( self::github_payload( $job ) );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_preview'] = $result;
			$job['stage']          = 'github_preview_ready';
			$job['last_error']     = '';
			self::add_event( $job, ! empty( $result['actions_enabled'] ) ? 'Protected GitHub delivery preview completed.' : 'GitHub delivery preview completed; gateway activation is still required before dispatch.' );
		} elseif ( 'retry_github_preview' === $action && 'github_preview_ready' === $job['stage'] ) {
			$result = Coordinator_AI_Router::preview_github_delivery( self::github_payload( $job ) );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_preview'] = $result;
			$job['last_error']     = '';
			self::add_event( $job, 'GitHub delivery preview refreshed after configuration change.' );
		} elseif ( 'dispatch_github' === $action && 'github_preview_ready' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_github_confirmation_required', 'Confirm creation of the allowlisted branch and draft pull request first.' );
			}
			$request              = self::github_payload( $job );
			$request['confirmed'] = true;
			$result               = Coordinator_AI_Router::dispatch_github_delivery( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = $result;
			$job['stage']           = 'github_dispatch_queued';
			$job['last_error']      = '';
			self::add_event( $job, 'GitHub delivery was dispatched. Merge and installation remain disabled.' );
		} elseif ( 'research' === $action && 'researching' === $job['stage'] ) {
			if ( self::research_confirmation_pending( $job ) ) {
				if ( ! $confirmed ) {
					return new WP_Error( 'workbench_research_confirmation_required', 'Confirm the bounded paid research job first.' );
				}
				$request = is_array( $job['supervisor_research_job'] ?? null ) ? $job['supervisor_research_job'] : self::prepare_research_job( $job );
				$request['confirmed'] = true;
				$result = Coordinator_AI_Router::run_job( $request );
				if ( is_wp_error( $result ) ) {
					return self::record_error( $state, $job, $result );
				}
				$output = trim( (string) ( $result['output'] ?? '' ) );
				if ( '' === $output ) {
					return self::record_error( $state, $job, new WP_Error( 'workbench_research_empty', 'The bounded research job returned no usable result.' ) );
				}
				$job['supervisor_research_result'] = $result;
				$job['supervisor_research_guidance'] = $output;
				$job['supervisor_research_status'] = 'completed';
				$job['supervisor_research_provider'] = self::clean_text( $result['provider'] ?? '' );
				$job['supervisor_research_cost_usd'] = isset( $result['actual_cost_usd'] ) ? (float) $result['actual_cost_usd'] : null;
				$job['stage'] = 'coding_ready';
				$job['last_error'] = '';
				self::add_event( $job, 'Confirmed bounded research completed and was saved. Coordinator returned to the automatic coding stage with the research guidance preserved.' );
			} else {
				$request = self::prepare_research_job( $job );
				$preview = Coordinator_AI_Router::preview_job( $request );
				if ( is_wp_error( $preview ) ) {
					return self::record_error( $state, $job, $preview );
				}
				$job['supervisor_research_preview'] = $preview;
				$job['supervisor_research_status'] = 'awaiting_confirmation';
				$job['last_error'] = '';
				self::add_event( $job, 'Bounded research request prepared and cost/routing previewed. No paid AI research ran; confirmation and router budget controls remain enforced.' );
			}
		} elseif ( 'run_build_stage' === $action && in_array( $job['stage'], array( 'github_dispatch_queued', 'github_pr_open', 'coding_ready', 'coding_running', 'github_ci_passed', 'awaiting_merge', 'merged', 'release_dispatched', 'release_ready', 'publication_dispatched' ), true ) ) {
			$result = self::run_build_stage( $state, $job );
			if ( is_wp_error( $result ) ) { return $result; }
			$job = $result;
		} elseif ( 'run_coding' === $action && 'coding_ready' === $job['stage'] ) {
			$request = self::github_payload( $job );
			$request['confirmed'] = true;
			$result = Coordinator_AI_Router::run_coding_generation( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['coding_execution'] = $result;
			$job['stage'] = 'coding_running';
			$job['last_error'] = '';
			self::add_event( $job, 'Bounded coding was queued safely in the background. The Workbench can be refreshed without starting a duplicate coding run.' );
		} elseif ( 'refresh_coding' === $action && 'coding_running' === $job['stage'] ) {
			$status = Coordinator_AI_Router::coding_generation_status( (string) $job['id'] );
			if ( is_wp_error( $status ) ) {
				return self::record_error( $state, $job, $status );
			}
			if ( 'completed' !== self::clean_text( $status['status'] ?? '' ) ) {
				$job['coding_execution'] = $status;
				$job['last_error'] = '';
				self::add_event( $job, 'Bounded coding is still running in the background.' );
			} else {
				$result = is_array( $status['result'] ?? null ) ? $status['result'] : array();
				$http_status = (int) ( $status['http_status'] ?? 500 );
				if ( $http_status < 200 || $http_status >= 300 ) {
					$message = self::clean_text( $result['error'] ?? 'The asynchronous coding worker failed safely.' );
					$retry_count = (int) ( $job['coding_retry_count'] ?? 0 );
					if ( $retry_count < 1 ) {
						$request = self::github_payload( $job );
						$request['confirmed'] = true;
						$retry = Coordinator_AI_Router::run_coding_generation( $request );
						if ( ! is_wp_error( $retry ) ) {
							$job['coding_execution'] = $retry;
							$job['coding_retry_count'] = $retry_count + 1;
							$job['last_error'] = '';
							self::add_event( $job, 'Coordinator automatically requeued the failed coding attempt after a recoverable infrastructure failure.' );
							$job['updated_at']   = gmdate( 'c' );
							$state['active_job'] = $job;
							self::save_state( $state );
							return $job;
						}
					}
					return self::record_error( $state, $job, new WP_Error( 'coding_worker_failed', $message ) );
				}
				$job['coding_execution'] = $result;
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'coding_execution' => $result ) );
				$job['last_error'] = '';
				if ( 'coding_changes_ready' === self::clean_text( $result['state'] ?? '' ) && ! empty( $result['validation_required'] ) ) {
					$job['stage'] = 'github_dispatch_queued';
					self::add_event( $job, 'Bounded coding changes were written to the isolated delivery branch. Required checks must now pass on the coding commit.' );
				} else {
					$job['stage'] = 'coding_ready';
					self::add_event( $job, 'Coding stopped safely at its independent generation or branch-write gate.' );
				}
			}
		} elseif ( 'refresh_github' === $action && in_array( $job['stage'], array( 'github_dispatch_queued', 'github_pr_open', 'github_ci_passed' ), true ) ) {
			$result = Coordinator_AI_Router::github_delivery_status( (string) $job['id'] );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$existing_coding = is_array( $job['coding_execution'] ?? null ) ? $job['coding_execution'] : null;
			$job['github_delivery'] = null !== $existing_coding ? array_merge( $result, array( 'coding_execution' => $existing_coding ) ) : $result;
			$delivery_state         = self::clean_text( $result['state'] ?? '' );
			if ( 'ci_passed' === $delivery_state ) {
				$job['stage'] = self::has_coding_evidence( $job ) ? 'github_ci_passed' : 'coding_ready';
			} elseif ( 'pull_request_open' === $delivery_state ) {
				$job['stage'] = self::has_coding_evidence( $job ) ? 'github_pr_open' : 'coding_ready';
			} elseif ( 'branch_created' === $delivery_state ) {
				$job['stage'] = 'github_dispatch_queued';
			} else {
				$job['stage'] = 'github_dispatch_queued';
			}
			$job['last_error'] = '';
			self::add_event( $job, 'GitHub and CI evidence refreshed: ' . ( '' !== $delivery_state ? $delivery_state : 'queued' ) . '.' );
		} elseif ( 'continue_after_ci' === $action && 'github_ci_passed' === $job['stage'] ) {
			if ( ! self::has_coding_evidence( $job ) ) {
				return new WP_Error( 'workbench_coding_evidence_required', 'Bounded coding evidence is required before the protected merge stage.' );
			}
			$job['stage']      = 'awaiting_merge';
			$job['last_error'] = '';
			self::add_event( $job, 'CI evidence accepted. Merge remains a separate protected action.' );
		} elseif ( 'merge_github' === $action && 'awaiting_merge' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_merge_confirmation_required', 'Confirm the exact protected Workbench merge first.' );
			}
			$result = Coordinator_AI_Router::merge_github_delivery( (string) $job['id'], true );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'merge' => $result ) );
			$job['stage']           = 'merged';
			$job['last_error']      = '';
			self::add_event( $job, 'Exact tested Workbench pull request merged through the protected gateway.' );
		} elseif ( 'release_gate' === $action && 'merged' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_release_confirmation_required', 'Confirm the protected signed release first.' );
			}
			$result = Coordinator_AI_Router::release_github_delivery( (string) $job['id'], true );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'release' => $result ) );
			$job['stage']           = 'release_dispatched';
			$job['last_error']      = '';
			self::add_event( $job, 'Protected signed release build dispatched. Publication and WordPress installation remain separate protected actions.' );
		} elseif ( 'refresh_release' === $action && 'release_dispatched' === $job['stage'] ) {
			$result = Coordinator_AI_Router::github_release_status( (string) $job['id'] );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'release_status' => $result ) );
			$release_state          = self::clean_text( $result['state'] ?? '' );
			if ( 'signed_release_ready' === $release_state ) {
				$job['stage'] = 'release_ready';
			}
			$job['last_error'] = '';
			self::add_event( $job, 'Signed release evidence refreshed: ' . ( '' !== $release_state ? $release_state : 'pending' ) . '.' );
		} elseif ( 'publish_release' === $action && 'release_ready' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_publication_confirmation_required', 'Confirm the protected release publication first.' );
			}
			$result = Coordinator_AI_Router::publish_github_delivery( (string) $job['id'], true );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'publication' => $result ) );
			$job['stage']           = 'publication_dispatched';
			$job['last_error']      = '';
			self::add_event( $job, 'Protected signed release publication dispatched. WordPress installation remains disabled.' );
		} elseif ( 'refresh_publication' === $action && 'publication_dispatched' === $job['stage'] ) {
			$result = Coordinator_AI_Router::github_publication_status( (string) $job['id'] );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'publication_status' => $result ) );
			$publication_state      = self::clean_text( $result['state'] ?? '' );
			if ( 'release_published' === $publication_state ) {
				$job['stage'] = 'release_published';
			}
			$job['last_error'] = '';
			self::add_event( $job, 'Release publication evidence refreshed: ' . ( '' !== $publication_state ? $publication_state : 'pending' ) . '.' );
		} elseif ( 'cancel_job' === $action && in_array( $job['stage'], array( 'planning', 'awaiting_plan_approval', 'plan_ready', 'waiting_for_github', 'github_preview_ready' ), true ) ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_cancel_confirmation_required', 'Confirm cancellation of this pre-delivery Workbench job first.' );
			}
			$job['archived_at'] = gmdate( 'c' );
			$job['archive_reason'] = 'cancelled_before_delivery';
			self::add_event( $job, 'Workbench job cancelled and archived before any GitHub delivery, merge, release, publication, or installation action.' );
			array_unshift( $state['history'], $job );
			$state['history'] = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
			$state['active_job'] = null;
			self::save_state( $state );
			return array( 'archived' => true, 'job' => $job );
		} elseif ( 'archive_stale_coding' === $action && 'coding_ready' === $job['stage'] && false !== stripos( (string) $job['last_error'], 'protected base moved' ) ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_stale_archive_confirmation_required', 'Confirm archival of the stale coding job first.' );
			}
			$job['archived_at'] = gmdate( 'c' );
			$job['archive_reason'] = 'stale_protected_base';
			self::add_event( $job, 'Stale coding job archived after the protected base moved. No merge, release, publication, or installation action ran.' );
			array_unshift( $state['history'], $job );
			$state['history'] = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
			$state['active_job'] = null;
			self::save_state( $state );
			return array( 'archived' => true, 'job' => $job );
		} elseif ( 'archive_obsolete' === $action && 'merged' === $job['stage'] && ! self::has_coding_evidence( $job ) ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_obsolete_archive_confirmation_required', 'Confirm archival of the obsolete Workbench job first.' );
			}
			$job['archived_at'] = gmdate( 'c' );
			$job['archive_reason'] = 'obsolete_missing_coding_evidence';
			self::add_event( $job, 'Obsolete planning-only Workbench job archived safely. No release, publication, or installation action ran.' );
			array_unshift( $state['history'], $job );
			$state['history']    = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
			$state['active_job'] = null;
			self::save_state( $state );
			return array( 'archived' => true, 'job' => $job );
		} elseif ( 'archive' === $action && 'verified' === $job['stage'] ) {
			$job['archived_at'] = gmdate( 'c' );
			self::add_event( $job, 'Verified Workbench job archived after live installation evidence.' );
			array_unshift( $state['history'], $job );
			$state['history']    = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
			$state['active_job'] = null;
			self::save_state( $state );
			return array( 'archived' => true, 'job' => $job );
		} else {
			return new WP_Error( 'workbench_invalid_transition', 'That Workbench action is not valid for the current stage.' );
		}

		$job['updated_at']     = gmdate( 'c' );
		$state['active_job']   = $job;
		self::save_state( $state );
		if ( self::autonomous_stage( (string) $job['stage'] ) ) {
			self::schedule_autonomous_tick( 5 );
		}
		return $job;
	}

	private static function run_build_stage( array $state, array $job ) {
		// One user checkpoint may perform the routine workspace-status, coding, and verification handoffs.
		// It stops as soon as an external workflow is still running or an independent gate needs attention.
		for ( $attempt = 0; $attempt < 4; $attempt++ ) {
			if ( 'researching' === $job['stage'] ) {
				$request = self::prepare_research_job( $job );
				$preview = Coordinator_AI_Router::preview_job( $request );
				if ( is_wp_error( $preview ) ) { return self::record_error( $state, $job, $preview ); }
				$job['supervisor_research_preview'] = $preview;
				$job['supervisor_research_status'] = 'awaiting_confirmation';
				$job['last_error'] = '';
				self::add_event( $job, 'Bounded research request prepared and cost/routing previewed automatically. No paid AI research ran; confirmation and router budget controls remain enforced.' );
				break;
			}
			if ( in_array( $job['stage'], array( 'github_dispatch_queued', 'github_pr_open' ), true ) && ! self::has_coding_evidence( $job ) ) {
				$status = Coordinator_AI_Router::github_delivery_status( (string) $job['id'] );
				if ( is_wp_error( $status ) ) { return self::record_error( $state, $job, $status ); }
				$job['github_delivery'] = $status;
				$delivery_state = self::clean_text( $status['state'] ?? '' );
				if ( ! in_array( $delivery_state, array( 'pull_request_open', 'ci_passed' ), true ) ) {
					$job['stage'] = 'github_dispatch_queued';
					self::add_event( $job, 'Protected coding workspace is still being prepared. The build stage will continue from this saved point.' );
					break;
				}
				$job['stage'] = 'coding_ready';
			}
			if ( 'coding_ready' === $job['stage'] ) {
				$request = self::github_payload( $job );
				$request['confirmed'] = true;
				$coding = Coordinator_AI_Router::run_coding_generation( $request );
				if ( is_wp_error( $coding ) ) { return self::record_error( $state, $job, $coding ); }
				$job['coding_execution'] = $coding;
				$job['stage'] = 'coding_running';
				self::add_event( $job, 'Bounded coding was queued safely in the background. Return to this step to check its status.' );
				break;
			}
			if ( 'coding_running' === $job['stage'] ) {
				$status = Coordinator_AI_Router::coding_generation_status( (string) $job['id'] );
				if ( is_wp_error( $status ) ) { return self::record_error( $state, $job, $status ); }
				if ( 'completed' !== self::clean_text( $status['status'] ?? '' ) ) {
					$job['coding_execution'] = $status;
					self::add_event( $job, 'Bounded coding is still running safely in the background.' );
					break;
				}
				$result = is_array( $status['result'] ?? null ) ? $status['result'] : array();
				$http_status = (int) ( $status['http_status'] ?? 500 );
				if ( $http_status < 200 || $http_status >= 300 ) {
					$message = self::clean_text( $result['error'] ?? 'The asynchronous coding worker failed safely.' );
					$delivery = is_array( $job['github_delivery'] ?? null ) ? $job['github_delivery'] : array();
					$job['supervisor_attempts'] = Coordinator_Supervisor::failure_record(
						$job,
						'coding_worker_failed',
						$message,
						array(
							'commit_sha' => self::clean_text( $delivery['commit_sha'] ?? '' ),
							'checkpoint' => 'coding_generation',
							'accepted_changes' => false,
						)
					);
					$job['supervisor_mode'] = Coordinator_Supervisor::failure_mode( $job['supervisor_attempts'] );
					$job['supervisor_memory_matches'] = Coordinator_Knowledge_Search::search_verified( $message, 'coding worker' );
					$decision = Coordinator_Supervisor::apply_diagnosis_decision( $job );
					$job['stage'] = Coordinator_Supervisor::MODE_RESEARCHING === $decision['mode'] ? 'researching' : 'diagnosing';
					$job['last_error'] = $message;
					if ( Coordinator_Supervisor::MODE_REPAIR_AUTHORIZED === $decision['mode'] ) {
						self::add_event( $job, 'Coding failed safely. Coordinator recorded the attempt, found a sufficiently relevant verified lesson, and authorized only that bounded repair path. Automatic repair execution remains stopped until the repair stage runs.' );
					} else {
						self::add_event( $job, 'Coding failed safely. Coordinator recorded the attempt, found no sufficiently relevant verified lesson, and moved to read-only research instead of retrying the same approach.' );
					}
					$job['updated_at'] = gmdate( 'c' );
					$state['active_job'] = $job;
					self::save_state( $state );
					break;
				}
				$job['coding_execution'] = $result;
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'coding_execution' => $result ) );
				if ( 'coding_changes_ready' === self::clean_text( $result['state'] ?? '' ) && ! empty( $result['validation_required'] ) ) {
					$job['stage'] = 'github_dispatch_queued';
					self::add_event( $job, 'Bounded coding finished. Coordinator is continuing into protected validation.' );
					continue;
				}
				$job['stage'] = 'coding_ready';
				self::add_event( $job, 'Coding stopped safely at its independent generation or branch-write gate.' );
				break;
			}
			if ( 'github_ci_passed' === $job['stage'] && self::has_coding_evidence( $job ) ) {
				$job['stage'] = 'awaiting_merge';
				self::add_event( $job, 'Required CI passed. Coordinator advanced automatically to the protected merge boundary.' );
				continue;
			}
			if ( 'awaiting_merge' === $job['stage'] ) {
				$result = Coordinator_AI_Router::merge_github_delivery( (string) $job['id'], true );
				if ( is_wp_error( $result ) ) { return self::record_error( $state, $job, $result ); }
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'merge' => $result ) );
				$job['stage'] = 'merged';
				self::add_event( $job, 'Exact tested Workbench pull request merged automatically through the protected gateway.' );
				continue;
			}
			if ( 'merged' === $job['stage'] ) {
				$result = Coordinator_AI_Router::release_github_delivery( (string) $job['id'], true );
				if ( is_wp_error( $result ) ) { return self::record_error( $state, $job, $result ); }
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'release' => $result ) );
				$job['stage'] = 'release_dispatched';
				self::add_event( $job, 'Protected signed release build dispatched automatically.' );
				break;
			}
			if ( 'release_dispatched' === $job['stage'] ) {
				$result = Coordinator_AI_Router::github_release_status( (string) $job['id'] );
				if ( is_wp_error( $result ) ) { return self::record_error( $state, $job, $result ); }
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'release_status' => $result ) );
				$release_state = self::clean_text( $result['state'] ?? '' );
				if ( 'signed_release_ready' !== $release_state ) {
					self::add_event( $job, 'Protected signed release is still building.' );
					break;
				}
				$job['stage'] = 'release_ready';
				continue;
			}
			if ( 'release_ready' === $job['stage'] ) {
				$result = Coordinator_AI_Router::publish_github_delivery( (string) $job['id'], true );
				if ( is_wp_error( $result ) ) { return self::record_error( $state, $job, $result ); }
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'publication' => $result ) );
				$job['stage'] = 'publication_dispatched';
				self::add_event( $job, 'Protected signed release publication dispatched automatically.' );
				break;
			}
			if ( 'publication_dispatched' === $job['stage'] ) {
				$result = Coordinator_AI_Router::github_publication_status( (string) $job['id'] );
				if ( is_wp_error( $result ) ) { return self::record_error( $state, $job, $result ); }
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'publication_status' => $result ) );
				$publication_state = self::clean_text( $result['state'] ?? '' );
				if ( 'release_published' === $publication_state ) {
					$job['stage'] = 'release_published';
					self::add_event( $job, 'Verified signed release is published. Coordinator is continuing through the signed WordPress updater.' );
				} else {
					self::add_event( $job, 'Protected release publication is still running.' );
				}
				if ( 'release_published' !== $job['stage'] ) { break; }
			}
			if ( 'release_published' === $job['stage'] ) {
				$result = self::install_verified_update();
				if ( is_wp_error( $result ) ) { return self::record_error( $state, $job, $result ); }
				$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'wordpress_update' => $result ) );
				$job['stage'] = 'wordpress_update_ready';
				self::add_event( $job, 'Verified signed WordPress update installed automatically.' );
				continue;
			}
			if ( 'wordpress_update_ready' === $job['stage'] ) {
				$expected = self::clean_text( $job['github_delivery']['publication_status']['version'] ?? $job['github_delivery']['publication']['version'] ?? '' );
				if ( '' !== $expected && version_compare( COORDINATOR_CORE_VERSION, $expected, '<' ) ) {
					return self::record_error( $state, $job, new WP_Error( 'workbench_install_version_mismatch', 'Coordinator Core did not activate the expected published version.' ) );
				}
				$job['stage'] = 'verified';
				self::add_event( $job, 'Live Coordinator Core installation verified. Job is ready to test.' );
				break;
			}
			if ( self::has_coding_evidence( $job ) ) {
				$status = Coordinator_AI_Router::github_delivery_status( (string) $job['id'] );
				if ( is_wp_error( $status ) ) { return self::record_error( $state, $job, $status ); }
				$coding = $job['coding_execution'];
				$job['github_delivery'] = array_merge( $status, array( 'coding_execution' => $coding ) );
				$delivery_state = self::clean_text( $status['state'] ?? '' );
				$job['stage'] = 'ci_passed' === $delivery_state ? 'github_ci_passed' : 'github_pr_open';
				self::add_event( $job, 'Automatic coding verification refreshed: ' . ( '' !== $delivery_state ? $delivery_state : 'pending' ) . '.' );
				break;
			}
		}
		$job['last_error'] = '';
		$job['updated_at'] = gmdate( 'c' );
		$state['active_job'] = $job;
		self::save_state( $state );
		// Re-arm the existing autonomous worker whenever this pass stops in a safe
		// background stage. This makes direct/admin-triggered passes behave like
		// cron-triggered passes instead of requiring another user click.
		if ( self::autonomous_stage( (string) $job['stage'] ) ) {
			self::schedule_autonomous_tick( 15 );
		}
		return $job;
	}

	private static function install_verified_update() {
		$metadata = Coordinator_Updater::get_verified_metadata( true );
		if ( is_wp_error( $metadata ) ) { return $metadata; }
		if ( version_compare( COORDINATOR_CORE_VERSION, (string) $metadata['version'], '>=' ) ) {
			return array( 'version' => COORDINATOR_CORE_VERSION, 'updated' => false );
		}
		if ( ! function_exists( 'wp_update_plugins' ) ) { require_once ABSPATH . 'wp-admin/includes/update.php'; }
		if ( ! class_exists( 'Plugin_Upgrader' ) ) { require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php'; }
		wp_update_plugins();
		$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
		$result = $upgrader->upgrade( 'coordinator-core/coordinator-core.php' );
		if ( is_wp_error( $result ) ) { return $result; }
		if ( true !== $result ) { return new WP_Error( 'workbench_install_failed', 'The verified Coordinator Core update did not install successfully.' ); }
		return array( 'version' => (string) $metadata['version'], 'updated' => true );
	}

	public static function handle_admin_action(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_workbench_action' );

		$user   = wp_get_current_user();
		$action = sanitize_key( wp_unslash( $_POST['workbench_step'] ?? '' ) );
		if ( in_array( $action, array( 'emergency_stop', 'emergency_resume', 'emergency_wipe', 'emergency_wipe_new' ), true ) ) {
			if ( ! Coordinator_Budget_Authority::is_initial_admin( (int) $user->ID ) ) {
				$result = new WP_Error( 'workbench_emergency_owner_required', 'Only the Initial Admin can control the Coordinator emergency brake.' );
			} elseif ( 'emergency_stop' === $action ) {
				$result = self::set_emergency_brake( true, (int) $user->ID );
			} elseif ( 'emergency_resume' === $action ) {
				$result = self::set_emergency_brake( false, (int) $user->ID );
			} else {
				$result = self::clear_emergency_job( (int) $user->ID );
				if ( $result ) { $result = self::set_emergency_brake( false, (int) $user->ID ); }
			}
			if ( false === $result ) { $result = new WP_Error( 'workbench_emergency_action_failed', 'Emergency brake action failed closed.' ); }
		} elseif ( 'start' === $action ) {
			$goal   = self::posted_string( 'workbench_goal' );
			$result = self::start_job( $goal, (int) $user->ID );
		} else {
			$confirmed = '1' === sanitize_text_field( wp_unslash( $_POST['workbench_confirmed'] ?? '' ) );
			$result    = self::advance_job( $action, $confirmed, (int) $user->ID );
		}

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 400 ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=coordinator-core#coordinator-workbench' ) );
		exit;
	}

	public static function render_admin_section( ?array $summary ): void {
		$state         = self::get_state();
		$job           = $state['active_job'];
		$goal          = '';
		$router_status = Coordinator_AI_Router::status();
		?>
		<hr>
		<style>
			#coordinator-workbench { max-width: 1000px; margin: 28px 0; color: #172033; }
			#coordinator-workbench * { box-sizing: border-box; }
			.cc-workbench-hero { padding: 24px; border: 1px solid #c7d2fe; border-radius: 18px; background: linear-gradient(135deg, #eff6ff 0%, #eef2ff 52%, #faf5ff 100%); box-shadow: 0 12px 30px rgba(30, 64, 175, .08); }
			.cc-workbench-hero h2 { margin: 0 0 8px; font-size: clamp(24px, 5vw, 34px); line-height: 1.15; }
			.cc-workbench-hero p { max-width: 720px; margin: 0; color: #475569; font-size: 15px; line-height: 1.6; }
			.cc-step-card { margin-top: 18px; padding: clamp(20px, 4vw, 32px); border: 1px solid #dbe4f0; border-radius: 18px; background: #fff; box-shadow: 0 16px 36px rgba(15, 23, 42, .08); }
			.cc-step-top { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 14px; }
			.cc-step-badge { display: inline-flex; align-items: center; min-height: 30px; padding: 5px 11px; border-radius: 999px; background: #1d4ed8; color: #fff; font-size: 12px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; }
			.cc-step-state { color: #166534; font-size: 13px; font-weight: 700; }
			.cc-progress { height: 18px; margin: 0 0 12px; overflow: hidden; border-radius: 999px; background: #e8eef7; }
			.cc-progress span { display: block; height: 100%; border-radius: inherit; background: linear-gradient(90deg, #2563eb, #7c3aed); transition: width .35s ease; }
			.cc-stage-now { margin: 0 0 22px; padding: 12px 14px; border-left: 4px solid #2563eb; border-radius: 8px; background: #f8fafc; color: #334155; font-size: 15px; line-height: 1.5; }
			.cc-stage-now strong { display:block; color:#0f172a; margin-bottom:3px; }
			.cc-runtime { margin: 0 0 18px; padding: 14px; border: 1px solid #dbe4f0; border-radius: 12px; background: #f8fafc; color: #334155; line-height: 1.5; }
			.cc-runtime strong { color:#0f172a; }
			.cc-runtime-stalled { border-color:#f59e0b; background:#fffbeb; color:#92400e; }
			.cc-live-console-wrap { margin: 0 0 20px; }
			.cc-live-console-title { margin: 0 0 8px; color:#0f172a; font-weight:700; }
			.cc-live-console { height: 13.5em; overflow:hidden; padding:12px 14px; border:1px solid #1e293b; border-radius:10px; background:#0f172a; color:#dbeafe; font:12px/1.5 ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace; white-space:pre-wrap; }
			.cc-live-console-line { display:block; min-height:1.5em; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
			.cc-stage-complete { margin: 18px 0; padding: 16px; border: 1px solid #bbf7d0; border-radius: 12px; background:#f0fdf4; color:#14532d; }
			.cc-stage-actions { display:flex; gap:10px; flex-wrap:wrap; margin-top:14px; }
			.cc-stage-actions .button { min-height:44px; padding:8px 16px; }
			.cc-step-card h3 { margin: 0 0 10px; color: #0f172a; font-size: clamp(21px, 4vw, 28px); line-height: 1.25; }
			.cc-step-card > p { color: #475569; font-size: 15px; line-height: 1.6; }
			.cc-goal-label { display: block; margin: 22px 0 8px; color: #0f172a; font-size: 14px; }
			#coordinator-workbench textarea { width: 100%; min-height: 132px; padding: 14px; border: 1px solid #94a3b8; border-radius: 12px; background: #f8fafc; font-size: 16px; line-height: 1.5; }
			#coordinator-workbench textarea:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, .16); outline: none; }
			#coordinator-workbench .cc-primary.button { width: 100%; min-height: 48px; margin-top: 8px; padding: 10px 18px; border: 0; border-radius: 12px; background: linear-gradient(90deg, #1d4ed8, #6d28d9); color: #fff; font-size: 15px; font-weight: 700; text-shadow: none; box-shadow: 0 8px 18px rgba(37, 99, 235, .22); }
			#coordinator-workbench .cc-primary.button:hover:not(:disabled), #coordinator-workbench .cc-primary.button:focus:not(:disabled) { background: linear-gradient(90deg, #1e40af, #5b21b6); color: #fff; }
			#coordinator-workbench .cc-primary.button:disabled { background: #cbd5e1; color: #64748b; box-shadow: none; cursor: not-allowed; }
			.cc-confirmation { margin: 20px 0 10px; padding: 14px; border: 1px solid #bfdbfe; border-radius: 12px; background: #eff6ff; color: #1e3a8a; line-height: 1.5; }
			.cc-confirmation input { width: 20px; height: 20px; margin-right: 8px; vertical-align: middle; }
			.cc-step-card .notice { margin: 18px 0; border-radius: 10px; }
			.cc-step-card pre { max-height: 430px; padding: 16px !important; border: 1px solid #dbe4f0 !important; border-radius: 12px; background: #f8fafc !important; color: #1e293b; font-size: 13px; line-height: 1.55; }
			.cc-history { margin-top: 16px; border: 1px solid #dbe4f0; border-radius: 14px; background: #fff; }
			.cc-history summary { padding: 16px 18px; cursor: pointer; color: #334155; font-weight: 700; }
			.cc-history[open] summary { border-bottom: 1px solid #e2e8f0; }
			.cc-history-body { padding: 16px 18px; overflow-x: auto; }
			.cc-history ol { margin-left: 20px; }
			.cc-history li { margin-bottom: 10px; line-height: 1.45; }
			.cc-history table { min-width: 680px; border: 0; box-shadow: none; }
			@media (max-width: 600px) {
				.cc-workbench-hero { padding: 20px; border-radius: 14px; }
				.cc-step-card { padding: 20px 16px; border-radius: 14px; }
				.cc-step-top { align-items: flex-start; flex-direction: column; }
				.cc-history-body { padding: 12px; }
			}
		</style>
		<div id="coordinator-workbench">
			<?php $brake = self::emergency_brake_engaged(); $current_user = wp_get_current_user(); $initial_admin = Coordinator_Budget_Authority::is_initial_admin( (int) $current_user->ID ); ?>
			<?php if ( $initial_admin ) : ?>
				<div class="cc-step-card" style="border-color:#dc2626;">
					<h3><?php echo esc_html( $brake ? 'Emergency Stop Engaged' : 'Emergency Stop' ); ?></h3>
					<p><?php echo esc_html( $brake ? 'Automation is frozen. Choose whether to resume the exact saved job, wipe the current job, or wipe it and return to a fresh job form.' : 'Use this only if Coordinator appears stuck in a loop or must be stopped immediately.' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cc-stage-actions">
						<input type="hidden" name="action" value="coordinator_workbench_action"><?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
						<?php if ( $brake ) : ?>
							<button class="button" name="workbench_step" value="emergency_resume" type="submit">Resume Saved Job</button>
							<button class="button" name="workbench_step" value="emergency_wipe" type="submit">Wipe Current Job</button>
							<button class="button button-primary" name="workbench_step" value="emergency_wipe_new" type="submit">Wipe &amp; Start New Job</button>
						<?php else : ?>
							<button class="button" name="workbench_step" value="emergency_stop" type="submit">EMERGENCY STOP</button>
						<?php endif; ?>
					</form>
				</div>
			<?php endif; ?>
			<div class="cc-workbench-hero">
				<h2><?php echo esc_html__( 'Coordinator Workbench', 'coordinator-core' ); ?></h2>
				<p><?php echo esc_html__( 'Give Coordinator a build goal, then follow the current stage here. Routine work stays in the background. The Workbench stops between stages with a plain-English summary and asks for you only when needed. Closing the browser or reaching a ChatGPT limit does not erase the job.', 'coordinator-core' ); ?></p>
			</div>
			<div class="cc-step-card">
				<?php if ( ! is_array( $job ) ) : ?>
					<div class="cc-step-top"><span class="cc-step-badge"><?php echo esc_html__( 'Step 1 of 8', 'coordinator-core' ); ?></span><span class="cc-step-state"><?php echo esc_html__( 'Ready', 'coordinator-core' ); ?></span></div>
					<div class="cc-progress" aria-label="<?php echo esc_attr( __( 'Workbench progress', 'coordinator-core' ) ); ?>"><span style="width:12.5%"></span></div>
					<h3><?php echo esc_html__( 'Choose the next build goal', 'coordinator-core' ); ?></h3>
					<p><?php echo esc_html__( 'Enter a new build goal below. Coordinator status instructions are never copied into this field.', 'coordinator-core' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="coordinator_workbench_action">
						<input type="hidden" name="workbench_step" value="start">
						<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
						<label class="cc-goal-label" for="workbench_goal"><strong><?php echo esc_html__( 'Build goal', 'coordinator-core' ); ?></strong></label>
						<textarea class="large-text" id="workbench_goal" name="workbench_goal" rows="5" maxlength="4000" required><?php echo esc_textarea( $goal ); ?></textarea>
						<p><button class="button button-primary cc-primary" id="coordinator_start_workbench_job" type="submit" disabled><?php echo esc_html__( 'Start Workbench Job', 'coordinator-core' ); ?></button></p>
					</form>
					<script>
					(function () {
						const goal = document.getElementById('workbench_goal');
						const button = document.getElementById('coordinator_start_workbench_job');
						if (!goal || !button) { return; }
						const update = function () { button.disabled = goal.value.trim().length < 1; };
						goal.addEventListener('input', update);
						update();
					}());
					</script>
				<?php else : ?>
					<?php self::render_current_step( $job, $router_status ); ?>
					<details class="cc-history">
						<summary><?php echo esc_html__( 'Job details and past activity', 'coordinator-core' ); ?></summary>
						<div class="cc-history-body">
						<p><strong><?php echo esc_html__( 'Job:', 'coordinator-core' ); ?></strong> <code><?php echo esc_html( (string) $job['id'] ); ?></code></p>
						<p><strong><?php echo esc_html__( 'Goal:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $job['goal'] ); ?></p>
						<ol>
							<?php foreach ( array_reverse( $job['events'] ) as $event ) : ?>
								<li><strong><?php echo esc_html( (string) $event['at'] ); ?></strong> — <?php echo esc_html( (string) $event['message'] ); ?></li>
							<?php endforeach; ?>
						</ol>
						</div>
					</details>
				<?php endif; ?>
			</div>

			<?php if ( ! empty( $state['history'] ) ) : ?>
				<details class="cc-history">
					<summary><?php echo esc_html__( 'Completed Workbench jobs', 'coordinator-core' ); ?></summary>
					<div class="cc-history-body">
				<table class="widefat striped">
					<thead><tr><th><?php echo esc_html__( 'Job', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Goal', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Last stage', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Updated', 'coordinator-core' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $state['history'] as $past ) : ?>
							<tr><td><code><?php echo esc_html( (string) $past['id'] ); ?></code></td><td><?php echo esc_html( (string) $past['goal'] ); ?></td><td><?php echo esc_html( self::stage_label( (string) $past['stage'] ) ); ?></td><td><?php echo esc_html( (string) $past['updated_at'] ); ?></td></tr>
						<?php endforeach; ?>
					</tbody>
				</table>
					</div>
				</details>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_current_step( array $job, array $router_status ): void {
		$next = self::next_action( (string) $job['stage'] );
		$ready = self::action_readiness( $job, $next, $router_status );
		$runtime = self::runtime_status( $job );
		if ( self::autonomous_stage( (string) $job['stage'] ) && ! $runtime['stalled'] && ! in_array( $runtime['state'], array( 'error', 'needs_you' ), true ) ) {
			$ready = array( 'ready' => false, 'reason' => __( 'Coordinator is working automatically. Continue is disabled until the job needs you or the heartbeat becomes stale.', 'coordinator-core' ) );
		}
		$step_number = self::step_number( $next );
		?>
		<div class="cc-step-top"><span class="cc-step-badge"><?php echo esc_html( sprintf( __( 'Step %1$d of %2$d', 'coordinator-core' ), $step_number, self::TOTAL_STEPS ) ); ?></span><span class="cc-step-state"><?php echo esc_html( sprintf( __( 'Current step: %s', 'coordinator-core' ), $ready['ready'] ? __( 'Ready', 'coordinator-core' ) : __( 'Waiting', 'coordinator-core' ) ) ); ?></span></div>
		<div class="cc-progress" aria-label="<?php echo esc_attr( __( 'Current stage progress', 'coordinator-core' ) ); ?>"><span style="width:<?php echo esc_attr( (string) self::stage_progress( $next ) ); ?>%"></span></div>
		<div class="cc-stage-now" aria-live="polite"><strong><?php echo esc_html__( 'Working on now', 'coordinator-core' ); ?></strong><?php echo esc_html( $runtime['message'] ); ?></div>
		<div class="cc-runtime<?php echo $runtime['stalled'] ? ' cc-runtime-stalled' : ''; ?>" aria-live="polite">
			<strong><?php echo esc_html__( 'Automation status:', 'coordinator-core' ); ?></strong> <?php echo esc_html( ucfirst( (string) $runtime['state'] ) ); ?>
			<br><strong><?php echo esc_html__( 'Last heartbeat:', 'coordinator-core' ); ?></strong> <?php echo esc_html( '' !== $runtime['last_heartbeat_at'] ? $runtime['last_heartbeat_at'] : __( 'No heartbeat recorded yet', 'coordinator-core' ) ); ?>
			<?php if ( $runtime['stalled'] ) : ?><br><strong><?php echo esc_html__( 'Stalled:', 'coordinator-core' ); ?></strong> <?php echo esc_html__( 'No recent automation heartbeat was recorded. Continue is available so this exact saved job can be resumed safely.', 'coordinator-core' ); ?><?php endif; ?>
		</div>
		<?php self::render_live_console( $job, $runtime ); ?>
		<h3><?php echo esc_html( self::step_title( $next ) ); ?></h3>
		<p><?php echo esc_html( self::step_help( $next ) ); ?></p>
		<?php if ( '' !== (string) $job['last_error'] ) : ?>
			<div class="notice notice-error inline"><p><strong><?php echo esc_html__( 'This step did not finish:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $job['last_error'] ); ?> <?php echo esc_html__( 'The saved job is safe. Retry only this step.', 'coordinator-core' ); ?></p></div>
		<?php endif; ?>
		<?php
		if ( 'coding_ready' === (string) $job['stage'] && false !== stripos( (string) $job['last_error'], 'protected base moved' ) ) {
			?>
			<div class="cc-stage-complete">
				<strong><?php echo esc_html__( 'Coding can be retried', 'coordinator-core' ); ?></strong>
				<p><?php echo esc_html__( 'The previous coding attempt stopped at its safety boundary. Keep this job and retry the current coding stage.', 'coordinator-core' ); ?></p>
			</div>
			<?php
		}
		if ( in_array( (string) $job['stage'], array( 'planning', 'awaiting_plan_approval', 'plan_ready', 'waiting_for_github', 'github_preview_ready' ), true ) ) {
			?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:16px 0;">
				<input type="hidden" name="action" value="coordinator_workbench_action">
				<input type="hidden" name="workbench_step" value="cancel_job">
				<input type="hidden" name="workbench_confirmed" value="1">
				<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
				<button class="button" type="submit" onclick="return window.confirm('Cancel and archive this Workbench job?');"><?php echo esc_html__( 'Cancel & Archive Job', 'coordinator-core' ); ?></button>
			</form>
			<?php
		}

		self::render_step_evidence( $job, $next );

		$checkpoint = self::checkpoint_state( $job, $next, $ready );
		if ( '' !== $checkpoint['mode'] ) {
			?>
			<div class="cc-stage-complete" aria-live="polite">
				<strong><?php echo esc_html( $checkpoint['title'] ); ?></strong>
				<p><?php echo esc_html( $checkpoint['summary'] ); ?></p>
				<div class="cc-stage-actions">
					<?php if ( '' !== $checkpoint['show_url'] ) : ?><a class="button" href="<?php echo esc_url( $checkpoint['show_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Show Me', 'coordinator-core' ); ?></a><?php endif; ?>
					<?php if ( 'next' === $checkpoint['mode'] ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="coordinator_workbench_action"><input type="hidden" name="workbench_step" value="<?php echo esc_attr( $next ); ?>"><?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
							<button class="button button-primary cc-primary" type="submit"><?php echo esc_html__( 'Next', 'coordinator-core' ); ?></button>
						</form>
					<?php else : ?><span class="button button-primary cc-primary" aria-disabled="true"><?php echo esc_html__( 'Need You', 'coordinator-core' ); ?></span><?php endif; ?>
				</div>
			</div>
			<?php
			if ( 'archive_obsolete' === $checkpoint['mode'] ) {
			?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:14px;">
				<input type="hidden" name="action" value="coordinator_workbench_action">
				<input type="hidden" name="workbench_step" value="archive_obsolete">
				<input type="hidden" name="workbench_confirmed" value="1">
				<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
				<button type="submit" class="button button-primary button-large"><?php esc_html_e( 'Archive Obsolete Job', 'coordinator-core' ); ?></button>
			</form>
			<?php
			return;
		}

		if ( 'next' === $checkpoint['mode'] ) { return; }
		}

		if ( 'archive' === $next ) {
			?>
			<div class="notice notice-success inline">
				<p><strong><?php echo esc_html__( 'Delivery evidence is ready.', 'coordinator-core' ); ?></strong> <?php echo esc_html__( 'CI passed. Merge and WordPress installation still require separate approval outside this release.', 'coordinator-core' ); ?></p>
			</div>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="coordinator_workbench_action">
				<input type="hidden" name="workbench_step" value="archive">
				<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
				<p><button class="button button-primary cc-primary" type="submit" <?php disabled( ! $ready['ready'] ); ?>><?php echo esc_html__( 'Archive Completed Job', 'coordinator-core' ); ?></button></p>
			</form>
			<?php
			return;
		}

		$labels = array(
			'preview_plan'    => __( 'Preview AI Plan Cost', 'coordinator-core' ),
			'run_plan'        => __( 'Run Confirmed AI Plan', 'coordinator-core' ),
			'accept_plan'     => __( 'Approve Plan and Queue Coding', 'coordinator-core' ),
			'preview_github'  => __( 'Preview GitHub Delivery', 'coordinator-core' ),
			'dispatch_github' => __( 'Create Delivery Branch and Draft PR', 'coordinator-core' ),
			'run_coding' => __( 'Run Bounded Coding', 'coordinator-core' ),
			'refresh_coding' => __( 'Check Bounded Coding Status', 'coordinator-core' ),
			'run_build_stage' => __( 'Continue Build Stage', 'coordinator-core' ),
			'refresh_github'  => __( 'Refresh GitHub and CI Status', 'coordinator-core' ),
			'continue_after_ci' => __( 'Continue to Protected Merge', 'coordinator-core' ),
			'merge_github' => __( 'Run Protected Merge', 'coordinator-core' ),
			'release_gate' => __( 'Build Signed Release', 'coordinator-core' ),
			'refresh_release' => __( 'Check Signed Release Status', 'coordinator-core' ),
			'publish_release' => __( 'Publish Signed Release', 'coordinator-core' ),
			'refresh_publication' => __( 'Check Publication Status', 'coordinator-core' ),
		);
		$confirmation_id = 'coordinator_confirm_' . sanitize_html_class( $next );
		?>
		<?php if ( ! $ready['ready'] ) : ?>
			<div class="notice notice-warning inline"><p><?php echo esc_html( $ready['reason'] ); ?></p></div>
			<?php if ( 'dispatch_github' === $next ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:12px 0 18px;">
					<input type="hidden" name="action" value="coordinator_workbench_action">
					<input type="hidden" name="workbench_step" value="retry_github_preview">
					<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
					<button class="button" type="submit"><?php echo esc_html__( 'Retry GitHub Preview', 'coordinator-core' ); ?></button>
				</form>
			<?php endif; ?>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="coordinator_workbench_action">
			<input type="hidden" name="workbench_step" value="<?php echo esc_attr( $next ); ?>">
			<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
			<?php if ( 'run_plan' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I confirm this paid advisory planning job.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'research' === $next && self::research_confirmation_pending( $job ) ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I confirm this bounded paid research job. The router budget controls still apply.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'dispatch_github' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I confirm creation of the allowlisted GitHub branch and draft pull request.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'merge_github' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I give explicit confirmation to merge this exact tested Workbench pull request through the independent merge gate.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'release_gate' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I give explicit confirmation to build the signed release for this exact merged Workbench job. Publication and WordPress installation remain separate protected actions.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'publish_release' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I give explicit confirmation to publish this exact signed Workbench release. WordPress installation remains a separate protected action.', 'coordinator-core' ); ?></label></p>
			<?php endif; ?>
			<p><button class="button button-primary cc-primary" id="coordinator_current_step_button" type="submit" <?php disabled( ! $ready['ready'] || in_array( $next, array( 'run_plan', 'research', 'dispatch_github', 'merge_github', 'release_gate', 'publish_release' ), true ) ); ?>><?php echo esc_html( $labels[ $next ] ?? __( 'Continue', 'coordinator-core' ) ); ?></button></p>
		</form>
		<?php if ( $ready['ready'] && in_array( $next, array( 'run_plan', 'research', 'dispatch_github', 'merge_github', 'release_gate', 'publish_release' ), true ) ) : ?>
			<script>
			(function () {
				const confirmation = document.getElementById(<?php echo wp_json_encode( $confirmation_id ); ?>);
				const button = document.getElementById('coordinator_current_step_button');
				if (!confirmation || !button) { return; }
				const update = function () { button.disabled = !confirmation.checked; };
				confirmation.addEventListener('change', update);
				update();
			}());
			</script>
		<?php endif; ?>
		<?php
	}

	private static function checkpoint_state( array $job, string $next, array $ready ): array {
		$mode = '';
		$title = '';
		$summary = '';
		$show_url = '';
		if ( ! empty( $job['github_delivery']['pull_request']['url'] ) ) { $show_url = (string) $job['github_delivery']['pull_request']['url']; }
		if ( $ready['ready'] && in_array( $next, array( 'accept_plan', 'continue_after_ci' ), true ) ) {
			$mode = 'next';
			$title = __( 'Stage Complete', 'coordinator-core' );
			$summary = 'accept_plan' === $next ? __( 'The plan is prepared and saved. Press Next when you want Coordinator to begin the protected build stage.', 'coordinator-core' ) : __( 'The build work passed its required checks. Review it with Show Me when available, then press Next to move to the protected completion stage.', 'coordinator-core' );
		} elseif ( $ready['ready'] && in_array( $next, array( 'run_plan', 'dispatch_github', 'merge_github', 'release_gate', 'publish_release' ), true ) ) {
			$mode = 'need_you';
			$title = __( 'Need You', 'coordinator-core' );
			$summary = __( 'This is a protected checkpoint that requires your confirmation. Review the instruction below; routine internal work does not need separate approval.', 'coordinator-core' );
		} elseif ( ! $ready['ready'] && 'release_gate' === $next ) {
			$mode = 'need_you';
			$title = __( 'Stopped Safely', 'coordinator-core' );
			$summary = (string) $ready['reason'];
			if ( 'merged' === (string) $job['stage'] && ! self::has_coding_evidence( $job ) ) {
				$mode = 'archive_obsolete';
				$summary .= ' ' . __( 'Archive this obsolete job to return the Workbench to a clean starting point.', 'coordinator-core' );
			}
		} elseif ( ! $ready['ready'] && in_array( $next, array( 'wordpress_update_gate', 'verify_installation' ), true ) ) {
			$mode = 'need_you';
			$title = __( 'Need You', 'coordinator-core' );
			$summary = (string) $ready['reason'];
		}
		return array( 'mode' => $mode, 'title' => $title, 'summary' => $summary, 'show_url' => $show_url );
	}

	private static function action_readiness( array $job, string $next, array $router_status ): array {
		$ready  = false;
		$reason = __( 'This step is waiting for its required information.', 'coordinator-core' );

		if ( 'preview_plan' === $next ) {
			$ready  = ! empty( $router_status['configured'] ) && '' !== trim( (string) $job['goal'] );
			$reason = __( 'Connect the bounded AI router and save a build goal before previewing.', 'coordinator-core' );
		} elseif ( 'run_plan' === $next ) {
			$ready  = is_array( $job['preview'] );
			$reason = __( 'The free cost preview must finish before a paid plan can run.', 'coordinator-core' );
		} elseif ( 'accept_plan' === $next ) {
			$ready  = '' !== trim( (string) $job['plan'] );
			$reason = __( 'A saved plan is required before coding can be approved.', 'coordinator-core' );
		} elseif ( 'preview_github' === $next ) {
			$ready  = ! empty( $router_status['configured'] ) && '' !== trim( (string) $job['plan'] );
			$reason = __( 'The router connection and an approved plan are required first.', 'coordinator-core' );
		} elseif ( 'dispatch_github' === $next ) {
			$ready  = is_array( $job['github_preview'] ) && ! empty( $job['github_preview']['actions_enabled'] );
			$reason = __( 'GitHub delivery must be configured and pass its free preview first.', 'coordinator-core' );
		} elseif ( 'research' === $next ) {
			$ready = 'researching' === (string) $job['stage'] && ! empty( $router_status['configured'] );
			$reason = self::research_confirmation_pending( $job )
				? __( 'Review the bounded research preview and confirm the paid advisory research job. Router budget controls remain enforced.', 'coordinator-core' )
				: __( 'The bounded AI router must be connected before Coordinator can prepare the read-only research preview.', 'coordinator-core' );
		} elseif ( 'run_build_stage' === $next ) {
			$ready = ! empty( $router_status['configured'] ) && '' !== trim( (string) $job['plan'] );
			$reason = __( 'The router connection and approved plan are required before the automatic build stage can continue.', 'coordinator-core' );
		} elseif ( 'run_coding' === $next ) {
			$ready = ! empty( $router_status['configured'] ) && '' !== trim( (string) $job['plan'] );
			$reason = __( 'The router connection and approved plan are required before coding can run.', 'coordinator-core' );
		} elseif ( 'refresh_coding' === $next ) {
			$ready = ! empty( $router_status['configured'] );
			$reason = __( 'The router connection is required to check the background coding job.', 'coordinator-core' );
		} elseif ( 'refresh_github' === $next ) {
			$ready  = is_array( $job['github_delivery'] );
			$reason = __( 'A GitHub delivery must be dispatched before its status can be refreshed.', 'coordinator-core' );
		} elseif ( 'continue_after_ci' === $next ) {
			$ready  = 'github_ci_passed' === (string) $job['stage'] && self::has_coding_evidence( $job );
			$reason = __( 'Both required GitHub checks must pass before the protected merge stage.', 'coordinator-core' );
		} elseif ( 'merge_github' === $next ) {
			$ready  = 'awaiting_merge' === (string) $job['stage'];
			$reason = __( 'Protected merge requires explicit confirmation. The gateway remains fail-closed unless its independent merge gate is enabled.', 'coordinator-core' );
		} elseif ( 'release_gate' === $next ) {
			$ready  = 'merged' === (string) $job['stage'] && self::has_coding_evidence( $job );
			$reason = $ready
				? __( 'The exact Workbench merge must complete before the protected signed release can run.', 'coordinator-core' )
				: __( 'Stopped safely: this older job has no bounded coding evidence and cannot create a release. It must not continue through the release pipeline.', 'coordinator-core' );
		} elseif ( 'refresh_release' === $next ) {
			$ready  = 'release_dispatched' === (string) $job['stage'];
			$reason = __( 'The signed release must be dispatched before its workflow status can be checked.', 'coordinator-core' );
		} elseif ( 'publish_release' === $next ) {
			$ready  = 'release_ready' === (string) $job['stage'];
			$reason = __( 'The exact signed release must be ready before protected publication.', 'coordinator-core' );
		} elseif ( 'refresh_publication' === $next ) {
			$ready  = 'publication_dispatched' === (string) $job['stage'];
			$reason = __( 'Publication must be dispatched before its exact workflow status can be checked.', 'coordinator-core' );
		} elseif ( 'wordpress_update_gate' === $next ) {
			$reason = __( 'WordPress installation is a separate protected action. WPVibe must remain active.', 'coordinator-core' );
		} elseif ( 'verify_installation' === $next ) {
			$reason = __( 'Installation verification must confirm the expected Coordinator Core version and that WPVibe remains active.', 'coordinator-core' );
		} elseif ( 'archive' === $next ) {
			$ready  = 'verified' === (string) $job['stage'];
			$reason = __( 'Verified installation evidence is required before this job can be archived.', 'coordinator-core' );
		}

		return array( 'ready' => $ready, 'reason' => $reason );
	}

	private static function has_coding_evidence( array $job ): bool {
		$delivery = is_array( $job['github_delivery'] ?? null ) ? $job['github_delivery'] : array();
		$coding = is_array( $delivery['coding_execution'] ?? null ) ? $delivery['coding_execution'] : array();
		return 'coding_changes_ready' === self::clean_text( $coding['state'] ?? '' )
			&& ! empty( $coding['validation_required'] );
	}

	private static function stage_progress( string $next ): int {
		$progress = array(
			'preview_plan' => 15, 'run_plan' => 55, 'accept_plan' => 100,
			'preview_github' => 10, 'dispatch_github' => 30, 'research' => 55, 'run_build_stage' => 55, 'run_coding' => 55, 'refresh_coding' => 65, 'refresh_github' => 75, 'continue_after_ci' => 100,
			'merge_github' => 35, 'release_gate' => 55, 'refresh_release' => 70, 'publish_release' => 82, 'refresh_publication' => 100,
			'wordpress_update_gate' => 35, 'verify_installation' => 85, 'archive' => 100,
		);
		return $progress[ $next ] ?? 0;
	}

	private static function render_live_console( array $job, array $runtime ): void {
		$lines = array();
		foreach ( array_slice( (array) ( $job['events'] ?? array() ), -9 ) as $event ) {
			$message = self::sanitize_console_line( self::clean_text( $event['message'] ?? '' ) );
			if ( '' !== $message ) {
				$lines[] = $message;
			}
		}
		$current = self::sanitize_console_line( self::clean_text( $runtime['message'] ?? '' ) );
		if ( '' !== $current && ( empty( $lines ) || end( $lines ) !== $current ) ) {
			$lines[] = $current;
		}
		$lines = array_slice( $lines, -9 );
		?>
		<div class="cc-live-console-wrap" aria-live="polite">
			<p class="cc-live-console-title"><?php echo esc_html__( 'Live activity — what Coordinator is doing now', 'coordinator-core' ); ?></p>
			<div class="cc-live-console" role="log" aria-label="Coordinator live activity">
				<?php foreach ( $lines as $line ) : ?><span class="cc-live-console-line">&gt; <?php echo esc_html( $line ); ?></span><?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	private static function sanitize_console_line( string $line ): string {
		$line = preg_replace( '/(authorization|token|secret|password|api[_-]?key|private[_-]?key)\\s*[:=]\\s*[^\\s,;]+/i', '$1=[redacted]', $line );
		return is_string( $line ) ? trim( $line ) : '';
	}

	private static function runtime_status( array $job ): array {
		$heartbeat = self::clean_text( $job['last_heartbeat_at'] ?? '' );
		$state = self::clean_text( $job['activity_state'] ?? '' );
		$message = self::clean_text( $job['activity_message'] ?? '' );
		$timestamp = '' !== $heartbeat ? strtotime( $heartbeat ) : false;
		$stalled = self::autonomous_stage( (string) ( $job['stage'] ?? '' ) )
			&& ! self::research_confirmation_pending( $job )
			&& ( false === $timestamp || ( time() - $timestamp ) > self::AUTONOMOUS_STALE_SECONDS );
		if ( $stalled ) {
			$state = 'stalled';
			if ( '' === $message ) {
				$message = __( 'Automation has not reported recent activity.', 'coordinator-core' );
			}
		} elseif ( '' === $state ) {
			$state = self::autonomous_stage( (string) ( $job['stage'] ?? '' ) ) ? 'waiting' : 'needs_you';
		}
		if ( '' === $message ) {
			$message = self::stage_activity( self::next_action( (string) ( $job['stage'] ?? '' ) ) );
		}
		return array(
			'state' => $state,
			'message' => $message,
			'last_heartbeat_at' => $heartbeat,
			'stalled' => $stalled,
		);
	}

	private static function stage_activity( string $next ): string {
		$activity = array(
			'preview_plan' => __( 'Preparing the build stage.', 'coordinator-core' ),
			'run_plan' => __( 'Preparing the work to be completed.', 'coordinator-core' ),
			'accept_plan' => __( 'Stage preparation is complete and ready for your checkpoint.', 'coordinator-core' ),
			'preview_github' => __( 'Preparing the protected coding workspace.', 'coordinator-core' ),
			'dispatch_github' => __( 'Creating the isolated work area.', 'coordinator-core' ),
			'research' => __( 'Preparing a bounded read-only research preview from the saved failure evidence.', 'coordinator-core' ),
			'run_build_stage' => __( 'Writing changes, running checks, and verifying the build automatically.' , 'coordinator-core' ),
			'run_coding' => __( 'Starting the approved coding work in the background.', 'coordinator-core' ),
			'refresh_coding' => __( 'Bounded coding is running in the background.', 'coordinator-core' ),
			'refresh_github' => __( 'Working and running automatic safety checks.', 'coordinator-core' ),
			'continue_after_ci' => __( 'Build work passed its checks and is ready for the stage checkpoint.', 'coordinator-core' ),
			'merge_github' => __( 'Finalizing the tested work.', 'coordinator-core' ),
			'release_gate' => __( 'Building the verified release.', 'coordinator-core' ),
			'refresh_release' => __( 'Verifying the release build.', 'coordinator-core' ),
			'publish_release' => __( 'Publishing the verified release.', 'coordinator-core' ),
			'refresh_publication' => __( 'Release stage is complete and ready for your checkpoint.', 'coordinator-core' ),
			'wordpress_update_gate' => __( 'Waiting for the protected site update.', 'coordinator-core' ),
			'verify_installation' => __( 'Checking the installed result.', 'coordinator-core' ),
			'archive' => __( 'Site verification is complete.', 'coordinator-core' ),
		);
		return $activity[ $next ] ?? __( 'Waiting for the next safe action.', 'coordinator-core' );
	}

	private static function step_number( string $next ): int {
		$steps = array(
			'preview_plan'    => 2,
			'run_plan'        => 3,
			'accept_plan'     => 4,
			'preview_github'  => 5,
			'dispatch_github' => 6,
			'research' => 7,
			'run_build_stage' => 7,
			'run_coding'      => 7,
			'refresh_coding'  => 7,
			'refresh_github'  => 7,
			'continue_after_ci' => 8,
			'merge_github' => 9,
			'release_gate' => 10,
			'refresh_release' => 10,
			'publish_release' => 10,
			'refresh_publication' => 10,
			'wordpress_update_gate' => 11,
			'verify_installation' => 12,
			'archive' => 12,
		);
		return $steps[ $next ] ?? 1;
	}

	private static function step_title( string $next ): string {
		$titles = array(
			'preview_plan'    => __( 'Check the plan cost', 'coordinator-core' ),
			'run_plan'        => __( 'Create the implementation plan', 'coordinator-core' ),
			'accept_plan'     => __( 'Review and approve the plan', 'coordinator-core' ),
			'preview_github'  => __( 'Check the GitHub delivery', 'coordinator-core' ),
			'dispatch_github' => __( 'Create the coding pull request', 'coordinator-core' ),
			'research' => __( 'Prepare the bounded research preview', 'coordinator-core' ),
			'run_build_stage' => __( 'Continue the automatic build stage', 'coordinator-core' ),
			'run_coding' => __( 'Start the approved coding changes', 'coordinator-core' ),
			'refresh_coding' => __( 'Check the background coding job', 'coordinator-core' ),
			'refresh_github'  => __( 'Check the coding and safety tests', 'coordinator-core' ),
			'continue_after_ci' => __( 'Move to protected merge', 'coordinator-core' ),
			'merge_github' => __( 'Merge the tested coding pull request', 'coordinator-core' ),
			'release_gate' => __( 'Build the signed release', 'coordinator-core' ),
			'refresh_release' => __( 'Check the signed release build', 'coordinator-core' ),
			'publish_release' => __( 'Publish the signed release', 'coordinator-core' ),
			'refresh_publication' => __( 'Check release publication', 'coordinator-core' ),
			'wordpress_update_gate' => __( 'Install the verified WordPress update', 'coordinator-core' ),
			'verify_installation' => __( 'Verify the live installation', 'coordinator-core' ),
			'archive' => __( 'Archive the completed job', 'coordinator-core' ),
		);
		return $titles[ $next ] ?? __( 'Wait for the next safe step', 'coordinator-core' );
	}

	private static function step_help( string $next ): string {
		$help = array(
			'preview_plan'    => __( 'This free check confirms the model, budget, and maximum cost. It does not spend money.', 'coordinator-core' ),
			'run_plan'        => __( 'Review the maximum cost, check the confirmation box, and run one paid advisory planning job.', 'coordinator-core' ),
			'accept_plan'     => __( 'Read the plan below. Approval allows the next GitHub preview but does not merge, deploy, or install anything.', 'coordinator-core' ),
			'preview_github'  => __( 'This free check confirms the repository, branch, permissions, and safety boundaries.', 'coordinator-core' ),
			'dispatch_github' => __( 'Confirm creation of one allowlisted branch and one draft pull request. Merge and WordPress installation remain disabled.', 'coordinator-core' ),
			'research' => __( 'Coordinator prepares the read-only research request and its cost/routing preview from saved failure evidence. Paid research still requires its independent confirmation and budget controls.', 'coordinator-core' ),
			'run_build_stage' => __( 'Coordinator handles routine workspace checks, bounded coding, and verification automatically. It stops when checks are still running or a user checkpoint is reached.', 'coordinator-core' ),
			'run_coding' => __( 'The bounded backup AI receives only the approved goal, plan, and server-verified source files. It runs in the background and can write only to the isolated delivery branch.', 'coordinator-core' ),
			'refresh_coding' => __( 'Check the saved background coding job. This does not start another AI generation or duplicate branch writes.', 'coordinator-core' ),
			'refresh_github'  => __( 'Refresh until the draft pull request and both required safety checks are finished.', 'coordinator-core' ),
			'continue_after_ci' => __( 'CI passed. Continue into the protected completion pipeline; this does not merge anything by itself.', 'coordinator-core' ),
			'merge_github' => __( 'This sends the exact Workbench job to the protected merge gateway. The gateway re-verifies the branch, pull request, head SHA, base branch, and required CI before merging.', 'coordinator-core' ),
			'release_gate' => __( 'Create the signed release only after the tested pull request is merged. Publication remains a separate protected action.', 'coordinator-core' ),
			'refresh_release' => __( 'Check the exact signed-release workflow for this Workbench job. Publication stays locked until that build succeeds.', 'coordinator-core' ),
			'publish_release' => __( 'Publish only the exact signed Workbench release through the independent protected publication gate. WordPress installation remains disabled.', 'coordinator-core' ),
			'refresh_publication' => __( 'Check the exact publication workflow for this Workbench job. Step 11 stays locked until publication succeeds.', 'coordinator-core' ),
			'wordpress_update_gate' => __( 'Install only the verified Coordinator Core release. WPVibe remains active.', 'coordinator-core' ),
			'verify_installation' => __( 'Confirm the expected Coordinator Core version is active and WPVibe is still active before completion.', 'coordinator-core' ),
			'archive' => __( 'All completion evidence is verified. Archiving moves this job into history and makes room for the next job.', 'coordinator-core' ),
		);
		return $help[ $next ] ?? __( 'This action is not available yet.', 'coordinator-core' );
	}

	private static function render_step_evidence( array $job, string $next ): void {
		if ( 'run_plan' === $next && is_array( $job['preview'] ) ) {
			?><p><strong><?php echo esc_html__( 'Maximum cost:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::money( $job['estimated_cost_usd'] ) ); ?> &nbsp; <strong><?php echo esc_html__( 'Model:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['preview']['normalized_job']['model'] ?? 'gpt-5.6-luna' ) ); ?></p><?php
		} elseif ( 'accept_plan' === $next && '' !== (string) $job['plan'] ) {
			?><pre style="overflow:auto;white-space:pre-wrap;border:1px solid #dcdcde;padding:12px;background:#f6f7f7"><?php echo esc_html( (string) $job['plan'] ); ?></pre><?php
		} elseif ( 'research' === $next && is_array( $job['supervisor_research_preview'] ?? null ) ) {
			$preview = $job['supervisor_research_preview'];
			?><p><strong><?php echo esc_html__( 'Maximum research cost:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::money( isset( $preview['estimated_max_cost_usd'] ) ? (float) $preview['estimated_max_cost_usd'] : null ) ); ?> &nbsp; <strong><?php echo esc_html__( 'Model:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $preview['normalized_job']['model'] ?? 'gpt-5.6-luna' ) ); ?></p><?php
		} elseif ( 'dispatch_github' === $next && is_array( $job['github_preview'] ) ) {
			?><p><strong><?php echo esc_html__( 'Repository:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['github_preview']['repository'] ?? 'Not configured' ) ); ?><br><strong><?php echo esc_html__( 'Delivery branch:', 'coordinator-core' ); ?></strong> <code><?php echo esc_html( (string) ( $job['github_preview']['branch'] ?? '' ) ); ?></code></p><?php
		} elseif ( in_array( $next, array( 'refresh_github', 'github_ci_ready' ), true ) && is_array( $job['github_delivery'] ) ) {
			?><p><strong><?php echo esc_html__( 'Delivery state:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['github_delivery']['state'] ?? 'queued' ) ); ?><br><strong><?php echo esc_html__( 'CI:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['github_delivery']['ci_state'] ?? $job['github_delivery']['ci'] ?? 'pending' ) ); ?></p><?php
			if ( ! empty( $job['github_delivery']['pull_request']['url'] ) ) {
				?><p><a href="<?php echo esc_url( (string) $job['github_delivery']['pull_request']['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Review the draft pull request', 'coordinator-core' ); ?></a></p><?php
			}
		}
	}

	private static function github_payload( array $job ): array {
		return array(
			'job_id' => (string) $job['id'],
			'goal'   => (string) $job['goal'],
			'plan'   => (string) $job['plan'],
		);
	}

	private static function router_job( array $job ): array {
		return array(
			'task_type'         => 'draft',
			'instructions'      => 'Create a concise implementation plan for the build goal. Include scope, likely files, tests, risks, approval gates, and the exact next action. Do not claim that code, GitHub, installation, publishing, or deployment actions were performed.',
			'input'             => (string) $job['goal'],
			'model'             => 'gpt-5.6-luna',
			'max_output_tokens' => 1200,
			'idempotency_key'   => 'workbench-' . (string) $job['id'] . '-plan',
		);
	}

	private static function research_router_job( array $job ): array {
		$attempts = array_slice( is_array( $job['supervisor_attempts'] ?? null ) ? $job['supervisor_attempts'] : array(), -5 );
		$matches = array_slice( is_array( $job['supervisor_memory_matches'] ?? null ) ? $job['supervisor_memory_matches'] : array(), 0, 5 );
		$evidence = array(
			'goal' => self::clean_text( $job['goal'] ?? '' ),
			'last_error' => self::clean_text( $job['last_error'] ?? '' ),
			'prior_attempts' => $attempts,
			'verified_memory_matches' => $matches,
		);
		return array(
			'task_type' => 'review',
			'instructions' => 'Diagnose the saved Workbench failure using only the supplied evidence. Propose one evidence-supported hypothesis and a materially different next approach from failed attempts. State what evidence supports the hypothesis, what would falsify it, and how progress must be verified. Do not execute code, GitHub, WordPress, publishing, deployment, or other write actions. Do not claim research outside the supplied evidence was performed.',
			'input' => wp_json_encode( $evidence, JSON_UNESCAPED_SLASHES ),
			'model' => 'gpt-5.6-luna',
			'max_output_tokens' => 1200,
			'idempotency_key' => 'workbench-' . (string) $job['id'] . '-research-' . substr( hash( 'sha256', (string) ( $job['last_error'] ?? '' ) . '|' . wp_json_encode( $attempts ) ), 0, 16 ),
		);
	}

	private static function prepare_research_job( array &$job ): array {
		$request = self::research_router_job( $job );
		$job['supervisor_research_job'] = $request;
		$job['supervisor_research_status'] = 'prepared';
		return $request;
	}

	private static function record_error( array $state, array $job, WP_Error $error ) {
		$job['last_error'] = $error->get_error_message();
		self::add_event( $job, 'Step failed safely: ' . $job['last_error'] );
		$job['updated_at']   = gmdate( 'c' );
		$state['active_job'] = $job;
		self::save_state( $state );
		return $error;
	}

	private static function add_event( array &$job, string $message ): void {
		$job['events'][] = array(
			'at'      => gmdate( 'c' ),
			'stage'   => (string) $job['stage'],
			'message' => $message,
		);
		$job['events'] = array_slice( $job['events'], -50 );
	}

	private static function next_action( string $stage ): string {
		$actions = array(
			'planning'               => 'preview_plan',
			'awaiting_plan_approval' => 'run_plan',
			'plan_ready'             => 'accept_plan',
			'waiting_for_github'     => 'preview_github',
			'github_preview_ready'    => 'dispatch_github',
			'github_dispatch_queued'  => 'run_build_stage',
			'github_pr_open'          => 'run_build_stage',
			'coding_ready'            => 'run_build_stage',
			'coding_running'          => 'run_build_stage',
			'diagnosing'              => 'diagnose',
			'researching'             => 'research',
			'github_ci_passed'        => 'run_build_stage',
			'awaiting_merge'          => 'run_build_stage',
			'merged'                  => 'run_build_stage',
			'release_dispatched'      => 'run_build_stage',
			'release_ready'           => 'run_build_stage',
			'publication_dispatched' => 'run_build_stage',
			'release_published'       => 'wordpress_update_gate',
			'wordpress_update_ready'  => 'verify_installation',
			'verified'                => 'archive',
		);
		return $actions[ $stage ] ?? 'start';
	}

	private static function stage_label( string $stage ): string {
		$labels = array(
			'planning'               => 'Planning',
			'awaiting_plan_approval' => 'Awaiting paid-plan approval',
			'plan_ready'             => 'Plan ready for review',
			'waiting_for_github'     => 'Approved plan queued for GitHub delivery preview',
			'github_preview_ready'    => 'GitHub delivery ready for approval',
			'github_dispatch_queued'  => 'GitHub delivery dispatched',
			'github_pr_open'          => 'Draft pull request open; CI pending',
			'coding_ready'            => 'Isolated workspace ready for bounded coding',
			'coding_running'          => 'Bounded coding running in background',
			'diagnosing'              => 'Diagnosing the problem from saved evidence',
			'researching'             => 'Researching a new evidence-supported approach',
			'github_ci_passed'        => 'Draft pull request open; CI passed',
			'awaiting_merge'          => 'CI passed; protected merge pending',
			'merged'                  => 'Merged; signed release pending',
			'release_dispatched'      => 'Signed release building',
			'release_ready'           => 'Signed release ready; protected publication pending',
			'publication_dispatched' => 'Release publication running',
			'release_published'       => 'Release published; WordPress update pending',
			'wordpress_update_ready'  => 'WordPress update installed; verification pending',
			'verified'                => 'Live installation verified',
		);
		return $labels[ $stage ] ?? $stage;
	}

	private static function normalize_job( $job ): ?array {
		if ( ! is_array( $job ) ) {
			return null;
		}
		$id    = self::clean_text( $job['id'] ?? '' );
		$goal  = self::clean_text( $job['goal'] ?? '' );
		$stage = self::clean_text( $job['stage'] ?? '' );
		if ( '' === $id || '' === $goal || ! in_array( $stage, self::STAGES, true ) ) {
			return null;
		}

		$events = array();
		foreach ( (array) ( $job['events'] ?? array() ) as $event ) {
			if ( is_array( $event ) && '' !== self::clean_text( $event['message'] ?? '' ) ) {
				$events[] = array(
					'at'      => self::clean_text( $event['at'] ?? '' ),
					'stage'   => self::clean_text( $event['stage'] ?? '' ),
					'message' => self::clean_text( $event['message'] ?? '' ),
				);
			}
		}

		return array(
			'id'                 => $id,
			'goal'               => $goal,
			'stage'              => $stage,
			'created_at'         => self::clean_text( $job['created_at'] ?? '' ),
			'updated_at'         => self::clean_text( $job['updated_at'] ?? '' ),
			'actor_id'           => (int) ( $job['actor_id'] ?? 0 ),
			'provider'           => self::clean_text( $job['provider'] ?? '' ),
			'estimated_cost_usd' => is_numeric( $job['estimated_cost_usd'] ?? null ) ? (float) $job['estimated_cost_usd'] : null,
			'actual_cost_usd'    => is_numeric( $job['actual_cost_usd'] ?? null ) ? (float) $job['actual_cost_usd'] : null,
			'plan'               => is_string( $job['plan'] ?? null ) ? trim( $job['plan'] ) : '',
			'preview'            => is_array( $job['preview'] ?? null ) ? $job['preview'] : null,
			'github_preview'     => is_array( $job['github_preview'] ?? null ) ? $job['github_preview'] : null,
			'github_delivery'    => is_array( $job['github_delivery'] ?? null ) ? $job['github_delivery'] : null,
			'coding_execution'   => is_array( $job['coding_execution'] ?? null ) ? $job['coding_execution'] : null,
			'activity_state'     => self::clean_text( $job['activity_state'] ?? '' ),
			'activity_message'   => self::clean_text( $job['activity_message'] ?? '' ),
			'last_heartbeat_at'  => self::clean_text( $job['last_heartbeat_at'] ?? '' ),
			'tick_started_at'    => self::clean_text( $job['tick_started_at'] ?? '' ),
			'supervisor_mode'     => self::clean_text( $job['supervisor_mode'] ?? '' ),
			'supervisor_hypothesis' => self::clean_text( $job['supervisor_hypothesis'] ?? '' ),
			'supervisor_verified_lesson_id' => self::clean_text( $job['supervisor_verified_lesson_id'] ?? '' ),
			'supervisor_attempts' => array_slice( is_array( $job['supervisor_attempts'] ?? null ) ? $job['supervisor_attempts'] : array(), -20 ),
			'supervisor_memory_matches' => array_slice( is_array( $job['supervisor_memory_matches'] ?? null ) ? $job['supervisor_memory_matches'] : array(), 0, 5 ),
			'supervisor_research_job' => is_array( $job['supervisor_research_job'] ?? null ) ? $job['supervisor_research_job'] : null,
			'supervisor_research_status' => self::clean_text( $job['supervisor_research_status'] ?? '' ),
			'supervisor_research_preview' => is_array( $job['supervisor_research_preview'] ?? null ) ? $job['supervisor_research_preview'] : null,
			'coding_retry_count' => max( 0, (int) ( $job['coding_retry_count'] ?? 0 ) ),
			'coding_retry_signature' => self::clean_text( $job['coding_retry_signature'] ?? '' ),
			'last_error'         => self::clean_text( $job['last_error'] ?? '' ),
			'events'             => array_slice( $events, -50 ),
			'archived_at'        => self::clean_text( $job['archived_at'] ?? '' ),
		);
	}

	private static function empty_state(): array {
		return array(
			'schema_version' => 1,
			'active_job'     => null,
			'history'        => array(),
			'updated_at'     => '',
		);
	}

	private static function save_state( array $state ): void {
		$state['schema_version'] = 1;
		$state['updated_at']     = gmdate( 'c' );
		update_option( self::OPTION, $state, false );
	}

	private static function posted_string( string $key ): string {
		$value = wp_unslash( $_POST[ $key ] ?? '' );
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function clean_text( $value ): string {
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function money( $value ): string {
		return is_numeric( $value ) ? '$' . number_format( (float) $value, 6 ) : 'Not available';
	}
}
