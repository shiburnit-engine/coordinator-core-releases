<?php
/**
 * OAuth 2.1 authorization-code flow for the read-only WordPress Connector.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_OAuth_Foundation {
	private const REST_NAMESPACE = 'coordinator-core/v1';
	private const CODE_TTL       = 300;
	private const TOKEN_TTL      = 3600;
	private const CODE_PREFIX    = 'coordinator_oauth_code_';
	private const TOKEN_PREFIX   = 'coordinator_oauth_token_';

	public static function boot(): void {
		add_action( 'admin_post_coordinator_oauth_authorize', array( self::class, 'handle_authorization_request' ) );
		add_action( 'parse_request', array( self::class, 'handle_well_known_request' ) );
	}

	public static function handle_well_known_request( $wp ): void {
		$path = trim( (string) ( $wp->request ?? '' ), '/' );
		if ( '.well-known/oauth-authorization-server' === $path ) {
			wp_send_json( self::authorization_server_metadata_payload() );
		}
		if ( 1 === preg_match( '#^\.well-known/oauth-protected-resource(?:/.*)?$#', $path ) ) {
			wp_send_json( self::protected_resource_metadata_payload() );
		}
	}

	public static function register_rest_routes(): void {
		register_rest_route( self::REST_NAMESPACE, '/connector/oauth/protected-resource-metadata', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( self::class, 'protected_resource_metadata' ), 'permission_callback' => array( self::class, 'can_discover' ) ) );
		register_rest_route( self::REST_NAMESPACE, '/connector/oauth/authorization-server-metadata', array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( self::class, 'authorization_server_metadata' ), 'permission_callback' => array( self::class, 'can_discover' ) ) );
		register_rest_route( self::REST_NAMESPACE, '/connector/oauth/token', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( self::class, 'token_request' ), 'permission_callback' => array( self::class, 'can_discover' ) ) );
		register_rest_route( self::REST_NAMESPACE, '/connector/oauth/revoke', array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( self::class, 'revoke_request' ), 'permission_callback' => array( self::class, 'can_discover' ) ) );
	}

	public static function can_discover(): bool {
		return is_ssl();
	}

	public static function protected_resource_metadata() {
		return rest_ensure_response( self::protected_resource_metadata_payload() );
	}

	private static function protected_resource_metadata_payload(): array {
		return array(
				'resource'              => self::resource_identifier(),
				'authorization_servers' => array( self::issuer() ),
				'scopes_supported'      => self::supported_scopes(),
				'coordinator_status'    => 'authorization-code-pkce',
				'oauth_ready'           => true,
			);
	}

	public static function authorization_server_metadata() {
		return rest_ensure_response( self::authorization_server_metadata_payload() );
	}

	private static function authorization_server_metadata_payload(): array {
		return array(
				'issuer'                                         => self::issuer(),
				'authorization_endpoint'                         => admin_url( 'admin-post.php?action=coordinator_oauth_authorize' ),
				'token_endpoint'                                 => rest_url( self::REST_NAMESPACE . '/connector/oauth/token' ),
				'revocation_endpoint'                            => rest_url( self::REST_NAMESPACE . '/connector/oauth/revoke' ),
				'response_types_supported'                       => array( 'code' ),
				'grant_types_supported'                          => array( 'authorization_code' ),
				'code_challenge_methods_supported'               => array( 'S256' ),
				'token_endpoint_auth_methods_supported'          => array( 'none' ),
				'revocation_endpoint_auth_methods_supported'     => array( 'none' ),
				'scopes_supported'                               => self::supported_scopes(),
				'client_id_metadata_document_supported'          => true,
				'authorization_response_iss_parameter_supported' => true,
				'coordinator_status'                             => 'authorization-code-pkce',
				'oauth_ready'                                    => true,
			);
	}

	public static function handle_authorization_request(): void {
		if ( ! is_ssl() ) {
			wp_die( esc_html__( 'OAuth authorization requires HTTPS.', 'coordinator-core' ), '', array( 'response' => 400 ) );
		}
		if ( ! is_user_logged_in() ) {
			auth_redirect();
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}

		$params    = self::authorization_parameters( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ? $_POST : $_GET );
		$validated = self::validate_authorization_request( $params );
		if ( is_wp_error( $validated ) ) {
			wp_die( esc_html( $validated->get_error_message() ), '', array( 'response' => 400 ) );
		}

		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) {
			self::render_consent_page( $validated );
			return;
		}

		check_admin_referer( 'coordinator_oauth_authorize' );
		if ( 'approve' !== sanitize_key( wp_unslash( $_POST['coordinator_oauth_decision'] ?? '' ) ) ) {
			self::redirect_authorization_response( $validated['redirect_uri'], array( 'error' => 'access_denied', 'error_description' => 'The resource owner denied the request.', 'state' => $validated['state'], 'iss' => self::issuer() ) );
		}

		$issued = self::issue_authorization_code( $validated, get_current_user_id() );
		if ( is_wp_error( $issued ) ) {
			wp_die( esc_html( $issued->get_error_message() ), '', array( 'response' => 500 ) );
		}

		self::redirect_authorization_response( $validated['redirect_uri'], array( 'code' => $issued, 'state' => $validated['state'], 'iss' => self::issuer() ) );
	}

	public static function validate_authorization_request( array $params ) {
		foreach ( array( 'client_id', 'redirect_uri', 'state', 'code_challenge', 'resource' ) as $field ) {
			if ( '' === ( $params[ $field ] ?? '' ) ) {
				return self::oauth_error( 'invalid_request', 'A required authorization parameter is missing.', 400 );
			}
		}
		if ( 'code' !== ( $params['response_type'] ?? '' ) ) {
			return self::oauth_error( 'unsupported_response_type', 'Only the authorization-code response type is supported.', 400 );
		}
		if ( 'S256' !== ( $params['code_challenge_method'] ?? '' ) || ! preg_match( '/^[A-Za-z0-9_-]{43}$/', $params['code_challenge'] ) ) {
			return self::oauth_error( 'invalid_request', 'PKCE S256 is required.', 400 );
		}
		if ( self::resource_identifier() !== $params['resource'] ) {
			return self::oauth_error( 'invalid_target', 'The requested resource is not valid.', 400 );
		}
		$scope = self::normalize_scope( $params['scope'] ?? '' );
		if ( ! in_array( $scope, array( Coordinator_Authentication::READ_SCOPE, self::write_scope_set() ), true ) ) {
			return self::oauth_error( 'invalid_scope', 'The requested Coordinator scope is not available.', 400 );
		}

		$client = self::client_metadata( $params['client_id'] );
		if ( is_wp_error( $client ) ) {
			return $client;
		}
		if ( ! in_array( $params['redirect_uri'], $client['redirect_uris'], true ) ) {
			return self::oauth_error( 'invalid_request', 'The redirect URI is not registered for this client.', 400 );
		}

		$params['scope']       = $scope;
		$params['client_name'] = $client['client_name'];
		return $params;
	}

	public static function issue_authorization_code( array $params, int $user_id ) {
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return self::oauth_error( 'access_denied', 'A valid administrator is required.', 403 );
		}
		$code = self::random_secret();
		set_transient(
			self::CODE_PREFIX . self::secret_hash( $code ),
			array(
				'client_id' => $params['client_id'], 'redirect_uri' => $params['redirect_uri'], 'code_challenge' => $params['code_challenge'],
				'resource' => $params['resource'], 'scope' => $params['scope'], 'user_id' => $user_id, 'expires_at' => time() + self::CODE_TTL,
			),
			self::CODE_TTL
		);
		return $code;
	}

	public static function token_request( WP_REST_Request $request ) {
		return self::exchange_authorization_code( $request->get_params() );
	}

	public static function exchange_authorization_code( array $params ) {
		if ( 'authorization_code' !== ( $params['grant_type'] ?? '' ) ) {
			return self::oauth_error( 'unsupported_grant_type', 'Only authorization_code is supported.', 400 );
		}
		$code = is_string( $params['code'] ?? null ) ? $params['code'] : '';
		if ( '' === $code ) {
			return self::oauth_error( 'invalid_grant', 'The authorization code is missing.', 400 );
		}

		$key    = self::CODE_PREFIX . self::secret_hash( $code );
		$record = get_transient( $key );
		delete_transient( $key );
		if ( ! is_array( $record ) || (int) ( $record['expires_at'] ?? 0 ) < time() ) {
			return self::oauth_error( 'invalid_grant', 'The authorization code is invalid or expired.', 400 );
		}
		foreach ( array( 'client_id', 'redirect_uri', 'resource' ) as $field ) {
			$value = is_string( $params[ $field ] ?? null ) ? $params[ $field ] : '';
			if ( ! hash_equals( (string) $record[ $field ], $value ) ) {
				return self::oauth_error( 'invalid_grant', 'The authorization code binding is invalid.', 400 );
			}
		}

		$verifier = is_string( $params['code_verifier'] ?? null ) ? $params['code_verifier'] : '';
		if ( ! preg_match( '/^[A-Za-z0-9._~-]{43,128}$/', $verifier ) || ! hash_equals( (string) $record['code_challenge'], self::pkce_challenge( $verifier ) ) ) {
			return self::oauth_error( 'invalid_grant', 'PKCE verification failed.', 400 );
		}

		$token = self::random_secret();
		set_transient(
			self::TOKEN_PREFIX . self::secret_hash( $token ),
			array( 'client_id' => $record['client_id'], 'resource' => $record['resource'], 'scope' => $record['scope'], 'user_id' => (int) $record['user_id'], 'expires_at' => time() + self::TOKEN_TTL ),
			self::TOKEN_TTL
		);

		return rest_ensure_response( array( 'access_token' => $token, 'token_type' => 'Bearer', 'expires_in' => self::TOKEN_TTL, 'scope' => $record['scope'], 'resource' => self::resource_identifier() ) );
	}

	public static function authenticate_bearer_token() {
		$header = self::authorization_header();
		if ( ! preg_match( '/^Bearer[ ]+([^ ]+)$/i', $header, $matches ) ) {
			return self::oauth_error( 'invalid_token', 'A bearer token is required.', 401 );
		}
		$record = get_transient( self::TOKEN_PREFIX . self::secret_hash( $matches[1] ) );
		$scopes = is_array( $record ) ? preg_split( '/\s+/', trim( (string) ( $record['scope'] ?? '' ) ) ) : array();
		if ( ! is_array( $record ) || (int) ( $record['expires_at'] ?? 0 ) < time() || self::resource_identifier() !== ( $record['resource'] ?? '' ) || ! in_array( Coordinator_Authentication::READ_SCOPE, $scopes, true ) ) {
			return self::oauth_error( 'invalid_token', 'The bearer token is invalid or expired.', 401 );
		}
		if ( ! user_can( (int) $record['user_id'], 'manage_options' ) ) {
			return self::oauth_error( 'invalid_token', 'The authorizing administrator no longer has permission.', 401 );
		}
		return $record;
	}

	public static function revoke_request( WP_REST_Request $request ) {
		$token = (string) $request->get_param( 'token' );
		if ( '' !== $token ) {
			delete_transient( self::TOKEN_PREFIX . self::secret_hash( $token ) );
		}
		return rest_ensure_response( array() );
	}

	public static function resource_identifier(): string {
		return rest_url( self::REST_NAMESPACE . '/mcp' );
	}

	private static function authorization_parameters( array $source ): array {
		$params = array();
		foreach ( array( 'response_type', 'client_id', 'redirect_uri', 'scope', 'state', 'code_challenge', 'code_challenge_method', 'resource' ) as $key ) {
			$params[ $key ] = sanitize_text_field( wp_unslash( $source[ $key ] ?? '' ) );
		}
		return $params;
	}

	private static function client_metadata( string $client_id ) {
		if ( ! self::is_allowed_client_id( $client_id ) ) {
			return self::oauth_error( 'invalid_request', 'The OAuth client is not trusted.', 400 );
		}
		$metadata = apply_filters( 'coordinator_core_oauth_client_metadata', null, $client_id );
		if ( null === $metadata ) {
			$response = wp_safe_remote_get( $client_id, array( 'timeout' => 5, 'redirection' => 0, 'headers' => array( 'Accept' => 'application/json' ) ) );
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
				return self::oauth_error( 'invalid_request', 'The OAuth client metadata could not be verified.', 400 );
			}
			$metadata = json_decode( wp_remote_retrieve_body( $response ), true );
		}
		if ( ! is_array( $metadata ) ) {
			return self::oauth_error( 'invalid_request', 'The OAuth client metadata is invalid.', 400 );
		}
		$client_methods = is_array( $metadata['token_endpoint_auth_methods_supported'] ?? null )
			? $metadata['token_endpoint_auth_methods_supported']
			: array( $metadata['token_endpoint_auth_method'] ?? 'none' );
		if ( ! hash_equals( $client_id, (string) ( $metadata['client_id'] ?? '' ) ) || ! is_array( $metadata['redirect_uris'] ?? null ) || ! in_array( 'none', $client_methods, true ) ) {
			return self::oauth_error( 'invalid_request', 'The OAuth client metadata is invalid.', 400 );
		}
		$redirect_uris = array_values( array_filter( $metadata['redirect_uris'], static fn( $uri ): bool => is_string( $uri ) && 0 === strpos( $uri, 'https://' ) ) );
		if ( array() === $redirect_uris ) {
			return self::oauth_error( 'invalid_request', 'The OAuth client has no secure redirect URI.', 400 );
		}
		return array( 'client_id' => $client_id, 'client_name' => sanitize_text_field( (string) ( $metadata['client_name'] ?? 'OpenAI client' ) ), 'redirect_uris' => $redirect_uris );
	}

	private static function is_allowed_client_id( string $client_id ): bool {
		$parts = wp_parse_url( $client_id );
		if ( ! is_array( $parts ) || 'https' !== ( $parts['scheme'] ?? '' ) || 'chatgpt.com' !== strtolower( $parts['host'] ?? '' ) ) {
			return false;
		}
		return 1 === preg_match( '#^/oauth/(?:client\.json|[A-Za-z0-9_-]+/client\.json)$#', $parts['path'] ?? '' ) && empty( $parts['query'] ) && empty( $parts['fragment'] );
	}

	private static function render_consent_page( array $params ): void {
		?><!doctype html>
		<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?php echo esc_html__( 'Authorize Coordinator', 'coordinator-core' ); ?></title><?php wp_admin_css( 'login', true ); ?></head>
		<body class="login"><div id="login"><h1><?php echo esc_html__( 'Authorize Coordinator', 'coordinator-core' ); ?></h1>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<p><?php echo esc_html( sprintf( __( '%s is requesting access to Coordinator.', 'coordinator-core' ), $params['client_name'] ) ); ?></p>
		<p><strong><?php echo esc_html__( 'Allowed:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::write_scope_set() === $params['scope'] ? __( 'Read Coordinator status and safe site inventory, and update only Coordinator operational state after explicit approval.', 'coordinator-core' ) : __( 'Read Coordinator status and safe site inventory.', 'coordinator-core' ) ); ?></p>
		<p><strong><?php echo esc_html__( 'Not allowed:', 'coordinator-core' ); ?></strong> <?php echo esc_html__( 'Publishing; editing site content; installing, updating, activating, or deactivating plugins or themes; deployment; file or user changes; or deletion.', 'coordinator-core' ); ?></p>
		<input type="hidden" name="action" value="coordinator_oauth_authorize">
		<?php foreach ( array( 'response_type', 'client_id', 'redirect_uri', 'scope', 'state', 'code_challenge', 'code_challenge_method', 'resource' ) as $field ) : ?><input type="hidden" name="<?php echo esc_attr( $field ); ?>" value="<?php echo esc_attr( $params[ $field ] ); ?>"><?php endforeach; ?>
		<?php wp_nonce_field( 'coordinator_oauth_authorize' ); ?>
		<p class="submit"><button class="button button-primary button-large" name="coordinator_oauth_decision" value="approve" type="submit"><?php echo esc_html( self::write_scope_set() === $params['scope'] ? __( 'Allow limited operational-state access', 'coordinator-core' ) : __( 'Allow read-only access', 'coordinator-core' ) ); ?></button> <button class="button button-large" name="coordinator_oauth_decision" value="deny" type="submit"><?php echo esc_html__( 'Cancel', 'coordinator-core' ); ?></button></p>
		</form></div></body></html><?php
	}

	private static function redirect_authorization_response( string $redirect_uri, array $params ): void {
		wp_redirect( add_query_arg( array_filter( $params, static fn( $value ): bool => '' !== $value ), $redirect_uri ), 302, 'Coordinator Core' );
		exit;
	}

	private static function authorization_header(): string {
		return trim( (string) ( $_SERVER['HTTP_AUTHORIZATION'] ?? '' ) );
	}

	private static function normalize_scope( string $scope ): string {
		$scopes = preg_split( '/\s+/', trim( $scope ) ) ?: array();
		$scopes = array_values( array_unique( array_filter( $scopes ) ) );
		sort( $scopes );
		return implode( ' ', $scopes );
	}

	private static function supported_scopes(): array {
		return array( Coordinator_Authentication::READ_SCOPE, Coordinator_Authentication::WRITE_OPERATIONAL_STATE_SCOPE );
	}

	private static function write_scope_set(): string {
		return self::normalize_scope( Coordinator_Authentication::READ_SCOPE . ' ' . Coordinator_Authentication::WRITE_OPERATIONAL_STATE_SCOPE );
	}

	private static function pkce_challenge( string $verifier ): string {
		return rtrim( strtr( base64_encode( hash( 'sha256', $verifier, true ) ), '+/', '-_' ), '=' );
	}

	private static function random_secret(): string {
		return rtrim( strtr( base64_encode( random_bytes( 32 ) ), '+/', '-_' ), '=' );
	}

	private static function secret_hash( string $secret ): string {
		return hash_hmac( 'sha256', $secret, wp_salt( 'auth' ) );
	}

	private static function issuer(): string {
		return untrailingslashit( site_url( '/' ) );
	}

	private static function oauth_error( string $code, string $message, int $status ): WP_Error {
		return new WP_Error( $code, $message, array( 'status' => $status ) );
	}
}
