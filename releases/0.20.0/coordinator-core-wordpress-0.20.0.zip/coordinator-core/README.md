# Coordinator Core WordPress Plugin

This folder contains the clean, project-neutral WordPress plugin.

## Foundation behavior

- Version: 0.20.0
- Adds an administrator-only Coordinator page.
- Adds a persistent Coordinator Workbench with a single contextual next action, cost preview, explicit paid-AI confirmation, saved provider/cost evidence, activity history, and a safe queue boundary before GitHub writes.
- Adds a nonce-protected administrator editor for project-neutral operational state: status, phase, stage, checkpoint progress, current work, blockers, exact next action, and an optional Continue Work link.
- Adds an administrator-only read-only health route at `/wp-json/coordinator-core/v1/health`.
- Adds administrator-only read-only Connector capability, safe site-inventory, and HTTPS-only connection-handshake routes.
- Adds an administrator-only read-only Continue Work status route.
- Uses WordPress native cookie-session or application-password authentication over HTTPS before checking administrator capability.
- Grants only the explicit `coordinator:read` handshake scope and exposes no credential material.
- Implements the OAuth 2.1 authorization-code flow for trusted ChatGPT Client ID Metadata Documents.
- Requires an authenticated WordPress administrator to approve a clear read-only consent screen.
- Requires PKCE S256 and binds each one-time, five-minute authorization code to its client, redirect URI, and MCP resource.
- Issues one-hour bearer tokens, stores only keyed hashes at rest, rechecks the authorizing administrator's permission, and supports revocation.
- Publishes protected-resource and authorization-server metadata over HTTPS with issuer validation enabled.
- Grants OAuth clients `coordinator:read` by default; operational-state, exact-content-edit, nonpublic-draft-creation, nonpublic-media-upload, and advisory-AI permissions remain separate explicit scopes.
- Adds a stateless MCP Streamable HTTP endpoint at `/wp-json/coordinator-core/v1/mcp` with `initialize`, `ping`, `tools/list`, and `tools/call`.
- Exposes authenticated profile, Coordinator status, site inventory, and Continue Work as explicitly read-only MCP tools.
- Adds administrator-only read-only content retrieval for one explicitly selected post ID and one allowlisted field: title, excerpt, or content.
- Adds bounded literal snippet search with line numbers, adjacent context, result limits, and truncation reporting; it cannot read post meta or change content.
- Rejects unknown arguments, non-allowlisted fields, invalid limits, multiline patterns, missing content items, and non-administrator requests.
- Adds a preview-only exact-match edit planner that returns conflict status, occurrence count, expected and proposed SHA-256 hashes, byte changes, and bounded before/after snippets without saving anything.
- Adds a separate `coordinator:write:content` scope for one explicitly confirmed exact-match edit. The apply boundary requires the approved current SHA-256 identity, refuses stale or ambiguous state, forces a distinct WordPress recovery revision before writing even when the latest revision already matches the current content, verifies the saved value, preserves publishing status, returns an audit receipt, and makes safe retries idempotent.
- Adds a separate `coordinator:create:drafts` scope for one explicitly confirmed new page or post in `draft` or `pending` status only. It rejects every other type or status, prevents exact duplicate drafts even across different idempotency keys, recovers safely after an interrupted audit write, verifies title, excerpt, content, type, and status by readback, and returns an idempotent audit receipt.
- Adds read-only rendered verification for one explicitly selected page or post in `draft`, `pending`, or `private` status. It applies the site's normal WordPress content rendering, returns bounded HTML, visible-text evidence, SHA-256 identities, element counts, truncation warnings, and a same-site administrator preview URL only when that URL contains no credential-like parameters. Public content and unrelated post types are rejected.
- Adds a separate `coordinator:upload:media` scope for one explicitly confirmed JPEG, PNG, WebP, or GIF image of at most 5 MiB attached only to one selected draft, pending, or private page/post. It requires non-empty alt text, verifies the file signature against the declared MIME type and filename extension, prevents SHA-256 duplicates, performs readback verification, and returns an idempotent audit receipt without publishing or changing content.
- Preserves the `coordinator_core_continue_work_summary` adapter filter and adds the `coordinator_core_operational_state` filter.
- Performs no publishing-status, plugin, theme, file, user, deployment, or deletion action. Content writes are limited to explicitly confirmed, exact-match, hash-bound replacements with revision recovery and explicitly confirmed creation of new nonpublic drafts; the only external action is explicitly confirmed advisory AI delegation through the bounded router.
- Stores operational state separately and, when configured, stores only the router access token encrypted with WordPress salts. The OpenAI provider key remains exclusively in Cloudflare.
- Deletes no project record during uninstall.
- Uses a public distribution-only repository without storing GitHub credentials in WordPress.
- Accepts update metadata only when its Ed25519 signature, Coordinator identity, release URL, and version fields validate.
- Downloads an approved update through WordPress, verifies its SHA-256 checksum against the signed metadata, and blocks installation on any mismatch.
- Relies on WordPress's administrator approval and native update recovery instead of silently installing releases.
- Adds a separate `coordinator:write:operational-state` OAuth scope and two MCP tools limited to previewing and saving validated Coordinator operational state.
- Requires explicit confirmation and the last-known update timestamp before saving, and returns a non-secret audit receipt.
- Exposes only the narrow confirmed exact-match content edit and nonpublic draft creator; it does not expose publishing-status, plugin, theme, deployment, file, user, or deletion tools.
- Stores only hashed access and refresh tokens in a non-autoloaded durable WordPress option so cache purges do not disconnect ChatGPT.
- Issues rotating 30-day refresh tokens, retains one-hour access tokens, and revokes the token family when refresh-token reuse is detected.

This foundation must pass its offline tests before any practice installation.

- Adds an administrator-only Bounded AI Router setup panel with browser-generated access tokens encrypted at rest using WordPress salts.
- Adds a direct administrator AI Job Console so previewed and explicitly confirmed advisory jobs can run from WordPress even when ChatGPT is unavailable.
- Adds a separate `coordinator:delegate:ai` OAuth scope and MCP preview/run tools for advisory summarize, classify, draft, and review jobs.
- Requires explicit confirmation for paid AI runs and preserves the router's model allowlist, idempotency, per-job budget, and monthly budget enforcement.
- Never stores the OpenAI API key in WordPress or GitHub; only the Cloudflare router holds that provider key.
