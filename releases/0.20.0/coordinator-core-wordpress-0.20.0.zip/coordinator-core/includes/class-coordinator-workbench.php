<?php
/**
 * Persistent administrator Workbench for guided Coordinator jobs.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Workbench {
	public const OPTION = 'coordinator_core_workbench_v1';

	private const HISTORY_LIMIT = 20;
	private const STAGES = array(
		'planning',
		'awaiting_plan_approval',
		'plan_ready',
		'waiting_for_github',
	);

	public static function boot(): void {
		add_action( 'admin_post_coordinator_workbench_action', array( self::class, 'handle_admin_action' ) );
	}

	public static function status(): array {
		$state = self::get_state();
		$job   = $state['active_job'];

		return array(
			'enabled'            => true,
			'mode'               => 'guided-mvp',
			'active_job'         => is_array( $job ),
			'active_job_id'      => is_array( $job ) ? (string) $job['id'] : '',
			'stage'              => is_array( $job ) ? (string) $job['stage'] : 'ready',
			'next_action'        => is_array( $job ) ? self::next_action( (string) $job['stage'] ) : 'start',
			'history_count'      => count( $state['history'] ),
			'github_write_mode'  => 'disabled',
			'installation_mode'  => 'disabled',
		);
	}

	public static function get_state(): array {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) || 1 !== ( $stored['schema_version'] ?? null ) ) {
			return self::empty_state();
		}

		$active = self::normalize_job( $stored['active_job'] ?? null );
		$history = array();
		foreach ( (array) ( $stored['history'] ?? array() ) as $job ) {
			$normalized = self::normalize_job( $job );
			if ( null !== $normalized ) {
				$history[] = $normalized;
			}
		}

		return array(
			'schema_version' => 1,
			'active_job'     => $active,
			'history'        => array_slice( $history, 0, self::HISTORY_LIMIT ),
			'updated_at'     => self::clean_text( $stored['updated_at'] ?? '' ),
		);
	}

	public static function start_job( string $goal, int $user_id ) {
		$goal = trim( $goal );
		if ( '' === $goal || strlen( $goal ) > 4000 ) {
			return new WP_Error( 'workbench_invalid_goal', 'Enter a build goal of 1 to 4,000 characters.' );
		}
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'workbench_forbidden', 'Administrator permission is required.' );
		}

		$state = self::get_state();
		if ( is_array( $state['active_job'] ) ) {
			return new WP_Error( 'workbench_job_active', 'Finish or archive the active Workbench job first.' );
		}

		$now = gmdate( 'c' );
		$job = array(
			'id'                 => 'wb_' . substr( hash( 'sha256', $goal . '|' . $user_id . '|' . $now . '|' . count( $state['history'] ) ), 0, 20 ),
			'goal'               => $goal,
			'stage'              => 'planning',
			'created_at'         => $now,
			'updated_at'         => $now,
			'actor_id'           => $user_id,
			'provider'           => '',
			'estimated_cost_usd' => null,
			'actual_cost_usd'    => null,
			'plan'               => '',
			'preview'            => null,
			'last_error'         => '',
			'events'             => array(
				array(
					'at'      => $now,
					'stage'   => 'planning',
					'message' => 'Workbench job created. No paid AI call has run.',
				),
			),
		);

		$state['active_job'] = $job;
		self::save_state( $state );
		return $job;
	}

	public static function advance_job( string $action, bool $confirmed, int $user_id ) {
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'workbench_forbidden', 'Administrator permission is required.' );
		}

		$state = self::get_state();
		$job   = $state['active_job'];
		if ( ! is_array( $job ) ) {
			return new WP_Error( 'workbench_job_missing', 'There is no active Workbench job.' );
		}

		if ( 'preview_plan' === $action && 'planning' === $job['stage'] ) {
			$request = self::router_job( $job );
			$result  = Coordinator_AI_Router::preview_job( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['preview']            = $result;
			$job['estimated_cost_usd'] = isset( $result['estimated_max_cost_usd'] ) ? (float) $result['estimated_max_cost_usd'] : null;
			$job['stage']              = 'awaiting_plan_approval';
			$job['last_error']         = '';
			self::add_event( $job, 'AI plan cost and routing preview completed. No paid call ran.' );
		} elseif ( 'run_plan' === $action && 'awaiting_plan_approval' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_confirmation_required', 'Confirm the paid advisory planning job first.' );
			}
			$request              = self::router_job( $job );
			$request['confirmed'] = true;
			$result               = Coordinator_AI_Router::run_job( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['plan']            = trim( (string) ( $result['output'] ?? '' ) );
			$job['provider']        = self::clean_text( $result['provider'] ?? '' );
			$job['actual_cost_usd'] = isset( $result['actual_cost_usd'] ) ? (float) $result['actual_cost_usd'] : null;
			$job['stage']           = 'plan_ready';
			$job['last_error']      = '';
			self::add_event( $job, 'Advisory implementation plan generated and saved for review.' );
		} elseif ( 'accept_plan' === $action && 'plan_ready' === $job['stage'] ) {
			$job['stage']      = 'waiting_for_github';
			$job['last_error'] = '';
			self::add_event( $job, 'Plan approved and queued. GitHub writes remain disabled in the Workbench MVP.' );
		} elseif ( 'archive' === $action && 'waiting_for_github' === $job['stage'] ) {
			$job['archived_at'] = gmdate( 'c' );
			self::add_event( $job, 'Planning job archived without a GitHub write.' );
			array_unshift( $state['history'], $job );
			$state['history']    = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
			$state['active_job'] = null;
			self::save_state( $state );
			return array( 'archived' => true, 'job' => $job );
		} else {
			return new WP_Error( 'workbench_invalid_transition', 'That Workbench action is not valid for the current stage.' );
		}

		$job['updated_at']     = gmdate( 'c' );
		$state['active_job']   = $job;
		self::save_state( $state );
		return $job;
	}

	public static function handle_admin_action(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_workbench_action' );

		$user   = wp_get_current_user();
		$action = sanitize_key( wp_unslash( $_POST['workbench_step'] ?? '' ) );
		if ( 'start' === $action ) {
			$goal   = self::posted_string( 'workbench_goal' );
			$result = self::start_job( $goal, (int) $user->ID );
		} else {
			$confirmed = '1' === sanitize_text_field( wp_unslash( $_POST['workbench_confirmed'] ?? '' ) );
			$result    = self::advance_job( $action, $confirmed, (int) $user->ID );
		}

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 400 ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=coordinator-core#coordinator-workbench' ) );
		exit;
	}

	public static function render_admin_section( ?array $summary ): void {
		$state = self::get_state();
		$job   = $state['active_job'];
		$goal  = is_array( $summary ) ? (string) ( $summary['exact_next_action'] ?? '' ) : '';
		?>
		<hr>
		<div id="coordinator-workbench">
			<h2><?php echo esc_html__( 'Coordinator Workbench', 'coordinator-core' ); ?></h2>
			<p><?php echo esc_html__( 'Persistent guided jobs show the current stage, evidence, cost, provider, history, and one safe next action. Closing the browser or reaching a ChatGPT limit does not erase the job.', 'coordinator-core' ); ?></p>
			<div style="max-width:1000px;border:1px solid #c3c4c7;background:#fff;padding:20px;margin:16px 0">
				<?php if ( ! is_array( $job ) ) : ?>
					<h3><?php echo esc_html__( 'Ready for the next build job', 'coordinator-core' ); ?></h3>
					<p><?php echo esc_html__( 'Start from the verified Coordinator next action or edit the goal before creating the persistent job.', 'coordinator-core' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="coordinator_workbench_action">
						<input type="hidden" name="workbench_step" value="start">
						<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
						<label for="workbench_goal"><strong><?php echo esc_html__( 'Build goal', 'coordinator-core' ); ?></strong></label>
						<textarea class="large-text" id="workbench_goal" name="workbench_goal" rows="5" maxlength="4000" required><?php echo esc_textarea( $goal ); ?></textarea>
						<?php submit_button( esc_html__( 'Start Workbench Job', 'coordinator-core' ), 'primary', 'submit', false ); ?>
					</form>
				<?php else : ?>
					<p><strong><?php echo esc_html__( 'Job:', 'coordinator-core' ); ?></strong> <code><?php echo esc_html( (string) $job['id'] ); ?></code></p>
					<p><strong><?php echo esc_html__( 'Stage:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::stage_label( (string) $job['stage'] ) ); ?></p>
					<p><strong><?php echo esc_html__( 'Goal:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $job['goal'] ); ?></p>
					<p><strong><?php echo esc_html__( 'Provider:', 'coordinator-core' ); ?></strong> <?php echo esc_html( '' !== $job['provider'] ? (string) $job['provider'] : __( 'Not used yet', 'coordinator-core' ) ); ?></p>
					<p><strong><?php echo esc_html__( 'Estimated maximum cost:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::money( $job['estimated_cost_usd'] ) ); ?></p>
					<p><strong><?php echo esc_html__( 'Actual cost:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::money( $job['actual_cost_usd'] ) ); ?></p>

					<?php if ( '' !== (string) $job['last_error'] ) : ?>
						<div class="notice notice-error inline"><p><?php echo esc_html( (string) $job['last_error'] ); ?></p></div>
					<?php endif; ?>

					<?php if ( is_array( $job['preview'] ) ) : ?>
						<details>
							<summary><strong><?php echo esc_html__( 'Cost and routing preview', 'coordinator-core' ); ?></strong></summary>
							<pre style="overflow:auto;white-space:pre-wrap"><?php echo esc_html( wp_json_encode( $job['preview'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); ?></pre>
						</details>
					<?php endif; ?>

					<?php if ( '' !== (string) $job['plan'] ) : ?>
						<h3><?php echo esc_html__( 'Saved implementation plan', 'coordinator-core' ); ?></h3>
						<pre style="overflow:auto;white-space:pre-wrap;border:1px solid #dcdcde;padding:12px;background:#f6f7f7"><?php echo esc_html( (string) $job['plan'] ); ?></pre>
					<?php endif; ?>

					<h3><?php echo esc_html__( 'Activity', 'coordinator-core' ); ?></h3>
					<ol>
						<?php foreach ( array_reverse( $job['events'] ) as $event ) : ?>
							<li><strong><?php echo esc_html( (string) $event['at'] ); ?></strong> — <?php echo esc_html( (string) $event['message'] ); ?></li>
						<?php endforeach; ?>
					</ol>

					<?php self::render_next_action( $job ); ?>
				<?php endif; ?>
			</div>

			<?php if ( ! empty( $state['history'] ) ) : ?>
				<h3><?php echo esc_html__( 'Recent Workbench history', 'coordinator-core' ); ?></h3>
				<table class="widefat striped" style="max-width:1000px">
					<thead><tr><th><?php echo esc_html__( 'Job', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Goal', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Last stage', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Updated', 'coordinator-core' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $state['history'] as $past ) : ?>
							<tr><td><code><?php echo esc_html( (string) $past['id'] ); ?></code></td><td><?php echo esc_html( (string) $past['goal'] ); ?></td><td><?php echo esc_html( self::stage_label( (string) $past['stage'] ) ); ?></td><td><?php echo esc_html( (string) $past['updated_at'] ); ?></td></tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_next_action( array $job ): void {
		$next = self::next_action( (string) $job['stage'] );
		if ( 'wait_for_github' === $next ) {
			?>
			<div class="notice notice-warning inline">
				<p><strong><?php echo esc_html__( 'Next connection required:', 'coordinator-core' ); ?></strong> <?php echo esc_html__( 'The approved plan is safely queued. GitHub branch and pull-request writes remain disabled in this MVP and will be connected in the next release.', 'coordinator-core' ); ?></p>
			</div>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="coordinator_workbench_action">
				<input type="hidden" name="workbench_step" value="archive">
				<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
				<?php submit_button( esc_html__( 'Archive Planning Job', 'coordinator-core' ), 'secondary', 'submit', false ); ?>
			</form>
			<?php
			return;
		}

		$labels = array(
			'preview_plan' => __( 'Preview AI Plan Cost', 'coordinator-core' ),
			'run_plan'     => __( 'Run Confirmed AI Plan', 'coordinator-core' ),
			'accept_plan'  => __( 'Approve Plan and Queue Coding', 'coordinator-core' ),
		);
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="coordinator_workbench_action">
			<input type="hidden" name="workbench_step" value="<?php echo esc_attr( $next ); ?>">
			<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
			<?php if ( 'run_plan' === $next ) : ?>
				<p><label><input type="checkbox" name="workbench_confirmed" value="1" required> <?php echo esc_html__( 'I confirm this paid advisory planning job.', 'coordinator-core' ); ?></label></p>
			<?php endif; ?>
			<?php submit_button( esc_html( $labels[ $next ] ?? __( 'Continue', 'coordinator-core' ) ), 'primary', 'submit', false ); ?>
		</form>
		<?php
	}

	private static function router_job( array $job ): array {
		return array(
			'task_type'         => 'draft',
			'instructions'      => 'Create a concise implementation plan for the build goal. Include scope, likely files, tests, risks, approval gates, and the exact next action. Do not claim that code, GitHub, installation, publishing, or deployment actions were performed.',
			'input'             => (string) $job['goal'],
			'model'             => 'gpt-5.6-luna',
			'max_output_tokens' => 1200,
			'idempotency_key'   => 'workbench-' . (string) $job['id'] . '-plan',
		);
	}

	private static function record_error( array $state, array $job, WP_Error $error ) {
		$job['last_error'] = $error->get_error_message();
		self::add_event( $job, 'Step failed safely: ' . $job['last_error'] );
		$job['updated_at']   = gmdate( 'c' );
		$state['active_job'] = $job;
		self::save_state( $state );
		return $error;
	}

	private static function add_event( array &$job, string $message ): void {
		$job['events'][] = array(
			'at'      => gmdate( 'c' ),
			'stage'   => (string) $job['stage'],
			'message' => $message,
		);
		$job['events'] = array_slice( $job['events'], -50 );
	}

	private static function next_action( string $stage ): string {
		$actions = array(
			'planning'               => 'preview_plan',
			'awaiting_plan_approval' => 'run_plan',
			'plan_ready'             => 'accept_plan',
			'waiting_for_github'     => 'wait_for_github',
		);
		return $actions[ $stage ] ?? 'start';
	}

	private static function stage_label( string $stage ): string {
		$labels = array(
			'planning'               => 'Planning',
			'awaiting_plan_approval' => 'Awaiting paid-plan approval',
			'plan_ready'             => 'Plan ready for review',
			'waiting_for_github'     => 'Approved plan queued for GitHub connection',
		);
		return $labels[ $stage ] ?? $stage;
	}

	private static function normalize_job( $job ): ?array {
		if ( ! is_array( $job ) ) {
			return null;
		}
		$id    = self::clean_text( $job['id'] ?? '' );
		$goal  = self::clean_text( $job['goal'] ?? '' );
		$stage = self::clean_text( $job['stage'] ?? '' );
		if ( '' === $id || '' === $goal || ! in_array( $stage, self::STAGES, true ) ) {
			return null;
		}

		$events = array();
		foreach ( (array) ( $job['events'] ?? array() ) as $event ) {
			if ( is_array( $event ) && '' !== self::clean_text( $event['message'] ?? '' ) ) {
				$events[] = array(
					'at'      => self::clean_text( $event['at'] ?? '' ),
					'stage'   => self::clean_text( $event['stage'] ?? '' ),
					'message' => self::clean_text( $event['message'] ?? '' ),
				);
			}
		}

		return array(
			'id'                 => $id,
			'goal'               => $goal,
			'stage'              => $stage,
			'created_at'         => self::clean_text( $job['created_at'] ?? '' ),
			'updated_at'         => self::clean_text( $job['updated_at'] ?? '' ),
			'actor_id'           => (int) ( $job['actor_id'] ?? 0 ),
			'provider'           => self::clean_text( $job['provider'] ?? '' ),
			'estimated_cost_usd' => is_numeric( $job['estimated_cost_usd'] ?? null ) ? (float) $job['estimated_cost_usd'] : null,
			'actual_cost_usd'    => is_numeric( $job['actual_cost_usd'] ?? null ) ? (float) $job['actual_cost_usd'] : null,
			'plan'               => is_string( $job['plan'] ?? null ) ? trim( $job['plan'] ) : '',
			'preview'            => is_array( $job['preview'] ?? null ) ? $job['preview'] : null,
			'last_error'         => self::clean_text( $job['last_error'] ?? '' ),
			'events'             => array_slice( $events, -50 ),
			'archived_at'        => self::clean_text( $job['archived_at'] ?? '' ),
		);
	}

	private static function empty_state(): array {
		return array(
			'schema_version' => 1,
			'active_job'     => null,
			'history'        => array(),
			'updated_at'     => '',
		);
	}

	private static function save_state( array $state ): void {
		$state['schema_version'] = 1;
		$state['updated_at']     = gmdate( 'c' );
		update_option( self::OPTION, $state, false );
	}

	private static function posted_string( string $key ): string {
		$value = wp_unslash( $_POST[ $key ] ?? '' );
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function clean_text( $value ): string {
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function money( $value ): string {
		return is_numeric( $value ) ? '$' . number_format( (float) $value, 6 ) : 'Not available';
	}
}
