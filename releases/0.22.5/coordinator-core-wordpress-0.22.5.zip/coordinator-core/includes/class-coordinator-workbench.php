<?php
/**
 * Persistent administrator Workbench for guided Coordinator jobs.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Workbench {
	public const OPTION = 'coordinator_core_workbench_v1';

	private const HISTORY_LIMIT = 20;
	private const TOTAL_STEPS = 12;
	private const STAGES = array(
		'planning',
		'awaiting_plan_approval',
		'plan_ready',
		'waiting_for_github',
		'github_preview_ready',
		'github_dispatch_queued',
		'github_pr_open',
		'github_ci_passed',
		'awaiting_merge',
		'merged',
		'release_dispatched',
		'release_ready',
		'publication_dispatched',
		'release_published',
		'wordpress_update_ready',
		'verified',
	);

	public static function boot(): void {
		add_action( 'admin_post_coordinator_workbench_action', array( self::class, 'handle_admin_action' ) );
	}

	public static function status(): array {
		$state = self::get_state();
		$job   = $state['active_job'];

		return array(
			'enabled'            => true,
			'mode'               => 'github-delivery-v1',
			'active_job'         => is_array( $job ),
			'active_job_id'      => is_array( $job ) ? (string) $job['id'] : '',
			'stage'              => is_array( $job ) ? (string) $job['stage'] : 'ready',
			'next_action'        => is_array( $job ) ? self::next_action( (string) $job['stage'] ) : 'start',
			'history_count'      => count( $state['history'] ),
			'github_write_mode'  => 'approval-gateway',
			'installation_mode'  => 'disabled',
		);
	}

	public static function get_state(): array {
		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) || 1 !== ( $stored['schema_version'] ?? null ) ) {
			return self::empty_state();
		}

		$active = self::normalize_job( $stored['active_job'] ?? null );
		$history = array();
		foreach ( (array) ( $stored['history'] ?? array() ) as $job ) {
			$normalized = self::normalize_job( $job );
			if ( null !== $normalized ) {
				$history[] = $normalized;
			}
		}

		return array(
			'schema_version' => 1,
			'active_job'     => $active,
			'history'        => array_slice( $history, 0, self::HISTORY_LIMIT ),
			'updated_at'     => self::clean_text( $stored['updated_at'] ?? '' ),
		);
	}

	public static function start_job( string $goal, int $user_id ) {
		$goal = trim( $goal );
		if ( '' === $goal || strlen( $goal ) > 4000 ) {
			return new WP_Error( 'workbench_invalid_goal', 'Enter a build goal of 1 to 4,000 characters.' );
		}
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'workbench_forbidden', 'Administrator permission is required.' );
		}

		$state = self::get_state();
		if ( is_array( $state['active_job'] ) ) {
			return new WP_Error( 'workbench_job_active', 'Finish or archive the active Workbench job first.' );
		}

		$now = gmdate( 'c' );
		$job = array(
			'id'                 => 'wb_' . substr( hash( 'sha256', $goal . '|' . $user_id . '|' . $now . '|' . count( $state['history'] ) ), 0, 20 ),
			'goal'               => $goal,
			'stage'              => 'planning',
			'created_at'         => $now,
			'updated_at'         => $now,
			'actor_id'           => $user_id,
			'provider'           => '',
			'estimated_cost_usd' => null,
			'actual_cost_usd'    => null,
			'plan'               => '',
			'preview'            => null,
			'github_preview'     => null,
			'github_delivery'    => null,
			'last_error'         => '',
			'events'             => array(
				array(
					'at'      => $now,
					'stage'   => 'planning',
					'message' => 'Workbench job created. No paid AI call has run.',
				),
			),
		);

		$state['active_job'] = $job;
		self::save_state( $state );
		return $job;
	}

	public static function advance_job( string $action, bool $confirmed, int $user_id ) {
		if ( $user_id < 1 || ! user_can( $user_id, 'manage_options' ) ) {
			return new WP_Error( 'workbench_forbidden', 'Administrator permission is required.' );
		}

		$state = self::get_state();
		$job   = $state['active_job'];
		if ( ! is_array( $job ) ) {
			return new WP_Error( 'workbench_job_missing', 'There is no active Workbench job.' );
		}

		if ( 'preview_plan' === $action && 'planning' === $job['stage'] ) {
			$request = self::router_job( $job );
			$result  = Coordinator_AI_Router::preview_job( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['preview']            = $result;
			$job['estimated_cost_usd'] = isset( $result['estimated_max_cost_usd'] ) ? (float) $result['estimated_max_cost_usd'] : null;
			$job['stage']              = 'awaiting_plan_approval';
			$job['last_error']         = '';
			self::add_event( $job, 'AI plan cost and routing preview completed. No paid call ran.' );
		} elseif ( 'run_plan' === $action && 'awaiting_plan_approval' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_confirmation_required', 'Confirm the paid advisory planning job first.' );
			}
			$request              = self::router_job( $job );
			$request['confirmed'] = true;
			$result               = Coordinator_AI_Router::run_job( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['plan']            = trim( (string) ( $result['output'] ?? '' ) );
			$job['provider']        = self::clean_text( $result['provider'] ?? '' );
			$job['actual_cost_usd'] = isset( $result['actual_cost_usd'] ) ? (float) $result['actual_cost_usd'] : null;
			$job['stage']           = 'plan_ready';
			$job['last_error']      = '';
			self::add_event( $job, 'Advisory implementation plan generated and saved for review.' );
		} elseif ( 'accept_plan' === $action && 'plan_ready' === $job['stage'] ) {
			$job['stage']      = 'waiting_for_github';
			$job['last_error'] = '';
			self::add_event( $job, 'Plan approved and queued for protected GitHub delivery preview.' );
		} elseif ( 'preview_github' === $action && 'waiting_for_github' === $job['stage'] ) {
			$result = Coordinator_AI_Router::preview_github_delivery( self::github_payload( $job ) );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_preview'] = $result;
			$job['stage']          = 'github_preview_ready';
			$job['last_error']     = '';
			self::add_event( $job, ! empty( $result['actions_enabled'] ) ? 'Protected GitHub delivery preview completed.' : 'GitHub delivery preview completed; gateway activation is still required before dispatch.' );
		} elseif ( 'dispatch_github' === $action && 'github_preview_ready' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_github_confirmation_required', 'Confirm creation of the allowlisted branch and draft pull request first.' );
			}
			$request              = self::github_payload( $job );
			$request['confirmed'] = true;
			$result               = Coordinator_AI_Router::dispatch_github_delivery( $request );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = $result;
			$job['stage']           = 'github_dispatch_queued';
			$job['last_error']      = '';
			self::add_event( $job, 'GitHub delivery was dispatched. Merge and installation remain disabled.' );
		} elseif ( 'refresh_github' === $action && in_array( $job['stage'], array( 'github_dispatch_queued', 'github_pr_open', 'github_ci_passed' ), true ) ) {
			$result = Coordinator_AI_Router::github_delivery_status( (string) $job['id'] );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = $result;
			$delivery_state         = self::clean_text( $result['state'] ?? '' );
			if ( 'ci_passed' === $delivery_state ) {
				$job['stage'] = 'github_ci_passed';
			} elseif ( 'pull_request_open' === $delivery_state ) {
				$job['stage'] = 'github_pr_open';
			} else {
				$job['stage'] = 'github_dispatch_queued';
			}
			$job['last_error'] = '';
			self::add_event( $job, 'GitHub and CI evidence refreshed: ' . ( '' !== $delivery_state ? $delivery_state : 'queued' ) . '.' );
		} elseif ( 'continue_after_ci' === $action && 'github_ci_passed' === $job['stage'] ) {
			$job['stage']      = 'awaiting_merge';
			$job['last_error'] = '';
			self::add_event( $job, 'CI evidence accepted. Merge remains a separate protected action.' );
		} elseif ( 'merge_github' === $action && 'awaiting_merge' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_merge_confirmation_required', 'Confirm the exact protected Workbench merge first.' );
			}
			$result = Coordinator_AI_Router::merge_github_delivery( (string) $job['id'], true );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'merge' => $result ) );
			$job['stage']           = 'merged';
			$job['last_error']      = '';
			self::add_event( $job, 'Exact tested Workbench pull request merged through the protected gateway.' );
		} elseif ( 'release_gate' === $action && 'merged' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_release_confirmation_required', 'Confirm the protected signed release first.' );
			}
			$result = Coordinator_AI_Router::release_github_delivery( (string) $job['id'], true );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'release' => $result ) );
			$job['stage']           = 'release_dispatched';
			$job['last_error']      = '';
			self::add_event( $job, 'Protected signed release build dispatched. Publication and WordPress installation remain separate protected actions.' );
		} elseif ( 'refresh_release' === $action && 'release_dispatched' === $job['stage'] ) {
			$result = Coordinator_AI_Router::github_release_status( (string) $job['id'] );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'release_status' => $result ) );
			$release_state          = self::clean_text( $result['state'] ?? '' );
			if ( 'signed_release_ready' === $release_state ) {
				$job['stage'] = 'release_ready';
			}
			$job['last_error'] = '';
			self::add_event( $job, 'Signed release evidence refreshed: ' . ( '' !== $release_state ? $release_state : 'pending' ) . '.' );
		} elseif ( 'publish_release' === $action && 'release_ready' === $job['stage'] ) {
			if ( ! $confirmed ) {
				return new WP_Error( 'workbench_publication_confirmation_required', 'Confirm the protected release publication first.' );
			}
			$result = Coordinator_AI_Router::publish_github_delivery( (string) $job['id'], true );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'publication' => $result ) );
			$job['stage']           = 'publication_dispatched';
			$job['last_error']      = '';
			self::add_event( $job, 'Protected signed release publication dispatched. WordPress installation remains disabled.' );
		} elseif ( 'refresh_publication' === $action && 'publication_dispatched' === $job['stage'] ) {
			$result = Coordinator_AI_Router::github_publication_status( (string) $job['id'] );
			if ( is_wp_error( $result ) ) {
				return self::record_error( $state, $job, $result );
			}
			$job['github_delivery'] = array_merge( (array) $job['github_delivery'], array( 'publication_status' => $result ) );
			$publication_state      = self::clean_text( $result['state'] ?? '' );
			if ( 'release_published' === $publication_state ) {
				$job['stage'] = 'release_published';
			}
			$job['last_error'] = '';
			self::add_event( $job, 'Release publication evidence refreshed: ' . ( '' !== $publication_state ? $publication_state : 'pending' ) . '.' );
		} elseif ( 'archive' === $action && 'verified' === $job['stage'] ) {
			$job['archived_at'] = gmdate( 'c' );
			self::add_event( $job, 'Verified Workbench job archived after live installation evidence.' );
			array_unshift( $state['history'], $job );
			$state['history']    = array_slice( $state['history'], 0, self::HISTORY_LIMIT );
			$state['active_job'] = null;
			self::save_state( $state );
			return array( 'archived' => true, 'job' => $job );
		} else {
			return new WP_Error( 'workbench_invalid_transition', 'That Workbench action is not valid for the current stage.' );
		}

		$job['updated_at']     = gmdate( 'c' );
		$state['active_job']   = $job;
		self::save_state( $state );
		return $job;
	}

	public static function handle_admin_action(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_workbench_action' );

		$user   = wp_get_current_user();
		$action = sanitize_key( wp_unslash( $_POST['workbench_step'] ?? '' ) );
		if ( 'start' === $action ) {
			$goal   = self::posted_string( 'workbench_goal' );
			$result = self::start_job( $goal, (int) $user->ID );
		} else {
			$confirmed = '1' === sanitize_text_field( wp_unslash( $_POST['workbench_confirmed'] ?? '' ) );
			$result    = self::advance_job( $action, $confirmed, (int) $user->ID );
		}

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 400 ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=coordinator-core#coordinator-workbench' ) );
		exit;
	}

	public static function render_admin_section( ?array $summary ): void {
		$state         = self::get_state();
		$job           = $state['active_job'];
		$goal          = '';
		$router_status = Coordinator_AI_Router::status();
		?>
		<hr>
		<style>
			#coordinator-workbench { max-width: 1000px; margin: 28px 0; color: #172033; }
			#coordinator-workbench * { box-sizing: border-box; }
			.cc-workbench-hero { padding: 24px; border: 1px solid #c7d2fe; border-radius: 18px; background: linear-gradient(135deg, #eff6ff 0%, #eef2ff 52%, #faf5ff 100%); box-shadow: 0 12px 30px rgba(30, 64, 175, .08); }
			.cc-workbench-hero h2 { margin: 0 0 8px; font-size: clamp(24px, 5vw, 34px); line-height: 1.15; }
			.cc-workbench-hero p { max-width: 720px; margin: 0; color: #475569; font-size: 15px; line-height: 1.6; }
			.cc-step-card { margin-top: 18px; padding: clamp(20px, 4vw, 32px); border: 1px solid #dbe4f0; border-radius: 18px; background: #fff; box-shadow: 0 16px 36px rgba(15, 23, 42, .08); }
			.cc-step-top { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 14px; }
			.cc-step-badge { display: inline-flex; align-items: center; min-height: 30px; padding: 5px 11px; border-radius: 999px; background: #1d4ed8; color: #fff; font-size: 12px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; }
			.cc-step-state { color: #166534; font-size: 13px; font-weight: 700; }
			.cc-progress { height: 18px; margin: 0 0 12px; overflow: hidden; border-radius: 999px; background: #e8eef7; }
			.cc-progress span { display: block; height: 100%; border-radius: inherit; background: linear-gradient(90deg, #2563eb, #7c3aed); transition: width .35s ease; }
			.cc-stage-now { margin: 0 0 22px; padding: 12px 14px; border-left: 4px solid #2563eb; border-radius: 8px; background: #f8fafc; color: #334155; font-size: 15px; line-height: 1.5; }
			.cc-stage-now strong { display:block; color:#0f172a; margin-bottom:3px; }
			.cc-stage-complete { margin: 18px 0; padding: 16px; border: 1px solid #bbf7d0; border-radius: 12px; background:#f0fdf4; color:#14532d; }
			.cc-stage-actions { display:flex; gap:10px; flex-wrap:wrap; margin-top:14px; }
			.cc-stage-actions .button { min-height:44px; padding:8px 16px; }
			.cc-step-card h3 { margin: 0 0 10px; color: #0f172a; font-size: clamp(21px, 4vw, 28px); line-height: 1.25; }
			.cc-step-card > p { color: #475569; font-size: 15px; line-height: 1.6; }
			.cc-goal-label { display: block; margin: 22px 0 8px; color: #0f172a; font-size: 14px; }
			#coordinator-workbench textarea { width: 100%; min-height: 132px; padding: 14px; border: 1px solid #94a3b8; border-radius: 12px; background: #f8fafc; font-size: 16px; line-height: 1.5; }
			#coordinator-workbench textarea:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, .16); outline: none; }
			#coordinator-workbench .cc-primary.button { width: 100%; min-height: 48px; margin-top: 8px; padding: 10px 18px; border: 0; border-radius: 12px; background: linear-gradient(90deg, #1d4ed8, #6d28d9); color: #fff; font-size: 15px; font-weight: 700; text-shadow: none; box-shadow: 0 8px 18px rgba(37, 99, 235, .22); }
			#coordinator-workbench .cc-primary.button:hover:not(:disabled), #coordinator-workbench .cc-primary.button:focus:not(:disabled) { background: linear-gradient(90deg, #1e40af, #5b21b6); color: #fff; }
			#coordinator-workbench .cc-primary.button:disabled { background: #cbd5e1; color: #64748b; box-shadow: none; cursor: not-allowed; }
			.cc-confirmation { margin: 20px 0 10px; padding: 14px; border: 1px solid #bfdbfe; border-radius: 12px; background: #eff6ff; color: #1e3a8a; line-height: 1.5; }
			.cc-confirmation input { width: 20px; height: 20px; margin-right: 8px; vertical-align: middle; }
			.cc-step-card .notice { margin: 18px 0; border-radius: 10px; }
			.cc-step-card pre { max-height: 430px; padding: 16px !important; border: 1px solid #dbe4f0 !important; border-radius: 12px; background: #f8fafc !important; color: #1e293b; font-size: 13px; line-height: 1.55; }
			.cc-history { margin-top: 16px; border: 1px solid #dbe4f0; border-radius: 14px; background: #fff; }
			.cc-history summary { padding: 16px 18px; cursor: pointer; color: #334155; font-weight: 700; }
			.cc-history[open] summary { border-bottom: 1px solid #e2e8f0; }
			.cc-history-body { padding: 16px 18px; overflow-x: auto; }
			.cc-history ol { margin-left: 20px; }
			.cc-history li { margin-bottom: 10px; line-height: 1.45; }
			.cc-history table { min-width: 680px; border: 0; box-shadow: none; }
			@media (max-width: 600px) {
				.cc-workbench-hero { padding: 20px; border-radius: 14px; }
				.cc-step-card { padding: 20px 16px; border-radius: 14px; }
				.cc-step-top { align-items: flex-start; flex-direction: column; }
				.cc-history-body { padding: 12px; }
			}
		</style>
		<div id="coordinator-workbench">
			<div class="cc-workbench-hero">
				<h2><?php echo esc_html__( 'Coordinator Workbench', 'coordinator-core' ); ?></h2>
				<p><?php echo esc_html__( 'Give Coordinator a build goal, then follow the current stage here. Routine work stays in the background. The Workbench stops between stages with a plain-English summary and asks for you only when needed. Closing the browser or reaching a ChatGPT limit does not erase the job.', 'coordinator-core' ); ?></p>
			</div>
			<div class="cc-step-card">
				<?php if ( ! is_array( $job ) ) : ?>
					<div class="cc-step-top"><span class="cc-step-badge"><?php echo esc_html__( 'Step 1 of 8', 'coordinator-core' ); ?></span><span class="cc-step-state"><?php echo esc_html__( 'Ready', 'coordinator-core' ); ?></span></div>
					<div class="cc-progress" aria-label="<?php echo esc_attr( __( 'Workbench progress', 'coordinator-core' ) ); ?>"><span style="width:12.5%"></span></div>
					<h3><?php echo esc_html__( 'Choose the next build goal', 'coordinator-core' ); ?></h3>
					<p><?php echo esc_html__( 'Enter a new build goal below. Coordinator status instructions are never copied into this field.', 'coordinator-core' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="coordinator_workbench_action">
						<input type="hidden" name="workbench_step" value="start">
						<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
						<label class="cc-goal-label" for="workbench_goal"><strong><?php echo esc_html__( 'Build goal', 'coordinator-core' ); ?></strong></label>
						<textarea class="large-text" id="workbench_goal" name="workbench_goal" rows="5" maxlength="4000" required><?php echo esc_textarea( $goal ); ?></textarea>
						<p><button class="button button-primary cc-primary" id="coordinator_start_workbench_job" type="submit" disabled><?php echo esc_html__( 'Start Workbench Job', 'coordinator-core' ); ?></button></p>
					</form>
					<script>
					(function () {
						const goal = document.getElementById('workbench_goal');
						const button = document.getElementById('coordinator_start_workbench_job');
						if (!goal || !button) { return; }
						const update = function () { button.disabled = goal.value.trim().length < 1; };
						goal.addEventListener('input', update);
						update();
					}());
					</script>
				<?php else : ?>
					<?php self::render_current_step( $job, $router_status ); ?>
					<details class="cc-history">
						<summary><?php echo esc_html__( 'Job details and past activity', 'coordinator-core' ); ?></summary>
						<div class="cc-history-body">
						<p><strong><?php echo esc_html__( 'Job:', 'coordinator-core' ); ?></strong> <code><?php echo esc_html( (string) $job['id'] ); ?></code></p>
						<p><strong><?php echo esc_html__( 'Goal:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $job['goal'] ); ?></p>
						<ol>
							<?php foreach ( array_reverse( $job['events'] ) as $event ) : ?>
								<li><strong><?php echo esc_html( (string) $event['at'] ); ?></strong> — <?php echo esc_html( (string) $event['message'] ); ?></li>
							<?php endforeach; ?>
						</ol>
						</div>
					</details>
				<?php endif; ?>
			</div>

			<?php if ( ! empty( $state['history'] ) ) : ?>
				<details class="cc-history">
					<summary><?php echo esc_html__( 'Completed Workbench jobs', 'coordinator-core' ); ?></summary>
					<div class="cc-history-body">
				<table class="widefat striped">
					<thead><tr><th><?php echo esc_html__( 'Job', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Goal', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Last stage', 'coordinator-core' ); ?></th><th><?php echo esc_html__( 'Updated', 'coordinator-core' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $state['history'] as $past ) : ?>
							<tr><td><code><?php echo esc_html( (string) $past['id'] ); ?></code></td><td><?php echo esc_html( (string) $past['goal'] ); ?></td><td><?php echo esc_html( self::stage_label( (string) $past['stage'] ) ); ?></td><td><?php echo esc_html( (string) $past['updated_at'] ); ?></td></tr>
						<?php endforeach; ?>
					</tbody>
				</table>
					</div>
				</details>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_current_step( array $job, array $router_status ): void {
		$next = self::next_action( (string) $job['stage'] );
		$ready = self::action_readiness( $job, $next, $router_status );
		$step_number = self::step_number( $next );
		?>
		<div class="cc-step-top"><span class="cc-step-badge"><?php echo esc_html( sprintf( __( 'Step %1$d of %2$d', 'coordinator-core' ), $step_number, self::TOTAL_STEPS ) ); ?></span><span class="cc-step-state"><?php echo esc_html( sprintf( __( 'Current step: %s', 'coordinator-core' ), $ready['ready'] ? __( 'Ready', 'coordinator-core' ) : __( 'Waiting', 'coordinator-core' ) ) ); ?></span></div>
		<div class="cc-progress" aria-label="<?php echo esc_attr( __( 'Current stage progress', 'coordinator-core' ) ); ?>"><span style="width:<?php echo esc_attr( (string) self::stage_progress( $next ) ); ?>%"></span></div>
		<div class="cc-stage-now" aria-live="polite"><strong><?php echo esc_html__( 'Working on now', 'coordinator-core' ); ?></strong><?php echo esc_html( self::stage_activity( $next ) ); ?></div>
		<h3><?php echo esc_html( self::step_title( $next ) ); ?></h3>
		<p><?php echo esc_html( self::step_help( $next ) ); ?></p>
		<?php if ( '' !== (string) $job['last_error'] ) : ?>
			<div class="notice notice-error inline"><p><strong><?php echo esc_html__( 'This step did not finish:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $job['last_error'] ); ?> <?php echo esc_html__( 'The saved job is safe. Retry only this step.', 'coordinator-core' ); ?></p></div>
		<?php endif; ?>
		<?php
		self::render_step_evidence( $job, $next );

		$checkpoint = self::checkpoint_state( $job, $next, $ready );
		if ( '' !== $checkpoint['mode'] ) {
			?>
			<div class="cc-stage-complete" aria-live="polite">
				<strong><?php echo esc_html( $checkpoint['title'] ); ?></strong>
				<p><?php echo esc_html( $checkpoint['summary'] ); ?></p>
				<div class="cc-stage-actions">
					<?php if ( '' !== $checkpoint['show_url'] ) : ?><a class="button" href="<?php echo esc_url( $checkpoint['show_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Show Me', 'coordinator-core' ); ?></a><?php endif; ?>
					<?php if ( 'next' === $checkpoint['mode'] ) : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="coordinator_workbench_action"><input type="hidden" name="workbench_step" value="<?php echo esc_attr( $next ); ?>"><?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
							<button class="button button-primary cc-primary" type="submit"><?php echo esc_html__( 'Next', 'coordinator-core' ); ?></button>
						</form>
					<?php else : ?><span class="button button-primary cc-primary" aria-disabled="true"><?php echo esc_html__( 'Need You', 'coordinator-core' ); ?></span><?php endif; ?>
				</div>
			</div>
			<?php
			if ( 'next' === $checkpoint['mode'] ) { return; }
		}

		if ( 'archive' === $next ) {
			?>
			<div class="notice notice-success inline">
				<p><strong><?php echo esc_html__( 'Delivery evidence is ready.', 'coordinator-core' ); ?></strong> <?php echo esc_html__( 'CI passed. Merge and WordPress installation still require separate approval outside this release.', 'coordinator-core' ); ?></p>
			</div>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="coordinator_workbench_action">
				<input type="hidden" name="workbench_step" value="archive">
				<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
				<p><button class="button button-primary cc-primary" type="submit" <?php disabled( ! $ready['ready'] ); ?>><?php echo esc_html__( 'Archive Completed Job', 'coordinator-core' ); ?></button></p>
			</form>
			<?php
			return;
		}

		$labels = array(
			'preview_plan'    => __( 'Preview AI Plan Cost', 'coordinator-core' ),
			'run_plan'        => __( 'Run Confirmed AI Plan', 'coordinator-core' ),
			'accept_plan'     => __( 'Approve Plan and Queue Coding', 'coordinator-core' ),
			'preview_github'  => __( 'Preview GitHub Delivery', 'coordinator-core' ),
			'dispatch_github' => __( 'Create Delivery Branch and Draft PR', 'coordinator-core' ),
			'refresh_github'  => __( 'Refresh GitHub and CI Status', 'coordinator-core' ),
			'continue_after_ci' => __( 'Continue to Protected Merge', 'coordinator-core' ),
			'merge_github' => __( 'Run Protected Merge', 'coordinator-core' ),
			'release_gate' => __( 'Build Signed Release', 'coordinator-core' ),
			'refresh_release' => __( 'Check Signed Release Status', 'coordinator-core' ),
			'publish_release' => __( 'Publish Signed Release', 'coordinator-core' ),
			'refresh_publication' => __( 'Check Publication Status', 'coordinator-core' ),
		);
		$confirmation_id = 'coordinator_confirm_' . sanitize_html_class( $next );
		?>
		<?php if ( ! $ready['ready'] ) : ?>
			<div class="notice notice-warning inline"><p><?php echo esc_html( $ready['reason'] ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="coordinator_workbench_action">
			<input type="hidden" name="workbench_step" value="<?php echo esc_attr( $next ); ?>">
			<?php wp_nonce_field( 'coordinator_workbench_action' ); ?>
			<?php if ( 'run_plan' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I confirm this paid advisory planning job.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'dispatch_github' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I confirm creation of the allowlisted GitHub branch and draft pull request.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'merge_github' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I give explicit confirmation to merge this exact tested Workbench pull request through the independent merge gate.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'release_gate' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I give explicit confirmation to build the signed release for this exact merged Workbench job. Publication and WordPress installation remain separate protected actions.', 'coordinator-core' ); ?></label></p>
			<?php elseif ( 'publish_release' === $next ) : ?>
				<p class="cc-confirmation"><label><input id="<?php echo esc_attr( $confirmation_id ); ?>" type="checkbox" name="workbench_confirmed" value="1" required <?php disabled( ! $ready['ready'] ); ?>> <?php echo esc_html__( 'I give explicit confirmation to publish this exact signed Workbench release. WordPress installation remains a separate protected action.', 'coordinator-core' ); ?></label></p>
			<?php endif; ?>
			<p><button class="button button-primary cc-primary" id="coordinator_current_step_button" type="submit" <?php disabled( ! $ready['ready'] || in_array( $next, array( 'run_plan', 'dispatch_github', 'merge_github', 'release_gate', 'publish_release' ), true ) ); ?>><?php echo esc_html( $labels[ $next ] ?? __( 'Continue', 'coordinator-core' ) ); ?></button></p>
		</form>
		<?php if ( $ready['ready'] && in_array( $next, array( 'run_plan', 'dispatch_github', 'merge_github', 'release_gate', 'publish_release' ), true ) ) : ?>
			<script>
			(function () {
				const confirmation = document.getElementById(<?php echo wp_json_encode( $confirmation_id ); ?>);
				const button = document.getElementById('coordinator_current_step_button');
				if (!confirmation || !button) { return; }
				const update = function () { button.disabled = !confirmation.checked; };
				confirmation.addEventListener('change', update);
				update();
			}());
			</script>
		<?php endif; ?>
		<?php
	}

	private static function checkpoint_state( array $job, string $next, array $ready ): array {
		$mode = '';
		$title = '';
		$summary = '';
		$show_url = '';
		if ( ! empty( $job['github_delivery']['pull_request']['url'] ) ) { $show_url = (string) $job['github_delivery']['pull_request']['url']; }
		if ( $ready['ready'] && in_array( $next, array( 'accept_plan', 'continue_after_ci' ), true ) ) {
			$mode = 'next';
			$title = __( 'Stage Complete', 'coordinator-core' );
			$summary = 'accept_plan' === $next ? __( 'The plan is prepared and saved. Press Next when you want Coordinator to begin the protected build stage.', 'coordinator-core' ) : __( 'The build work passed its required checks. Review it with Show Me when available, then press Next to move to the protected completion stage.', 'coordinator-core' );
		} elseif ( $ready['ready'] && in_array( $next, array( 'run_plan', 'dispatch_github', 'merge_github', 'release_gate', 'publish_release' ), true ) ) {
			$mode = 'need_you';
			$title = __( 'Need You', 'coordinator-core' );
			$summary = __( 'This is a protected checkpoint that requires your confirmation. Review the instruction below; routine internal work does not need separate approval.', 'coordinator-core' );
		} elseif ( ! $ready['ready'] && in_array( $next, array( 'wordpress_update_gate', 'verify_installation' ), true ) ) {
			$mode = 'need_you';
			$title = __( 'Need You', 'coordinator-core' );
			$summary = (string) $ready['reason'];
		}
		return array( 'mode' => $mode, 'title' => $title, 'summary' => $summary, 'show_url' => $show_url );
	}

	private static function action_readiness( array $job, string $next, array $router_status ): array {
		$ready  = false;
		$reason = __( 'This step is waiting for its required information.', 'coordinator-core' );

		if ( 'preview_plan' === $next ) {
			$ready  = ! empty( $router_status['configured'] ) && '' !== trim( (string) $job['goal'] );
			$reason = __( 'Connect the bounded AI router and save a build goal before previewing.', 'coordinator-core' );
		} elseif ( 'run_plan' === $next ) {
			$ready  = is_array( $job['preview'] );
			$reason = __( 'The free cost preview must finish before a paid plan can run.', 'coordinator-core' );
		} elseif ( 'accept_plan' === $next ) {
			$ready  = '' !== trim( (string) $job['plan'] );
			$reason = __( 'A saved plan is required before coding can be approved.', 'coordinator-core' );
		} elseif ( 'preview_github' === $next ) {
			$ready  = ! empty( $router_status['configured'] ) && '' !== trim( (string) $job['plan'] );
			$reason = __( 'The router connection and an approved plan are required first.', 'coordinator-core' );
		} elseif ( 'dispatch_github' === $next ) {
			$ready  = is_array( $job['github_preview'] ) && ! empty( $job['github_preview']['actions_enabled'] );
			$reason = __( 'GitHub delivery must be configured and pass its free preview first.', 'coordinator-core' );
		} elseif ( 'refresh_github' === $next ) {
			$ready  = is_array( $job['github_delivery'] );
			$reason = __( 'A GitHub delivery must be dispatched before its status can be refreshed.', 'coordinator-core' );
		} elseif ( 'continue_after_ci' === $next ) {
			$ready  = 'github_ci_passed' === (string) $job['stage'];
			$reason = __( 'Both required GitHub checks must pass before the protected merge stage.', 'coordinator-core' );
		} elseif ( 'merge_github' === $next ) {
			$ready  = 'awaiting_merge' === (string) $job['stage'];
			$reason = __( 'Protected merge requires explicit confirmation. The gateway remains fail-closed unless its independent merge gate is enabled.', 'coordinator-core' );
		} elseif ( 'release_gate' === $next ) {
			$ready  = 'merged' === (string) $job['stage'];
			$reason = __( 'The exact Workbench merge must complete before the protected signed release can run.', 'coordinator-core' );
		} elseif ( 'refresh_release' === $next ) {
			$ready  = 'release_dispatched' === (string) $job['stage'];
			$reason = __( 'The signed release must be dispatched before its workflow status can be checked.', 'coordinator-core' );
		} elseif ( 'publish_release' === $next ) {
			$ready  = 'release_ready' === (string) $job['stage'];
			$reason = __( 'The exact signed release must be ready before protected publication.', 'coordinator-core' );
		} elseif ( 'refresh_publication' === $next ) {
			$ready  = 'publication_dispatched' === (string) $job['stage'];
			$reason = __( 'Publication must be dispatched before its exact workflow status can be checked.', 'coordinator-core' );
		} elseif ( 'wordpress_update_gate' === $next ) {
			$reason = __( 'WordPress installation is a separate protected action. WPVibe must remain active.', 'coordinator-core' );
		} elseif ( 'verify_installation' === $next ) {
			$reason = __( 'Installation verification must confirm the expected Coordinator Core version and that WPVibe remains active.', 'coordinator-core' );
		} elseif ( 'archive' === $next ) {
			$ready  = 'verified' === (string) $job['stage'];
			$reason = __( 'Verified installation evidence is required before this job can be archived.', 'coordinator-core' );
		}

		return array( 'ready' => $ready, 'reason' => $reason );
	}

	private static function stage_progress( string $next ): int {
		$progress = array(
			'preview_plan' => 15, 'run_plan' => 55, 'accept_plan' => 100,
			'preview_github' => 10, 'dispatch_github' => 30, 'refresh_github' => 75, 'continue_after_ci' => 100,
			'merge_github' => 35, 'release_gate' => 55, 'refresh_release' => 70, 'publish_release' => 82, 'refresh_publication' => 100,
			'wordpress_update_gate' => 35, 'verify_installation' => 85, 'archive' => 100,
		);
		return $progress[ $next ] ?? 0;
	}

	private static function stage_activity( string $next ): string {
		$activity = array(
			'preview_plan' => __( 'Preparing the build stage.', 'coordinator-core' ),
			'run_plan' => __( 'Preparing the work to be completed.', 'coordinator-core' ),
			'accept_plan' => __( 'Stage preparation is complete and ready for your checkpoint.', 'coordinator-core' ),
			'preview_github' => __( 'Preparing the protected coding workspace.', 'coordinator-core' ),
			'dispatch_github' => __( 'Creating the isolated work area.', 'coordinator-core' ),
			'refresh_github' => __( 'Working and running automatic safety checks.', 'coordinator-core' ),
			'continue_after_ci' => __( 'Build work passed its checks and is ready for the stage checkpoint.', 'coordinator-core' ),
			'merge_github' => __( 'Finalizing the tested work.', 'coordinator-core' ),
			'release_gate' => __( 'Building the verified release.', 'coordinator-core' ),
			'refresh_release' => __( 'Verifying the release build.', 'coordinator-core' ),
			'publish_release' => __( 'Publishing the verified release.', 'coordinator-core' ),
			'refresh_publication' => __( 'Release stage is complete and ready for your checkpoint.', 'coordinator-core' ),
			'wordpress_update_gate' => __( 'Waiting for the protected site update.', 'coordinator-core' ),
			'verify_installation' => __( 'Checking the installed result.', 'coordinator-core' ),
			'archive' => __( 'Site verification is complete.', 'coordinator-core' ),
		);
		return $activity[ $next ] ?? __( 'Waiting for the next safe action.', 'coordinator-core' );
	}

	private static function step_number( string $next ): int {
		$steps = array(
			'preview_plan'    => 2,
			'run_plan'        => 3,
			'accept_plan'     => 4,
			'preview_github'  => 5,
			'dispatch_github' => 6,
			'refresh_github'  => 7,
			'continue_after_ci' => 8,
			'merge_github' => 9,
			'release_gate' => 10,
			'refresh_release' => 10,
			'publish_release' => 10,
			'refresh_publication' => 10,
			'wordpress_update_gate' => 11,
			'verify_installation' => 12,
			'archive' => 12,
		);
		return $steps[ $next ] ?? 1;
	}

	private static function step_title( string $next ): string {
		$titles = array(
			'preview_plan'    => __( 'Check the plan cost', 'coordinator-core' ),
			'run_plan'        => __( 'Create the implementation plan', 'coordinator-core' ),
			'accept_plan'     => __( 'Review and approve the plan', 'coordinator-core' ),
			'preview_github'  => __( 'Check the GitHub delivery', 'coordinator-core' ),
			'dispatch_github' => __( 'Create the coding pull request', 'coordinator-core' ),
			'refresh_github'  => __( 'Check the coding and safety tests', 'coordinator-core' ),
			'continue_after_ci' => __( 'Move to protected merge', 'coordinator-core' ),
			'merge_github' => __( 'Merge the tested coding pull request', 'coordinator-core' ),
			'release_gate' => __( 'Build the signed release', 'coordinator-core' ),
			'refresh_release' => __( 'Check the signed release build', 'coordinator-core' ),
			'publish_release' => __( 'Publish the signed release', 'coordinator-core' ),
			'refresh_publication' => __( 'Check release publication', 'coordinator-core' ),
			'wordpress_update_gate' => __( 'Install the verified WordPress update', 'coordinator-core' ),
			'verify_installation' => __( 'Verify the live installation', 'coordinator-core' ),
			'archive' => __( 'Archive the completed job', 'coordinator-core' ),
		);
		return $titles[ $next ] ?? __( 'Wait for the next safe step', 'coordinator-core' );
	}

	private static function step_help( string $next ): string {
		$help = array(
			'preview_plan'    => __( 'This free check confirms the model, budget, and maximum cost. It does not spend money.', 'coordinator-core' ),
			'run_plan'        => __( 'Review the maximum cost, check the confirmation box, and run one paid advisory planning job.', 'coordinator-core' ),
			'accept_plan'     => __( 'Read the plan below. Approval allows the next GitHub preview but does not merge, deploy, or install anything.', 'coordinator-core' ),
			'preview_github'  => __( 'This free check confirms the repository, branch, permissions, and safety boundaries.', 'coordinator-core' ),
			'dispatch_github' => __( 'Confirm creation of one allowlisted branch and one draft pull request. Merge and WordPress installation remain disabled.', 'coordinator-core' ),
			'refresh_github'  => __( 'Refresh until the draft pull request and both required safety checks are finished.', 'coordinator-core' ),
			'continue_after_ci' => __( 'CI passed. Continue into the protected completion pipeline; this does not merge anything by itself.', 'coordinator-core' ),
			'merge_github' => __( 'This sends the exact Workbench job to the protected merge gateway. The gateway re-verifies the branch, pull request, head SHA, base branch, and required CI before merging.', 'coordinator-core' ),
			'release_gate' => __( 'Create the signed release only after the tested pull request is merged. Publication remains a separate protected action.', 'coordinator-core' ),
			'refresh_release' => __( 'Check the exact signed-release workflow for this Workbench job. Publication stays locked until that build succeeds.', 'coordinator-core' ),
			'publish_release' => __( 'Publish only the exact signed Workbench release through the independent protected publication gate. WordPress installation remains disabled.', 'coordinator-core' ),
			'refresh_publication' => __( 'Check the exact publication workflow for this Workbench job. Step 11 stays locked until publication succeeds.', 'coordinator-core' ),
			'wordpress_update_gate' => __( 'Install only the verified Coordinator Core release. WPVibe remains active.', 'coordinator-core' ),
			'verify_installation' => __( 'Confirm the expected Coordinator Core version is active and WPVibe is still active before completion.', 'coordinator-core' ),
			'archive' => __( 'All completion evidence is verified. Archiving moves this job into history and makes room for the next job.', 'coordinator-core' ),
		);
		return $help[ $next ] ?? __( 'This action is not available yet.', 'coordinator-core' );
	}

	private static function render_step_evidence( array $job, string $next ): void {
		if ( 'run_plan' === $next && is_array( $job['preview'] ) ) {
			?><p><strong><?php echo esc_html__( 'Maximum cost:', 'coordinator-core' ); ?></strong> <?php echo esc_html( self::money( $job['estimated_cost_usd'] ) ); ?> &nbsp; <strong><?php echo esc_html__( 'Model:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['preview']['normalized_job']['model'] ?? 'gpt-5.6-luna' ) ); ?></p><?php
		} elseif ( 'accept_plan' === $next && '' !== (string) $job['plan'] ) {
			?><pre style="overflow:auto;white-space:pre-wrap;border:1px solid #dcdcde;padding:12px;background:#f6f7f7"><?php echo esc_html( (string) $job['plan'] ); ?></pre><?php
		} elseif ( 'dispatch_github' === $next && is_array( $job['github_preview'] ) ) {
			?><p><strong><?php echo esc_html__( 'Repository:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['github_preview']['repository'] ?? 'Not configured' ) ); ?><br><strong><?php echo esc_html__( 'Delivery branch:', 'coordinator-core' ); ?></strong> <code><?php echo esc_html( (string) ( $job['github_preview']['branch'] ?? '' ) ); ?></code></p><?php
		} elseif ( in_array( $next, array( 'refresh_github', 'github_ci_ready' ), true ) && is_array( $job['github_delivery'] ) ) {
			?><p><strong><?php echo esc_html__( 'Delivery state:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['github_delivery']['state'] ?? 'queued' ) ); ?><br><strong><?php echo esc_html__( 'CI:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) ( $job['github_delivery']['ci_state'] ?? $job['github_delivery']['ci'] ?? 'pending' ) ); ?></p><?php
			if ( ! empty( $job['github_delivery']['pull_request']['url'] ) ) {
				?><p><a href="<?php echo esc_url( (string) $job['github_delivery']['pull_request']['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html__( 'Review the draft pull request', 'coordinator-core' ); ?></a></p><?php
			}
		}
	}

	private static function github_payload( array $job ): array {
		return array(
			'job_id' => (string) $job['id'],
			'goal'   => (string) $job['goal'],
			'plan'   => (string) $job['plan'],
		);
	}

	private static function router_job( array $job ): array {
		return array(
			'task_type'         => 'draft',
			'instructions'      => 'Create a concise implementation plan for the build goal. Include scope, likely files, tests, risks, approval gates, and the exact next action. Do not claim that code, GitHub, installation, publishing, or deployment actions were performed.',
			'input'             => (string) $job['goal'],
			'model'             => 'gpt-5.6-luna',
			'max_output_tokens' => 1200,
			'idempotency_key'   => 'workbench-' . (string) $job['id'] . '-plan',
		);
	}

	private static function record_error( array $state, array $job, WP_Error $error ) {
		$job['last_error'] = $error->get_error_message();
		self::add_event( $job, 'Step failed safely: ' . $job['last_error'] );
		$job['updated_at']   = gmdate( 'c' );
		$state['active_job'] = $job;
		self::save_state( $state );
		return $error;
	}

	private static function add_event( array &$job, string $message ): void {
		$job['events'][] = array(
			'at'      => gmdate( 'c' ),
			'stage'   => (string) $job['stage'],
			'message' => $message,
		);
		$job['events'] = array_slice( $job['events'], -50 );
	}

	private static function next_action( string $stage ): string {
		$actions = array(
			'planning'               => 'preview_plan',
			'awaiting_plan_approval' => 'run_plan',
			'plan_ready'             => 'accept_plan',
			'waiting_for_github'     => 'preview_github',
			'github_preview_ready'    => 'dispatch_github',
			'github_dispatch_queued'  => 'refresh_github',
			'github_pr_open'          => 'refresh_github',
			'github_ci_passed'        => 'continue_after_ci',
			'awaiting_merge'          => 'merge_github',
			'merged'                  => 'release_gate',
			'release_dispatched'      => 'refresh_release',
			'release_ready'           => 'publish_release',
			'publication_dispatched' => 'refresh_publication',
			'release_published'       => 'wordpress_update_gate',
			'wordpress_update_ready'  => 'verify_installation',
			'verified'                => 'archive',
		);
		return $actions[ $stage ] ?? 'start';
	}

	private static function stage_label( string $stage ): string {
		$labels = array(
			'planning'               => 'Planning',
			'awaiting_plan_approval' => 'Awaiting paid-plan approval',
			'plan_ready'             => 'Plan ready for review',
			'waiting_for_github'     => 'Approved plan queued for GitHub delivery preview',
			'github_preview_ready'    => 'GitHub delivery ready for approval',
			'github_dispatch_queued'  => 'GitHub delivery dispatched',
			'github_pr_open'          => 'Draft pull request open; CI pending',
			'github_ci_passed'        => 'Draft pull request open; CI passed',
			'awaiting_merge'          => 'CI passed; protected merge pending',
			'merged'                  => 'Merged; signed release pending',
			'release_dispatched'      => 'Signed release building',
			'release_ready'           => 'Signed release ready; protected publication pending',
			'publication_dispatched' => 'Release publication running',
			'release_published'       => 'Release published; WordPress update pending',
			'wordpress_update_ready'  => 'WordPress update installed; verification pending',
			'verified'                => 'Live installation verified',
		);
		return $labels[ $stage ] ?? $stage;
	}

	private static function normalize_job( $job ): ?array {
		if ( ! is_array( $job ) ) {
			return null;
		}
		$id    = self::clean_text( $job['id'] ?? '' );
		$goal  = self::clean_text( $job['goal'] ?? '' );
		$stage = self::clean_text( $job['stage'] ?? '' );
		if ( '' === $id || '' === $goal || ! in_array( $stage, self::STAGES, true ) ) {
			return null;
		}

		$events = array();
		foreach ( (array) ( $job['events'] ?? array() ) as $event ) {
			if ( is_array( $event ) && '' !== self::clean_text( $event['message'] ?? '' ) ) {
				$events[] = array(
					'at'      => self::clean_text( $event['at'] ?? '' ),
					'stage'   => self::clean_text( $event['stage'] ?? '' ),
					'message' => self::clean_text( $event['message'] ?? '' ),
				);
			}
		}

		return array(
			'id'                 => $id,
			'goal'               => $goal,
			'stage'              => $stage,
			'created_at'         => self::clean_text( $job['created_at'] ?? '' ),
			'updated_at'         => self::clean_text( $job['updated_at'] ?? '' ),
			'actor_id'           => (int) ( $job['actor_id'] ?? 0 ),
			'provider'           => self::clean_text( $job['provider'] ?? '' ),
			'estimated_cost_usd' => is_numeric( $job['estimated_cost_usd'] ?? null ) ? (float) $job['estimated_cost_usd'] : null,
			'actual_cost_usd'    => is_numeric( $job['actual_cost_usd'] ?? null ) ? (float) $job['actual_cost_usd'] : null,
			'plan'               => is_string( $job['plan'] ?? null ) ? trim( $job['plan'] ) : '',
			'preview'            => is_array( $job['preview'] ?? null ) ? $job['preview'] : null,
			'github_preview'     => is_array( $job['github_preview'] ?? null ) ? $job['github_preview'] : null,
			'github_delivery'    => is_array( $job['github_delivery'] ?? null ) ? $job['github_delivery'] : null,
			'last_error'         => self::clean_text( $job['last_error'] ?? '' ),
			'events'             => array_slice( $events, -50 ),
			'archived_at'        => self::clean_text( $job['archived_at'] ?? '' ),
		);
	}

	private static function empty_state(): array {
		return array(
			'schema_version' => 1,
			'active_job'     => null,
			'history'        => array(),
			'updated_at'     => '',
		);
	}

	private static function save_state( array $state ): void {
		$state['schema_version'] = 1;
		$state['updated_at']     = gmdate( 'c' );
		update_option( self::OPTION, $state, false );
	}

	private static function posted_string( string $key ): string {
		$value = wp_unslash( $_POST[ $key ] ?? '' );
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function clean_text( $value ): string {
		return is_string( $value ) ? trim( $value ) : '';
	}

	private static function money( $value ): string {
		return is_numeric( $value ) ? '$' . number_format( (float) $value, 6 ) : 'Not available';
	}
}
