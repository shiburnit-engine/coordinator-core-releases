<?php
/**
 * Stateless MCP Streamable HTTP server with narrow approval-controlled boundaries.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_MCP_Server {
	private const REST_NAMESPACE  = 'coordinator-core/v1';
	private const LATEST_PROTOCOL = '2025-11-25';
	private const PROTOCOLS       = array( '2025-11-25', '2025-06-18', '2025-03-26' );

	public static function register_rest_route(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/mcp',
			array(
				'methods'             => array( WP_REST_Server::READABLE, WP_REST_Server::CREATABLE ),
				'callback'            => array( self::class, 'handle_request' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public static function handle_request( WP_REST_Request $request ) {
		if ( ! Coordinator_Authentication::is_secure_request() ) {
			return self::http_error( 403, 'HTTPS is required.' );
		}

		if ( ! self::origin_is_allowed( (string) $request->get_header( 'origin' ) ) ) {
			return self::http_error( 403, 'The request Origin is not allowed.' );
		}

		if ( 'GET' === strtoupper( $request->get_method() ) ) {
			return self::http_error( 405, 'Server-sent event streams are not supported by this stateless endpoint.', array( 'Allow' => 'POST' ) );
		}

		if ( ! self::accepts_mcp_response( (string) $request->get_header( 'accept' ) ) ) {
			return self::http_error( 406, 'Accept must include application/json and text/event-stream.' );
		}

		$message = $request->get_json_params();
		if ( ! is_array( $message ) || array_is_list( $message ) || '2.0' !== ( $message['jsonrpc'] ?? null ) || ! is_string( $message['method'] ?? null ) ) {
			return self::jsonrpc_error( $message['id'] ?? null, -32600, 'Invalid Request', 400 );
		}

		$method = $message['method'];
		if ( 'initialize' !== $method && ! str_starts_with( $method, 'notifications/' ) ) {
			$protocol = trim( (string) $request->get_header( 'mcp-protocol-version' ) );
			$protocol = '' === $protocol ? '2025-03-26' : $protocol;
			if ( ! in_array( $protocol, self::PROTOCOLS, true ) ) {
				return self::jsonrpc_error( $message['id'] ?? null, -32600, 'Unsupported MCP-Protocol-Version.', 400 );
			}
		}

		$authorization = Coordinator_Authentication::can_read();
		if ( true !== $authorization && ! is_array( $authorization ) ) {
			return self::authorization_required( $message['id'] ?? null );
		}

		if ( str_starts_with( $method, 'notifications/' ) ) {
			return new WP_REST_Response( null, 202 );
		}

		switch ( $method ) {
			case 'initialize':
				return self::jsonrpc_result( $message['id'] ?? null, self::initialize_result( $message['params'] ?? array() ) );
			case 'ping':
				return self::jsonrpc_result( $message['id'] ?? null, (object) array() );
			case 'tools/list':
				return self::jsonrpc_result( $message['id'] ?? null, array( 'tools' => self::tool_definitions() ) );
			case 'tools/call':
				return self::call_tool( $message['id'] ?? null, $message['params'] ?? null, $authorization );
			default:
				return self::jsonrpc_error( $message['id'] ?? null, -32601, 'Method not found', 404 );
		}
	}

	private static function initialize_result( $params ): array {
		$requested = is_array( $params ) && is_string( $params['protocolVersion'] ?? null ) ? $params['protocolVersion'] : '';
		$protocol  = in_array( $requested, self::PROTOCOLS, true ) ? $requested : self::LATEST_PROTOCOL;

		return array(
			'protocolVersion' => $protocol,
			'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
			'serverInfo'      => array( 'name' => 'Coordinator Core', 'version' => COORDINATOR_CORE_VERSION ),
			'instructions'    => 'Read tools, nonpublic rendered-page verification, approval-controlled operational-state, exact-match content-edit, nonpublic draft-creation, and nonpublic image-upload boundaries, plus explicitly confirmed advisory AI delegation through a separate budget-capped router. Publishing-status changes, plugin changes, deployment, files, users, and deletion are unavailable.',
		);
	}

	private static function tool_definitions(): array {
		$input       = array( 'type' => 'object', 'properties' => (object) array(), 'additionalProperties' => false );
		$annotations = array( 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false );
		$security    = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE ) ) );
		$write_security = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE, Coordinator_Authentication::WRITE_OPERATIONAL_STATE_SCOPE ) ) );
		$content_write_security = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE, Coordinator_Authentication::WRITE_CONTENT_SCOPE ) ) );
		$draft_write_security = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE, Coordinator_Authentication::CREATE_DRAFT_SCOPE ) ) );
		$media_write_security = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE, Coordinator_Authentication::UPLOAD_MEDIA_SCOPE ) ) );
		$write_annotations = array( 'readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => false, 'openWorldHint' => false );
		$content_write_annotations = array( 'readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => false );
		$ai_security = array( array( 'type' => 'oauth2', 'scopes' => array( Coordinator_Authentication::READ_SCOPE, Coordinator_Authentication::DELEGATE_AI_SCOPE ) ) );
		$ai_preview_annotations = array( 'readOnlyHint' => true, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => true );
		$ai_run_annotations = array( 'readOnlyHint' => false, 'destructiveHint' => false, 'idempotentHint' => true, 'openWorldHint' => true );

		return array(
			array(
				'name' => 'get_profile', 'title' => 'Get authenticated profile',
				'description' => 'Returns the stable, privacy-preserving identity of the authenticated Coordinator administrator.',
				'inputSchema' => $input,
				'outputSchema' => array( 'type' => 'object', 'properties' => array( 'id' => array( 'type' => 'string' ), 'name' => array( 'type' => 'string' ) ), 'required' => array( 'id' ), 'additionalProperties' => false ),
				'annotations' => $annotations, 'securitySchemes' => $security, '_meta' => array( 'openai/profile' => true ),
			),
			array(
				'name' => 'get_coordinator_status', 'title' => 'Get Coordinator status',
				'description' => 'Returns the current Coordinator Core health and read-only connection status.',
				'inputSchema' => $input, 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'get_site_inventory', 'title' => 'Get WordPress site inventory',
				'description' => 'Returns WordPress, PHP, theme, and plugin inventory without changing the site.',
				'inputSchema' => $input, 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'get_continue_work', 'title' => 'Get Continue Work status',
				'description' => 'Returns the validated Continue Work summary or a safe waiting state.',
				'inputSchema' => $input, 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'get_content_item', 'title' => 'Read WordPress content',
				'description' => 'Reads one administrator-selected WordPress title, excerpt, or content field by post ID. It never changes WordPress.',
				'inputSchema' => self::content_read_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'verify_rendered_page', 'title' => 'Verify rendered nonpublic page',
				'description' => 'Renders one selected draft, pending, or private page/post through WordPress, returns bounded HTML and visible-output evidence, and provides a same-site administrator preview URL without credential-like parameters. It never changes WordPress and rejects public content.',
				'inputSchema' => self::rendered_page_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'search_content_snippets', 'title' => 'Search WordPress content snippets',
				'description' => 'Searches one administrator-selected WordPress title, excerpt, or content field and returns bounded matching lines with context. It never changes WordPress.',
				'inputSchema' => self::content_search_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'preview_content_edit', 'title' => 'Preview an exact-match content edit',
				'description' => 'Plans one exact, case-sensitive replacement and reports no-match or multiple-match conflicts, hashes, byte changes, and bounded before/after previews. It never saves anything.',
				'inputSchema' => self::content_edit_preview_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'apply_content_edit', 'title' => 'Apply an approved exact-match content edit',
				'description' => 'Applies one explicitly confirmed exact replacement only when the current SHA-256 state still matches the approved preview. Creates a WordPress recovery revision, verifies the saved value, rejects stale or ambiguous state, and returns an idempotent audit receipt.',
				'inputSchema' => self::content_edit_apply_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $content_write_annotations, 'securitySchemes' => $content_write_security,
			),
			array(
				'name' => 'create_nonpublic_draft', 'title' => 'Create an approved nonpublic draft',
				'description' => 'Creates one explicitly confirmed page or post with draft or pending status only. It uses a dedicated scope, idempotency, exact-duplicate protection, readback verification, and an audit receipt. It cannot publish or change an existing item.',
				'inputSchema' => self::draft_creation_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $content_write_annotations, 'securitySchemes' => $draft_write_security,
			),
			array(
				'name' => 'upload_draft_image', 'title' => 'Upload an approved image to a nonpublic draft',
				'description' => 'Uploads one explicitly confirmed JPEG, PNG, WebP, or GIF image of at most 5 MiB to one selected draft, pending, or private page/post. It requires alt text, verifies file signatures, prevents duplicates, performs readback, and cannot publish or change content.',
				'inputSchema' => self::media_upload_schema(), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $content_write_annotations, 'securitySchemes' => $media_write_security,
			),
			array(
				'name' => 'preview_operational_state', 'title' => 'Preview Coordinator operational state',
				'description' => 'Validates and normalizes a proposed Coordinator operational-state record without saving it.',
				'inputSchema' => self::state_input_schema( false ), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $annotations, 'securitySchemes' => $security,
			),
			array(
				'name' => 'save_operational_state', 'title' => 'Save Coordinator operational state',
				'description' => 'Saves only a previously reviewed Coordinator operational-state record and returns an audit receipt. Requires explicit confirmation and the last-known update timestamp.',
				'inputSchema' => self::state_input_schema( true ), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $write_annotations, 'securitySchemes' => $write_security,
			),
			array(
				'name' => 'preview_ai_job', 'title' => 'Preview bounded AI job',
				'description' => 'Validates and prices an advisory summarize, classify, draft, or review job without contacting the model provider or spending API credit.',
				'inputSchema' => self::ai_job_schema( false ), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $ai_preview_annotations, 'securitySchemes' => $ai_security,
			),
			array(
				'name' => 'run_ai_job', 'title' => 'Run bounded AI job',
				'description' => 'Runs one explicitly confirmed advisory job through the allowlisted, idempotent, per-job and monthly budget-capped AI router. It cannot call tools or change WordPress.',
				'inputSchema' => self::ai_job_schema( true ), 'outputSchema' => array( 'type' => 'object', 'additionalProperties' => true ),
				'annotations' => $ai_run_annotations, 'securitySchemes' => $ai_security,
			),
		);
	}

	private static function content_read_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'post_id' => array( 'type' => 'integer', 'minimum' => 1 ),
				'field' => array( 'type' => 'string', 'enum' => array( 'post_title', 'post_excerpt', 'post_content' ), 'default' => 'post_content' ),
				'max_length' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100000, 'default' => 50000 ),
			),
			'required' => array( 'post_id' ),
			'additionalProperties' => false,
		);
	}

	private static function content_search_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'post_id' => array( 'type' => 'integer', 'minimum' => 1 ),
				'field' => array( 'type' => 'string', 'enum' => array( 'post_title', 'post_excerpt', 'post_content' ), 'default' => 'post_content' ),
				'pattern' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 500 ),
				'case_sensitive' => array( 'type' => 'boolean', 'default' => false ),
				'max_results' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100, 'default' => 20 ),
			),
			'required' => array( 'post_id', 'pattern' ),
			'additionalProperties' => false,
		);
	}

	private static function rendered_page_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'post_id' => array( 'type' => 'integer', 'minimum' => 1 ),
				'max_length' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100000, 'default' => 50000 ),
			),
			'required' => array( 'post_id' ),
			'additionalProperties' => false,
		);
	}

	private static function content_edit_preview_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'post_id' => array( 'type' => 'integer', 'minimum' => 1 ),
				'field' => array( 'type' => 'string', 'enum' => array( 'post_title', 'post_excerpt', 'post_content' ), 'default' => 'post_content' ),
				'old_content' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 10000 ),
				'new_content' => array( 'type' => 'string', 'maxLength' => 50000 ),
			),
			'required' => array( 'post_id', 'old_content', 'new_content' ),
			'additionalProperties' => false,
		);
	}

	private static function content_edit_apply_schema(): array {
		$schema = self::content_edit_preview_schema();
		$schema['properties']['expected_content_sha256'] = array( 'type' => 'string', 'pattern' => '^[a-fA-F0-9]{64}$' );
		$schema['properties']['idempotency_key'] = array( 'type' => 'string', 'minLength' => 16, 'maxLength' => 128 );
		$schema['properties']['confirmed'] = array( 'type' => 'boolean', 'const' => true );
		$schema['required'][] = 'expected_content_sha256';
		$schema['required'][] = 'idempotency_key';
		$schema['required'][] = 'confirmed';
		return $schema;
	}

	private static function draft_creation_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'post_type' => array( 'type' => 'string', 'enum' => array( 'page', 'post' ) ),
				'post_status' => array( 'type' => 'string', 'enum' => array( 'draft', 'pending' ) ),
				'post_title' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 1000 ),
				'post_excerpt' => array( 'type' => 'string', 'maxLength' => 10000, 'default' => '' ),
				'post_content' => array( 'type' => 'string', 'maxLength' => 200000, 'default' => '' ),
				'idempotency_key' => array( 'type' => 'string', 'minLength' => 16, 'maxLength' => 128 ),
				'confirmed' => array( 'type' => 'boolean', 'const' => true ),
			),
			'required' => array( 'post_type', 'post_status', 'post_title', 'idempotency_key', 'confirmed' ),
			'additionalProperties' => false,
		);
	}

	private static function media_upload_schema(): array {
		return array(
			'type' => 'object',
			'properties' => array(
				'post_id' => array( 'type' => 'integer', 'minimum' => 1 ),
				'filename' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 240 ),
				'mime_type' => array( 'type' => 'string', 'enum' => array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ) ),
				'alt_text' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 2000 ),
				'source_url' => array( 'type' => 'string', 'format' => 'uri', 'minLength' => 8, 'maxLength' => 2048 ),
				'idempotency_key' => array( 'type' => 'string', 'minLength' => 16, 'maxLength' => 128 ),
				'confirmed' => array( 'type' => 'boolean', 'const' => true ),
			),
			'required' => array( 'post_id', 'filename', 'mime_type', 'alt_text', 'source_url', 'idempotency_key', 'confirmed' ),
			'additionalProperties' => false,
		);
	}

	private static function state_input_schema( bool $for_save ): array {
		$properties = array(
			'project_key' => array( 'type' => 'string', 'minLength' => 1 ), 'project_name' => array( 'type' => 'string' ),
			'status' => array( 'type' => 'string', 'enum' => array( 'working', 'waiting', 'needs_you', 'failed', 'completed' ) ),
			'phase' => array( 'type' => 'string' ), 'stage' => array( 'type' => 'string' ),
			'progress' => array( 'type' => 'object', 'properties' => array( 'percent_complete' => array( 'type' => 'number', 'minimum' => 0, 'maximum' => 100 ) ), 'required' => array( 'percent_complete' ), 'additionalProperties' => false ),
			'current_work' => array( 'type' => 'string' ), 'blockers' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
			'exact_next_action' => array( 'type' => 'string', 'minLength' => 1 ),
			'continue_work' => array( 'type' => 'object', 'properties' => array( 'enabled' => array( 'type' => 'boolean' ), 'url' => array( 'type' => 'string' ), 'label' => array( 'type' => 'string' ), 'reason' => array( 'type' => 'string' ) ), 'required' => array( 'enabled' ), 'additionalProperties' => false ),
		);
		$required = array( 'project_key', 'status', 'progress', 'exact_next_action', 'continue_work' );
		if ( $for_save ) {
			$properties['confirmed'] = array( 'type' => 'boolean', 'const' => true );
			$properties['expected_updated_at'] = array( 'type' => 'string' );
			$required[] = 'confirmed'; $required[] = 'expected_updated_at';
		}
		return array( 'type' => 'object', 'properties' => $properties, 'required' => $required, 'additionalProperties' => false );
	}

	private static function ai_job_schema( bool $for_run ): array {
		$properties = array(
			'task_type' => array( 'type' => 'string', 'enum' => array( 'summarize', 'classify', 'draft', 'review' ) ),
			'instructions' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 4000 ),
			'input' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 50000 ),
			'model' => array( 'type' => 'string', 'enum' => array( 'gpt-5.6-luna', 'gpt-5.6-terra' ), 'default' => 'gpt-5.6-luna' ),
			'max_output_tokens' => array( 'type' => 'integer', 'minimum' => 64, 'maximum' => 4000 ),
			'idempotency_key' => array( 'type' => 'string', 'minLength' => 16, 'maxLength' => 128 ),
		);
		$required = array( 'task_type', 'instructions', 'input', 'model', 'max_output_tokens', 'idempotency_key' );
		if ( $for_run ) {
			$properties['confirmed'] = array( 'type' => 'boolean', 'const' => true );
			$required[] = 'confirmed';
		}
		return array( 'type' => 'object', 'properties' => $properties, 'required' => $required, 'additionalProperties' => false );
	}

	private static function call_tool( $id, $params, $authorization ) {
		if ( ! is_array( $params ) || ! is_string( $params['name'] ?? null ) || ( isset( $params['arguments'] ) && ! is_array( $params['arguments'] ) ) ) {
			return self::jsonrpc_error( $id, -32602, 'Invalid tool arguments.', 400 );
		}
		$arguments = $params['arguments'] ?? array();
		if ( in_array( $params['name'], array( 'get_profile', 'get_coordinator_status', 'get_site_inventory', 'get_continue_work' ), true ) && array() !== $arguments ) {
			return self::jsonrpc_error( $id, -32602, 'This read tool accepts no arguments.', 400 );
		}
		if ( 'get_content_item' === $params['name'] && ! self::content_arguments_are_allowed( $arguments, false ) ) {
			return self::jsonrpc_error( $id, -32602, 'Content-read arguments are invalid.', 400 );
		}
		if ( 'verify_rendered_page' === $params['name'] && ! self::rendered_page_arguments_are_allowed( $arguments ) ) {
			return self::jsonrpc_error( $id, -32602, 'Rendered-page arguments are invalid.', 400 );
		}
		if ( 'search_content_snippets' === $params['name'] && ! self::content_arguments_are_allowed( $arguments, true ) ) {
			return self::jsonrpc_error( $id, -32602, 'Content-search arguments are invalid.', 400 );
		}
		if ( 'preview_content_edit' === $params['name'] && ! self::content_edit_arguments_are_allowed( $arguments, false ) ) {
			return self::jsonrpc_error( $id, -32602, 'Content-edit preview arguments are invalid.', 400 );
		}
		if ( 'apply_content_edit' === $params['name'] && ! self::content_edit_arguments_are_allowed( $arguments, true ) ) {
			return self::jsonrpc_error( $id, -32602, 'Confirmed content-edit arguments are invalid.', 400 );
		}
		if ( 'create_nonpublic_draft' === $params['name'] && ! self::draft_arguments_are_allowed( $arguments ) ) {
			return self::jsonrpc_error( $id, -32602, 'Nonpublic draft arguments are invalid.', 400 );
		}
		if ( 'upload_draft_image' === $params['name'] && ! self::media_arguments_are_allowed( $arguments ) ) {
			return self::jsonrpc_error( $id, -32602, 'Draft-image upload arguments are invalid.', 400 );
		}
		if ( in_array( $params['name'], array( 'preview_operational_state', 'save_operational_state' ), true ) && ! self::state_arguments_are_allowed( $arguments, 'save_operational_state' === $params['name'] ) ) {
			return self::jsonrpc_error( $id, -32602, 'Operational-state arguments are invalid.', 400 );
		}
		if ( in_array( $params['name'], array( 'preview_ai_job', 'run_ai_job' ), true ) && ! self::ai_arguments_are_allowed( $arguments, 'run_ai_job' === $params['name'] ) ) {
			return self::jsonrpc_error( $id, -32602, 'AI job arguments are invalid.', 400 );
		}

		switch ( $params['name'] ) {
			case 'get_profile':
				$data = self::profile_data( $authorization );
				break;
			case 'get_coordinator_status':
				$data = self::response_data( Coordinator_Core::health_response() );
				break;
			case 'get_site_inventory':
				$data = self::response_data( Coordinator_Connector::site_inventory_response() );
				break;
			case 'get_continue_work':
				$data = self::response_data( Coordinator_Core::continue_work_response() );
				break;
			case 'get_content_item':
				$data = Coordinator_Content_Reader::read_content( $arguments );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 400 ); }
				break;
			case 'verify_rendered_page':
				$data = Coordinator_Rendered_Page_Verifier::verify( $arguments );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 400 ); }
				break;
			case 'search_content_snippets':
				$data = Coordinator_Content_Reader::search_content( $arguments );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 400 ); }
				break;
			case 'preview_content_edit':
				$data = Coordinator_Content_Reader::preview_content_edit( $arguments );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 400 ); }
				break;
			case 'apply_content_edit':
				if ( true !== ( $arguments['confirmed'] ?? false ) || ! Coordinator_Authentication::can_write_content( $authorization ) ) {
					return self::authorization_required( $id, 'content-edit' );
				}
				$user_id = current_user_can( 'manage_options' ) ? (int) wp_get_current_user()->ID : (int) ( $authorization['user_id'] ?? 0 );
				$data = Coordinator_Content_Editor::apply_exact_edit( $arguments, $user_id );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 409 ); }
				break;
			case 'create_nonpublic_draft':
				if ( true !== ( $arguments['confirmed'] ?? false ) || ! Coordinator_Authentication::can_create_drafts( $authorization ) ) {
					return self::authorization_required( $id, 'draft-creation' );
				}
				$user_id = current_user_can( 'manage_options' ) ? (int) wp_get_current_user()->ID : (int) ( $authorization['user_id'] ?? 0 );
				$data = Coordinator_Draft_Creator::create_nonpublic_draft( $arguments, $user_id );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 409 ); }
				break;
			case 'upload_draft_image':
				if ( true !== ( $arguments['confirmed'] ?? false ) || ! Coordinator_Authentication::can_upload_media( $authorization ) ) {
					return self::authorization_required( $id, 'media-upload' );
				}
				$user_id = current_user_can( 'manage_options' ) ? (int) wp_get_current_user()->ID : (int) ( $authorization['user_id'] ?? 0 );
				$data = Coordinator_Media_Uploader::upload_image( $arguments, $user_id );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 409 ); }
				break;
			case 'preview_operational_state':
				$data = Coordinator_Operational_State::preview_connector_input( $arguments );
				if ( null === $data ) { return self::jsonrpc_error( $id, -32602, 'Operational state did not pass validation.', 400 ); }
				break;
			case 'save_operational_state':
				if ( true !== ( $arguments['confirmed'] ?? false ) || ! Coordinator_Authentication::can_write_operational_state( $authorization ) ) {
					return self::authorization_required( $id, 'operational-state' );
				}
				$expected = is_string( $arguments['expected_updated_at'] ?? null ) ? $arguments['expected_updated_at'] : '';
				unset( $arguments['confirmed'], $arguments['expected_updated_at'] );
				$user_id = current_user_can( 'manage_options' ) ? (int) wp_get_current_user()->ID : (int) ( $authorization['user_id'] ?? 0 );
				$data = Coordinator_Operational_State::save_from_connector( $arguments, $user_id, $expected );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 409 ); }
				break;
			case 'preview_ai_job':
				if ( ! Coordinator_Authentication::can_delegate_ai( $authorization ) ) {
					return self::authorization_required( $id, 'ai-delegation' );
				}
				$data = Coordinator_AI_Router::preview_job( $arguments );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 400 ); }
				break;
			case 'run_ai_job':
				if ( true !== ( $arguments['confirmed'] ?? false ) || ! Coordinator_Authentication::can_delegate_ai( $authorization ) ) {
					return self::authorization_required( $id, 'ai-delegation' );
				}
				$data = Coordinator_AI_Router::run_job( $arguments );
				if ( is_wp_error( $data ) ) { return self::jsonrpc_error( $id, -32602, $data->get_error_message(), 400 ); }
				break;
			default:
				return self::jsonrpc_error( $id, -32602, 'Unknown tool.', 400 );
		}

		return self::jsonrpc_result(
			$id,
			array(
				'structuredContent' => $data,
				'content'           => array( array( 'type' => 'text', 'text' => wp_json_encode( $data, JSON_UNESCAPED_SLASHES ) ) ),
				'isError'           => false,
			)
		);
	}

	private static function content_arguments_are_allowed( array $arguments, bool $for_search ): bool {
		$allowed = array( 'post_id', 'field' );
		if ( $for_search ) {
			$allowed[] = 'pattern';
			$allowed[] = 'case_sensitive';
			$allowed[] = 'max_results';
		} else {
			$allowed[] = 'max_length';
		}
		return array() === array_diff( array_keys( $arguments ), $allowed );
	}

	private static function rendered_page_arguments_are_allowed( array $arguments ): bool {
		return array() === array_diff( array_keys( $arguments ), array( 'post_id', 'max_length' ) );
	}

	private static function content_edit_arguments_are_allowed( array $arguments, bool $for_apply ): bool {
		$allowed = array( 'post_id', 'field', 'old_content', 'new_content' );
		if ( $for_apply ) {
			$allowed[] = 'expected_content_sha256';
			$allowed[] = 'idempotency_key';
			$allowed[] = 'confirmed';
		}
		return array() === array_diff( array_keys( $arguments ), $allowed );
	}

	private static function draft_arguments_are_allowed( array $arguments ): bool {
		$allowed = array( 'post_type', 'post_status', 'post_title', 'post_excerpt', 'post_content', 'idempotency_key', 'confirmed' );
		return array() === array_diff( array_keys( $arguments ), $allowed );
	}

	private static function media_arguments_are_allowed( array $arguments ): bool {
		$allowed = array( 'post_id', 'filename', 'mime_type', 'alt_text', 'source_url', 'idempotency_key', 'confirmed' );
		return array() === array_diff( array_keys( $arguments ), $allowed );
	}

	private static function state_arguments_are_allowed( array $arguments, bool $for_save ): bool {
		$allowed = array( 'project_key', 'project_name', 'status', 'phase', 'stage', 'progress', 'current_work', 'blockers', 'exact_next_action', 'continue_work' );
		if ( $for_save ) { $allowed[] = 'confirmed'; $allowed[] = 'expected_updated_at'; }
		return array() === array_diff( array_keys( $arguments ), $allowed );
	}

	private static function ai_arguments_are_allowed( array $arguments, bool $for_run ): bool {
		$allowed = array( 'task_type', 'instructions', 'input', 'model', 'max_output_tokens', 'idempotency_key' );
		if ( $for_run ) { $allowed[] = 'confirmed'; }
		return array() === array_diff( array_keys( $arguments ), $allowed );
	}

	private static function profile_data( $authorization ): array {
		$user_id = current_user_can( 'manage_options' ) ? (int) wp_get_current_user()->ID : (int) ( $authorization['user_id'] ?? 0 );
		$user    = get_userdata( $user_id );
		$data    = array( 'id' => 'prf_' . substr( hash_hmac( 'sha256', site_url( '/' ) . '|' . $user_id, wp_salt( 'auth' ) ), 0, 32 ) );

		if ( $user && is_string( $user->display_name ?? null ) && '' !== trim( $user->display_name ) ) {
			$data['name'] = sanitize_text_field( $user->display_name );
		}

		return $data;
	}

	private static function response_data( $response ): array {
		$data = $response instanceof WP_REST_Response ? $response->get_data() : $response;
		return is_array( $data ) ? $data : array();
	}

	private static function origin_is_allowed( string $origin ): bool {
		if ( '' === trim( $origin ) ) {
			return true;
		}

		$allowed = array( self::origin_from_url( site_url( '/' ) ), 'https://chatgpt.com' );
		return in_array( self::origin_from_url( $origin ), $allowed, true );
	}

	private static function origin_from_url( string $url ): string {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return '';
		}
		return strtolower( $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' ) );
	}

	private static function accepts_mcp_response( string $accept ): bool {
		$accept = strtolower( $accept );
		return str_contains( $accept, 'application/json' ) && str_contains( $accept, 'text/event-stream' );
	}

	private static function authorization_required( $id, string $boundary = 'read' ) {
		$description = 'A valid coordinator:read access token is required';
		if ( 'content-edit' === $boundary ) {
			$description = 'A valid content-write scope and explicit confirmation are required';
		} elseif ( 'draft-creation' === $boundary ) {
			$description = 'A valid draft-creation scope and explicit confirmation are required';
		} elseif ( 'media-upload' === $boundary ) {
			$description = 'A valid media-upload scope and explicit confirmation are required';
		} elseif ( 'operational-state' === $boundary ) {
			$description = 'A valid operational-state write scope and explicit confirmation are required';
		}
		if ( 'ai-delegation' === $boundary ) {
			$description = 'A valid AI delegation scope and explicit confirmation are required';
		}
		$challenge = 'Bearer resource_metadata="' . self::resource_metadata_url() . '", error="insufficient_scope", error_description="' . $description . '"';
		$result    = array(
			'content' => array( array( 'type' => 'text', 'text' => 'Authorization is required.' ) ),
			'isError' => true,
			'_meta'   => array( 'mcp/www_authenticate' => array( $challenge ) ),
		);
		$response = self::jsonrpc_result( $id, $result, 401 );
		$response->header( 'WWW-Authenticate', $challenge );
		return $response;
	}

	private static function resource_metadata_url(): string {
		return site_url( '/.well-known/oauth-protected-resource' . wp_parse_url( rest_url( self::REST_NAMESPACE . '/mcp' ), PHP_URL_PATH ) );
	}

	private static function jsonrpc_result( $id, $result, int $status = 200 ): WP_REST_Response {
		return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => $id, 'result' => $result ), $status );
	}

	private static function jsonrpc_error( $id, int $code, string $message, int $status ): WP_REST_Response {
		return new WP_REST_Response( array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => $code, 'message' => $message ) ), $status );
	}

	private static function http_error( int $status, string $message, array $headers = array() ): WP_REST_Response {
		$response = new WP_REST_Response( array( 'error' => $message ), $status );
		foreach ( $headers as $name => $value ) {
			$response->header( $name, $value );
		}
		return $response;
	}
}
