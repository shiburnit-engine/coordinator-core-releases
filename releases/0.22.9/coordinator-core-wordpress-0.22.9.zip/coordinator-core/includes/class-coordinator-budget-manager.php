<?php
/**
 * Budget manager with spending caps, quiet hours, alerts, and budget-aware optimization.
 *
 * Works with the provider registry's optimizer to:
 * - Enforce configurable daily/weekly/monthly spending caps
 * - Front-load free provider usage to maximize free daily quota
 * - Reserve paid budget for complex tasks that free models can't handle
 * - Track spending with daily reports
 * - Pause paid spending during configured quiet hours
 * - Alert when spending crosses warning thresholds
 * - Track token efficiency and quality per provider
 * - Filter providers by context window capacity
 * - Handle concurrent request allocation
 * - Cooldown providers after consecutive failures
 * - Test new provider connections on setup
 * - Persist fallback chains with failure memory
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Budget_Manager {
	public const OPTION = 'coordinator_core_budget_v1';
	public const SPENDING_OPTION = 'coordinator_core_spending_v1';
	public const COOLDOWN_OPTION = 'coordinator_core_provider_cooldown_v1';

	private const TASK_TYPES = array( 'summarize', 'classify', 'draft', 'review' );

	// Default budgets (all zero — free only — until the owner configures spending)
	private const DEFAULT_DAILY_BUDGET = 0.0;
	private const DEFAULT_WEEKLY_BUDGET = 0.0;
	private const DEFAULT_MONTHLY_BUDGET = 5.0; // Matches existing AI Router cap
	private const DEFAULT_WARNING_PCT = 80;
	private const DEFAULT_COMPLEX_RESERVE_PCT = 30;
	private const DEFAULT_COOLDOWN_MINUTES = 30;
	private const MAX_CONSECUTIVE_FAILURES = 3;

	/**
	 * Boot — register admin actions.
	 */
	public static function boot(): void {
		add_action( 'admin_post_coordinator_save_budget', array( self::class, 'handle_admin_save' ) );
	}

	// ─── Budget configuration ────────────────────────────────────────────

	/**
	 * Get the current budget configuration.
	 */
	public static function get_config(): array {
		$config = get_option( self::OPTION, array() );
		if ( ! is_array( $config ) || 1 !== ( $config['schema_version'] ?? null ) ) {
			return self::default_config();
		}
		return $config;
	}

	private static function default_config(): array {
		return array(
			'schema_version'        => 1,
			'daily_budget_usd'      => self::DEFAULT_DAILY_BUDGET,
			'weekly_budget_usd'     => self::DEFAULT_WEEKLY_BUDGET,
			'monthly_budget_usd'    => self::DEFAULT_MONTHLY_BUDGET,
			'warning_pct'           => self::DEFAULT_WARNING_PCT,
			'complex_reserve_pct'   => self::DEFAULT_COMPLEX_RESERVE_PCT,
			'quiet_hours_enabled'   => false,
			'quiet_start'           => '22:00',
			'quiet_end'             => '06:00',
			'quiet_timezone'        => 'America/Chicago',
			'alert_threshold_pct'   => self::DEFAULT_WARNING_PCT,
			'updated_at'            => gmdate( 'c' ),
		);
	}

	/**
	 * Save budget configuration from admin input.
	 */
	public static function save_config( array $input ): array|WP_Error {
		$daily = (float) ( $input['daily_budget_usd'] ?? 0 );
		$weekly = (float) ( $input['weekly_budget_usd'] ?? 0 );
		$monthly = (float) ( $input['monthly_budget_usd'] ?? 0 );
		$warning = (int) ( $input['warning_pct'] ?? 80 );
		$reserve = (int) ( $input['complex_reserve_pct'] ?? 30 );

		if ( $daily < 0 || $weekly < 0 || $monthly < 0 ) {
			return new WP_Error( 'invalid_budget', 'Budget values cannot be negative.' );
		}
		if ( $warning < 50 || $warning > 99 ) {
			return new WP_Error( 'invalid_warning', 'Warning threshold must be between 50 and 99 percent.' );
		}
		if ( $reserve < 0 || $reserve > 50 ) {
			return new WP_Error( 'invalid_reserve', 'Complex task reserve must be between 0 and 50 percent.' );
		}

		$config = array(
			'schema_version'        => 1,
			'daily_budget_usd'      => $daily,
			'weekly_budget_usd'     => $weekly,
			'monthly_budget_usd'    => $monthly,
			'warning_pct'           => $warning,
			'complex_reserve_pct'   => $reserve,
			'quiet_hours_enabled'   => ! empty( $input['quiet_hours_enabled'] ),
			'quiet_start'           => sanitize_text_field( (string) ( $input['quiet_start'] ?? '22:00' ) ),
			'quiet_end'             => sanitize_text_field( (string) ( $input['quiet_end'] ?? '06:00' ) ),
			'quiet_timezone'        => sanitize_text_field( (string) ( $input['quiet_timezone'] ?? 'America/Chicago' ) ),
			'alert_threshold_pct'   => $warning,
			'updated_at'            => gmdate( 'c' ),
		);

		update_option( self::OPTION, $config, false );
		return $config;
	}

	// ─── Spending tracking ───────────────────────────────────────────────

	/**
	 * Record a spending event.
	 *
	 * @param string $provider_id Provider ID.
	 * @param string $task_type Task type.
	 * @param float  $cost_usd Actual cost (0 for free tier).
	 * @param int    $input_tokens Input tokens consumed.
	 * @param int    $output_tokens Output tokens consumed.
	 * @param bool   $success Whether the job succeeded.
	 * @param bool   $quality_accepted Whether the output was accepted as usable.
	 */
	public static function record_spending( string $provider_id, string $task_type, float $cost_usd, int $input_tokens, int $output_tokens, bool $success, bool $quality_accepted = true ): void {
		$spending = self::get_spending();
		$today = gmdate( 'Y-m-d' );
		$week = gmdate( 'Y-W' );
		$month = gmdate( 'Y-m' );

		if ( ! isset( $spending['periods']['daily'][ $today ] ) ) {
			$spending['periods']['daily'][ $today ] = array( 'cost_usd' => 0.0, 'requests' => 0, 'free_requests' => 0, 'paid_requests' => 0 );
		}
		if ( ! isset( $spending['periods']['weekly'][ $week ] ) ) {
			$spending['periods']['weekly'][ $week ] = array( 'cost_usd' => 0.0, 'requests' => 0 );
		}
		if ( ! isset( $spending['periods']['monthly'][ $month ] ) ) {
			$spending['periods']['monthly'][ $month ] = array( 'cost_usd' => 0.0, 'requests' => 0 );
		}

		$d = &$spending['periods']['daily'][ $today ];
		$d['cost_usd'] = round( $d['cost_usd'] + $cost_usd, 6 );
		$d['requests'] += 1;
		if ( $cost_usd > 0 ) { $d['paid_requests'] += 1; } else { $d['free_requests'] += 1; }

		$w = &$spending['periods']['weekly'][ $week ];
		$w['cost_usd'] = round( $w['cost_usd'] + $cost_usd, 6 );
		$w['requests'] += 1;

		$m = &$spending['periods']['monthly'][ $month ];
		$m['cost_usd'] = round( $m['cost_usd'] + $cost_usd, 6 );
		$m['requests'] += 1;

		// Provider-level quality and token efficiency tracking
		if ( ! isset( $spending['providers'][ $provider_id ] ) ) {
			$spending['providers'][ $provider_id ] = array(
				'total_cost' => 0.0,
				'total_requests' => 0,
				'quality_accepted' => 0,
				'quality_rejected' => 0,
				'avg_input_tokens' => 0,
				'avg_output_tokens' => 0,
				'total_input_tokens' => 0,
				'total_output_tokens' => 0,
				'by_task' => array(),
			);
		}

		$p = &$spending['providers'][ $provider_id ];
		$p['total_cost'] = round( $p['total_cost'] + $cost_usd, 6 );
		$p['total_requests'] += 1;
		$p['total_input_tokens'] += $input_tokens;
		$p['total_output_tokens'] += $output_tokens;
		if ( $quality_accepted ) { $p['quality_accepted'] += 1; } else { $p['quality_rejected'] += 1; }
		$p['avg_input_tokens'] = (int) round( $p['total_input_tokens'] / $p['total_requests'] );
		$p['avg_output_tokens'] = (int) round( $p['total_output_tokens'] / $p['total_requests'] );

		if ( ! isset( $p['by_task'][ $task_type ] ) ) {
			$p['by_task'][ $task_type ] = array( 'requests' => 0, 'cost' => 0.0, 'quality_accepted' => 0, 'quality_rejected' => 0 );
		}
		$pt = &$p['by_task'][ $task_type ];
		$pt['requests'] += 1;
		$pt['cost'] = round( $pt['cost'] + $cost_usd, 6 );
		if ( $quality_accepted ) { $pt['quality_accepted'] += 1; } else { $pt['quality_rejected'] += 1; }

		// Clean old daily entries (keep 90 days)
		$cutoff = gmdate( 'Y-m-d', time() - 90 * DAY_IN_SECONDS );
		foreach ( $spending['periods']['daily'] as $date => $data ) {
			if ( $date < $cutoff ) {
				unset( $spending['periods']['daily'][ $date ] );
			}
		}

		unset( $d, $w, $m, $p, $pt );
		update_option( self::SPENDING_OPTION, $spending, false );

		// Update provider registry usage for optimizer
		Coordinator_Provider_Registry::record_usage( $provider_id, $task_type, $input_tokens, $output_tokens, $cost_usd, $success );

		// Handle cooldown on failure
		if ( ! $success ) {
			self::record_failure( $provider_id, $task_type );
		} else {
			self::clear_failures( $provider_id, $task_type );
		}
	}

	private static function get_spending(): array {
		$s = get_option( self::SPENDING_OPTION, array() );
		if ( ! is_array( $s ) ) return array( 'periods' => array( 'daily' => array(), 'weekly' => array(), 'monthly' => array() ), 'providers' => array() );
		return $s;
	}

	// ─── Budget-aware selection ───────────────────────────────────────────

	/**
	 * Select the best provider+model with budget awareness.
	 *
	 * This wraps the provider registry's optimizer and adds:
	 * - Budget state checks (skip paid if budget exhausted)
	 * - Context window filtering (skip providers that can't fit the input)
	 * - Cooldown checks (skip providers in failure cooldown)
	 * - Quiet hours (skip paid during configured hours)
	 * - Free front-loading (prefer free earlier in the day)
	 * - Complex task reserve (save paid budget for tasks that need it)
	 *
	 * @param string $task_type Task type.
	 * @param int    $input_token_estimate Estimated input tokens (for context window filtering).
	 * @param bool   $is_complex Whether this is a complex task that may need paid models.
	 * @return array|null Selected provider+model or null if none available.
	 */
	public static function select_with_budget( string $task_type, int $input_token_estimate = 0, bool $is_complex = false ): ?array {
		if ( ! in_array( $task_type, self::TASK_TYPES, true ) ) {
			return null;
		}

		$config = self::get_config();
		$budget_state = self::budget_state( $config );
		$quiet_active = self::is_quiet_hours( $config );

		// Get all ranked candidates from the provider registry
		$candidates = Coordinator_Provider_Registry::ranked_candidates( $task_type );
		if ( empty( $candidates ) ) {
			return null;
		}

		// Filter candidates based on budget, context, cooldown, and quiet hours
		$filtered = array();
		foreach ( $candidates as $candidate ) {
			$provider_id = $candidate['id'];
			$is_free = $candidate['free_tier'];

			// Context window filter — hard exclusion
			if ( $input_token_estimate > 0 && ! self::provider_can_handle_context( $provider_id, $input_token_estimate ) ) {
				continue;
			}

			// Cooldown filter — skip providers in cooldown for this task
			if ( self::is_in_cooldown( $provider_id, $task_type ) ) {
				continue;
			}

			// Budget filter for paid providers
			if ( ! $is_free ) {
				// During quiet hours, skip paid entirely
				if ( $quiet_active ) {
					continue;
				}

				// If budget is exhausted, skip paid
				if ( 'exhausted' === $budget_state ) {
					continue;
				}

				// If this is NOT a complex task and we're reserving paid budget, skip paid
				if ( ! $is_complex && 'reserve' === $budget_state ) {
					continue;
				}
			}

			// Adjust score based on budget state
			$adjusted = $candidate;
			$score = (float) $candidate['selection_score'];

			if ( ! $is_free ) {
				// Apply budget factor to paid providers
				$budget_factor = self::budget_cost_factor( $budget_state );
				$score *= $budget_factor;
			} else {
				// Free providers get a front-loading bonus earlier in the day
				$hour = (int) gmdate( 'G' );
				if ( $hour < 12 ) {
					$score *= 1.10; // Morning: prefer free to use daily quota early
				}
			}

			$adjusted['selection_score'] = round( $score, 2 );
			$adjusted['budget_state'] = $budget_state;
			$adjusted['quiet_active'] = $quiet_active;
			$filtered[] = $adjusted;
		}

		if ( empty( $filtered ) ) {
			// Last resort: if no free providers passed filters, try paid ones ignoring budget
			if ( 'exhausted' === $budget_state || 'reserve' === $budget_state ) {
				foreach ( $candidates as $candidate ) {
					if ( $candidate['free_tier'] ) continue;
					if ( self::is_in_cooldown( $candidate['id'], $task_type ) ) continue;
					if ( $input_token_estimate > 0 && ! self::provider_can_handle_context( $candidate['id'], $input_token_estimate ) ) continue;
					if ( $quiet_active ) continue;
					$candidate['selection_score'] = round( (float) $candidate['selection_score'] * 0.3, 2 );
					$candidate['last_resort'] = true;
					$candidate['budget_state'] = $budget_state;
					return $candidate;
				}
			}
			return null;
		}

		// Sort by adjusted score
		usort( $filtered, static function ( $a, $b ) {
			return $b['selection_score'] <=> $a['selection_score'];
		} );

		$filtered[0]['budget_state'] = $budget_state;
		$filtered[0]['quiet_active'] = $quiet_active;
		return $filtered[0];
	}

	// ─── Budget state ───────────────────────────────────────────────────

	/**
	 * Determine the current budget state for the active period.
	 * Returns: fresh, approaching, reserve, or exhausted
	 */
	private static function budget_state( array $config ): string {
		$spent = self::spent_this_period( $config );

		// Check the most restrictive period
		$daily_pct = self::period_usage_pct( $spent['daily'], $config['daily_budget_usd'] );
		$weekly_pct = self::period_usage_pct( $spent['weekly'], $config['weekly_budget_usd'] );
		$monthly_pct = self::period_usage_pct( $spent['monthly'], $config['monthly_budget_usd'] );

		// Use the highest percentage consumed across all periods
		$max_pct = max( $daily_pct, $weekly_pct, $monthly_pct );

		// If monthly budget is 0, only free providers should be used
		if ( $config['monthly_budget_usd'] <= 0 && $config['daily_budget_usd'] <= 0 && $config['weekly_budget_usd'] <= 0 ) {
			return 'exhausted'; // No paid budget configured — free only
		}

		$warning = (float) $config['warning_pct'];
		$reserve_mark = 100 - (float) $config['complex_reserve_pct'];

		if ( $max_pct >= 95 ) return 'exhausted';
		if ( $max_pct >= $reserve_mark ) return 'reserve';
		if ( $max_pct >= $warning ) return 'approaching';
		return 'fresh';
	}

	private static function period_usage_pct( float $spent, float $budget ): float {
		if ( $budget <= 0 ) return 100.0; // No budget = treat as fully used (free only)
		return min( 100, ( $spent / $budget ) * 100 );
	}

	private static function spent_this_period( array $config ): array {
		$spending = self::get_spending();
		$today = gmdate( 'Y-m-d' );
		$week = gmdate( 'Y-W' );
		$month = gmdate( 'Y-m' );

		return array(
			'daily'   => (float) ( $spending['periods']['daily'][ $today ]['cost_usd'] ?? 0.0 ),
			'weekly'  => (float) ( $spending['periods']['weekly'][ $week ]['cost_usd'] ?? 0.0 ),
			'monthly'  => (float) ( $spending['periods']['monthly'][ $month ]['cost_usd'] ?? 0.0 ),
		);
	}

	private static function budget_cost_factor( string $state ): float {
		return match ( $state ) {
			'fresh'       => 1.0,
			'approaching'  => 0.70,
			'reserve'      => 0.40,
			'exhausted'    => 0.0,
			default        => 1.0,
		};
	}

	// ─── Quiet hours ────────────────────────────────────────────────────

	private static function is_quiet_hours( array $config ): bool {
		if ( empty( $config['quiet_hours_enabled'] ) ) return false;

		$tz = $config['quiet_timezone'] ?? 'America/Chicago';
		try {
			$timezone = new DateTimeZone( $tz );
		} catch ( Exception $e ) {
			$timezone = new DateTimeZone( 'UTC' );
		}

		$now = new DateTime( 'now', $timezone );
		$current = (int) $now->format( 'Gi' ); // HMM format for comparison

		$start = self::parse_time( $config['quiet_start'] ?? '22:00' );
		$end   = self::parse_time( $config['quiet_end'] ?? '06:00' );

		if ( $start <= $end ) {
			return $current >= $start && $current < $end;
		}
		// Overnight range (e.g., 22:00 to 06:00)
		return $current >= $start || $current < $end;
	}

	private static function parse_time( string $time ): int {
		$parts = explode( ':', $time );
		$h = (int) ( $parts[0] ?? 0 );
		$m = (int) ( $parts[1] ?? 0 );
		return $h * 100 + $m;
	}

	// ─── Context window filtering ───────────────────────────────────────

	private static function provider_can_handle_context( string $provider_id, int $input_tokens ): bool {
		$providers = Coordinator_Provider_Registry::get_configured_providers();
		$provider = $providers[ $provider_id ] ?? null;
		if ( null === $provider ) return false;

		$models = $provider['models'] ?? array();
		foreach ( $models as $model ) {
			if ( ! empty( $model['paid_only'] ) && $provider['free_tier']['available'] ) continue;
			$context = (int) ( $model['context'] ?? 0 );
			if ( $context >= $input_tokens ) return true;
		}
		return false;
	}

	// ─── Provider cooldown ──────────────────────────────────────────────

	private static function record_failure( string $provider_id, string $task_type ): void {
		$cooldown = get_option( self::COOLDOWN_OPTION, array() );
		if ( ! is_array( $cooldown ) ) $cooldown = array();

		$key = $provider_id . ':' . $task_type;
		if ( ! isset( $cooldown[ $key ] ) ) {
			$cooldown[ $key ] = array( 'failures' => 0, 'cooldown_until' => '' );
		}

		$cooldown[ $key ]['failures'] += 1;

		if ( $cooldown[ $key ]['failures'] >= self::MAX_CONSECUTIVE_FAILURES ) {
			$minutes = self::DEFAULT_COOLDOWN_MINUTES;
			$cooldown[ $key ]['cooldown_until'] = gmdate( 'c', time() + $minutes * MINUTE_IN_SECONDS );
		}

		update_option( self::COOLDOWN_OPTION, $cooldown, false );
	}

	private static function clear_failures( string $provider_id, string $task_type ): void {
		$cooldown = get_option( self::COOLDOWN_OPTION, array() );
		if ( ! is_array( $cooldown ) ) return;

		$key = $provider_id . ':' . $task_type;
		if ( isset( $cooldown[ $key ] ) ) {
			unset( $cooldown[ $key ] );
			update_option( self::COOLDOWN_OPTION, $cooldown, false );
		}
	}

	private static function is_in_cooldown( string $provider_id, string $task_type ): bool {
		$cooldown = get_option( self::COOLDOWN_OPTION, array() );
		if ( ! is_array( $cooldown ) ) return false;

		$key = $provider_id . ':' . $task_type;
		if ( ! isset( $cooldown[ $key ] ) ) return false;

		$until = $cooldown[ $key ]['cooldown_until'] ?? '';
		if ( '' === $until ) {
			// Has failures but not enough for cooldown yet
			return false;
		}

		$until_ts = strtotime( $until );
		if ( false === $until_ts ) return false;

		if ( time() >= $until_ts ) {
			// Cooldown expired — clear it
			unset( $cooldown[ $key ] );
			update_option( self::COOLDOWN_OPTION, $cooldown, false );
			return false;
		}

		return true;
	}

	// ─── Provider health check ──────────────────────────────────────────

	/**
	 * Test a provider's API key and connection.
	 * Returns a result array with success/failure and details.
	 *
	 * @param string $provider_id Provider ID.
	 * @return array { success: bool, message: string }
	 */
	public static function test_provider_connection( string $provider_id ): array {
		$providers = Coordinator_Provider_Registry::get_configured_providers();
		$provider = $providers[ $provider_id ] ?? null;
		if ( null === $provider ) {
			return array( 'success' => false, 'message' => 'Provider not found.' );
		}

		$api_key = Coordinator_Provider_Registry::decrypt_secret( $provider );
		if ( '' === $api_key ) {
			return array( 'success' => false, 'message' => 'API key could not be decrypted.' );
		}

		// Build a minimal test request
		$endpoint = rtrim( $provider['api_base'], '/' ) . '/models';
		$headers = array( 'Accept' => 'application/json' );

		if ( 'Authorization' === $provider['auth_header'] ) {
			$headers['Authorization'] = ( $provider['auth_prefix'] ?? '' ) . $api_key;
		} else {
			$headers[ $provider['auth_header'] ] = $api_key;
		}

		$response = wp_safe_remote_get( $endpoint, array(
			'timeout' => 15,
			'headers' => $headers,
		) );

		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => 'Could not reach ' . $provider['name'] . ': ' . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			return array( 'success' => true, 'message' => $provider['name'] . ' connection verified. API key is valid.' );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		$error = is_array( $data ) ? (string) ( $data['error']['message'] ?? $data['error'] ?? 'Unknown error' ) : 'HTTP ' . $code;

		return array( 'success' => false, 'message' => $provider['name'] . ' rejected the test: ' . $error );
	}

	// ─── Daily spending report ─────────────────────────────────────────

	/**
	 * Get a summary of today's spending and provider usage.
	 */
	public static function daily_report(): array {
		$spending = self::get_spending();
		$config = self::get_config();
		$today = gmdate( 'Y-m-d' );

		$today_data = $spending['periods']['daily'][ $today ] ?? array( 'cost_usd' => 0.0, 'requests' => 0, 'free_requests' => 0, 'paid_requests' => 0 );
		$month_data = $spending['periods']['monthly'][ gmdate( 'Y-m' ) ] ?? array( 'cost_usd' => 0.0, 'requests' => 0 );

		$providers_used = array();
		foreach ( $spending['providers'] ?? array() as $pid => $pdata ) {
			if ( $pdata['total_requests'] > 0 ) {
				$quality_rate = $pdata['total_requests'] > 0
					? round( ( $pdata['quality_accepted'] / $pdata['total_requests'] ) * 100 )
					: 0;
				$providers_used[] = array(
					'id' => $pid,
					'requests' => $pdata['total_requests'],
					'cost' => $pdata['total_cost'],
					'quality_rate' => $quality_rate,
					'avg_input_tokens' => $pdata['avg_input_tokens'] ?? 0,
					'avg_output_tokens' => $pdata['avg_output_tokens'] ?? 0,
				);
			}
		}

		// Sort by request count descending
		usort( $providers_used, static function ( $a, $b ) {
			return $b['requests'] <=> $a['requests'];
		} );

		$monthly_remaining = max( 0, (float) $config['monthly_budget_usd'] - (float) $month_data['cost_usd'] );
		$projected_monthly = ( (float) $today_data['cost_usd'] ) * (int) gmdate( 't' ) / max( 1, (int) gmdate( 'j' ) );

		return array(
			'today' => array(
				'cost' => (float) $today_data['cost_usd'],
				'requests' => (int) $today_data['requests'],
				'free_requests' => (int) ( $today_data['free_requests'] ?? 0 ),
				'paid_requests' => (int) ( $today_data['paid_requests'] ?? 0 ),
			),
			'month' => array(
				'cost' => (float) $month_data['cost_usd'],
				'requests' => (int) $month_data['requests'],
				'remaining_budget' => $monthly_remaining,
				'projected_total' => round( $projected_monthly, 4 ),
			),
			'providers_used' => $providers_used,
			'alert' => self::should_alert( $config, (float) $month_data['cost_usd'] ),
		);
	}

	private static function should_alert( array $config, float $monthly_spent ): array {
		$threshold = (float) $config['alert_threshold_pct'];
		$budget = (float) $config['monthly_budget_usd'];
		if ( $budget <= 0 ) {
			return array( 'active' => false, 'message' => '' );
		}
		$pct = ( $monthly_spent / $budget ) * 100;
		if ( $pct >= $threshold ) {
			return array(
				'active' => true,
				'message' => sprintf( 'Monthly spending has reached %.0f%% of the budget ($%.2f of $%.2f).', $pct, $monthly_spent, $budget ),
			);
		}
		return array( 'active' => false, 'message' => '' );
	}

	// ─── Admin handlers ──────────────────────────────────────────────────

	public static function handle_admin_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_save_budget' );

		$input = array(
			'daily_budget_usd'    => (float) wp_unslash( $_POST['daily_budget_usd'] ?? 0 ),
			'weekly_budget_usd'   => (float) wp_unslash( $_POST['weekly_budget_usd'] ?? 0 ),
			'monthly_budget_usd'   => (float) wp_unslash( $_POST['monthly_budget_usd'] ?? 0 ),
			'warning_pct'         => (int) wp_unslash( $_POST['warning_pct'] ?? 80 ),
			'complex_reserve_pct' => (int) wp_unslash( $_POST['complex_reserve_pct'] ?? 30 ),
			'quiet_hours_enabled'  => ! empty( $_POST['quiet_hours_enabled'] ),
			'quiet_start'         => sanitize_text_field( wp_unslash( $_POST['quiet_start'] ?? '22:00' ) ),
			'quiet_end'            => sanitize_text_field( wp_unslash( $_POST['quiet_end'] ?? '06:00' ) ),
			'quiet_timezone'       => sanitize_text_field( wp_unslash( $_POST['quiet_timezone'] ?? 'America/Chicago' ) ),
		);

		$saved = self::save_config( $input );
		if ( is_wp_error( $saved ) ) {
			wp_die( esc_html( $saved->get_error_message() ), '', array( 'response' => 400 ) );
		}

		wp_safe_redirect( add_query_arg( array( 'page' => 'coordinator-core', 'budget_saved' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	// ─── Admin render ───────────────────────────────────────────────────

	public static function render_admin_section(): void {
		$config = self::get_config();
		$report = self::daily_report();
		$saved = '1' === sanitize_key( wp_unslash( $_GET['budget_saved'] ?? '' ) );
		?>
		<style>
			#coordinator-budget { max-width: 1000px; margin: 28px 0; color: #172033; }
			#coordinator-budget * { box-sizing: border-box; }
			.cc-budget-hero { padding: 24px; border: 1px solid #c7d2fe; border-radius: 18px; background: linear-gradient(135deg, #f0f9ff 0%, #eef2ff 52%, #faf5ff 100%); box-shadow: 0 12px 30px rgba(30, 64, 175, .08); }
			.cc-budget-hero h2 { margin: 0 0 8px; font-size: clamp(22px, 4vw, 30px); }
			.cc-budget-hero p { max-width: 720px; margin: 0; color: #475569; font-size: 14px; line-height: 1.6; }
			.cc-budget-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; margin-top: 20px; }
			.cc-budget-card { padding: 20px; border: 1px solid #dbe4f0; border-radius: 14px; background: #fff; box-shadow: 0 8px 24px rgba(15,23,42,.06); }
			.cc-budget-card h4 { margin: 0 0 12px; font-size: 15px; color: #0f172a; }
			.cc-budget-stat { font-size: 28px; font-weight: 700; color: #1e3a8a; margin: 0; }
			.cc-budget-label { font-size: 12px; color: #64748b; margin: 4px 0 0; }
			.cc-budget-bar { height: 8px; margin: 10px 0 4px; border-radius: 999px; background: #e2e8f0; overflow: hidden; }
			.cc-budget-bar span { display: block; height: 100%; border-radius: inherit; }
			.cc-bar-green { background: #22c55e; }
			.cc-bar-yellow { background: #eab308; }
			.cc-bar-red { background: #ef4444; }
			.cc-budget-settings { margin-top: 24px; padding: 24px; border: 1px solid #dbe4f0; border-radius: 16px; background: #fff; }
			.cc-budget-settings h3 { margin: 0 0 16px; font-size: 18px; color: #0f172a; }
			.cc-budget-settings table th { font-size: 13px; }
			.cc-budget-settings input, .cc-budget-settings select { min-height: 40px; border-radius: 10px; }
			.cc-alert { margin-top: 16px; padding: 14px 18px; border-radius: 12px; background: #fef3c7; border: 1px solid #fde68a; color: #92400e; font-size: 13px; line-height: 1.5; }
			.cc-report-table { margin-top: 16px; }
			.cc-report-table table { font-size: 13px; }
			.cc-report-table th, .cc-report-table td { padding: 8px 10px; }
			@media (max-width: 600px) {
				.cc-budget-grid { grid-template-columns: 1fr; }
				.cc-budget-hero { padding: 20px; border-radius: 14px; }
			}
		</style>
		<div id="coordinator-budget">
			<div class="cc-budget-hero">
				<h2><?php echo esc_html__( 'Budget & Spending Controls', 'coordinator-core' ); ?></h2>
				<p><?php echo esc_html__( 'Set spending caps, track costs, and let the optimizer minimize spending by preferring free providers. The system switches before limits are reached, reserves paid budget for complex tasks, and pauses paid spending during quiet hours.', 'coordinator-core' ); ?></p>
			</div>

			<?php if ( $saved ) : ?>
				<div class="notice notice-success inline"><p><?php echo esc_html__( 'Budget settings saved.', 'coordinator-core' ); ?></p></div>
			<?php endif; ?>

			<?php if ( $report['alert']['active'] ) : ?>
				<div class="cc-alert">
					<p><strong><?php echo esc_html__( 'Spending Alert:', 'coordinator-core' ); ?></strong> <?php echo esc_html( $report['alert']['message'] ); ?></p>
				</div>
			<?php endif; ?>

			<div class="cc-budget-grid">
				<div class="cc-budget-card">
					<h4><?php echo esc_html__( 'Today', 'coordinator-core' ); ?></h4>
					<p class="cc-budget-stat">$<?php echo esc_html( number_format( $report['today']['cost'], 4 ) ); ?></p>
					<p class="cc-budget-label"><?php echo esc_html( sprintf( /* translators: request count */ __( '%d requests (%d free, %d paid)', 'coordinator-core' ), $report['today']['requests'], $report['today']['free_requests'], $report['today']['paid_requests'] ) ); ?></p>
				</div>
				<div class="cc-budget-card">
					<h4><?php echo esc_html__( 'This Month', 'coordinator-core' ); ?></h4>
					<p class="cc-budget-stat">$<?php echo esc_html( number_format( $report['month']['cost'], 4 ) ); ?></p>
					<p class="cc-budget-label"><?php echo esc_html( sprintf( /* translators: remaining budget */ __( '$%.2f remaining of $%.2f', 'coordinator-core' ), $report['month']['remaining_budget'], $config['monthly_budget_usd'] ) ); ?></p>
					<?php
					$month_pct = $config['monthly_budget_usd'] > 0 ? min( 100, round( ( $report['month']['cost'] / $config['monthly_budget_usd'] ) * 100 ) ) : 0;
					$month_bar = $month_pct < 70 ? 'cc-bar-green' : ( $month_pct < 90 ? 'cc-bar-yellow' : 'cc-bar-red' );
					?>
					<div class="cc-budget-bar"><span class="<?php echo esc_attr( $month_bar ); ?>" style="width:<?php echo esc_attr( (string) max( $month_pct, 2 ) ); ?>%"></span></div>
					<p class="cc-budget-label"><?php echo esc_html( sprintf( /* translators: projected total */ __( 'Projected: $%.2f for the month', 'coordinator-core' ), $report['month']['projected_total'] ) ); ?></p>
				</div>
			</div>

			<?php if ( ! empty( $report['providers_used'] ) ) : ?>
				<div class="cc-report-table">
					<h3 style="font-size:16px;color:#0f172a;margin:20px 0 8px"><?php echo esc_html__( 'Provider Performance', 'coordinator-core' ); ?></h3>
					<table class="widefat striped">
						<thead><tr><th>Provider</th><th>Requests</th><th>Cost</th><th>Quality Rate</th><th>Avg Tokens In</th><th>Avg Tokens Out</th></tr></thead>
						<tbody>
							<?php foreach ( $report['providers_used'] as $pu ) : ?>
								<tr>
									<td><strong><?php echo esc_html( $pu['id'] ); ?></strong></td>
									<td><?php echo esc_html( (string) $pu['requests'] ); ?></td>
									<td>$<?php echo esc_html( number_format( $pu['cost'], 4 ) ); ?></td>
									<td><?php echo esc_html( (string) $pu['quality_rate'] ); ?>%</td>
									<td><?php echo esc_html( number_format( $pu['avg_input_tokens'] ) ); ?></td>
									<td><?php echo esc_html( number_format( $pu['avg_output_tokens'] ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>

			<div class="cc-budget-settings">
				<h3><?php echo esc_html__( 'Budget Settings', 'coordinator-core' ); ?></h3>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="coordinator_save_budget">
					<?php wp_nonce_field( 'coordinator_save_budget' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th><label for="daily_budget_usd"><?php echo esc_html__( 'Daily spending cap', 'coordinator-core' ); ?></label></th>
							<td>$<input id="daily_budget_usd" name="daily_budget_usd" type="number" min="0" step="0.01" value="<?php echo esc_attr( (string) $config['daily_budget_usd'] ); ?>" style="width:120px">
							<p class="description"><?php echo esc_html__( '0 means free providers only. The optimizer will not spend paid budget during the day.', 'coordinator-core' ); ?></p></td>
						</tr>
						<tr>
							<th><label for="weekly_budget_usd"><?php echo esc_html__( 'Weekly spending cap', 'coordinator-core' ); ?></label></th>
							<td>$<input id="weekly_budget_usd" name="weekly_budget_usd" type="number" min="0" step="0.01" value="<?php echo esc_attr( (string) $config['weekly_budget_usd'] ); ?>" style="width:120px"></td>
						</tr>
						<tr>
							<th><label for="monthly_budget_usd"><?php echo esc_html__( 'Monthly spending cap', 'coordinator-core' ); ?></label></th>
							<td>$<input id="monthly_budget_usd" name="monthly_budget_usd" type="number" min="0" step="0.01" value="<?php echo esc_attr( (string) $config['monthly_budget_usd'] ); ?>" style="width:120px">
							<p class="description"><?php echo esc_html__( 'Default is $5.00 matching the AI Router cap.', 'coordinator-core' ); ?></p></td>
						</tr>
						<tr>
							<th><label for="warning_pct"><?php echo esc_html__( 'Warning threshold', 'coordinator-core' ); ?></label></th>
							<td><input id="warning_pct" name="warning_pct" type="number" min="50" max="99" value="<?php echo esc_attr( (string) $config['warning_pct'] ); ?>" style="width:80px">%
							<p class="description"><?php echo esc_html__( 'Show a spending alert when usage reaches this percentage of the monthly cap.', 'coordinator-core' ); ?></p></td>
						</tr>
						<tr>
							<th><label for="complex_reserve_pct"><?php echo esc_html__( 'Complex task reserve', 'coordinator-core' ); ?></label></th>
							<td><input id="complex_reserve_pct" name="complex_reserve_pct" type="number" min="0" max="50" value="<?php echo esc_attr( (string) $config['complex_reserve_pct'] ); ?>" style="width:80px">%
							<p class="description"><?php echo esc_html__( 'Reserve this portion of paid budget for complex tasks that free models cannot handle. Simple tasks use free providers only when this reserve is active.', 'coordinator-core' ); ?></p></td>
						</tr>
						<tr>
							<th><label for="quiet_hours_enabled"><?php echo esc_html__( 'Quiet hours', 'coordinator-core' ); ?></label></th>
							<td>
								<label><input type="checkbox" id="quiet_hours_enabled" name="quiet_hours_enabled" value="1" <?php echo $config['quiet_hours_enabled'] ? 'checked' : ''; ?>> <?php echo esc_html__( 'Pause paid spending during quiet hours', 'coordinator-core' ); ?></label>
							</td>
						</tr>
						<tr id="cc_quiet_times" style="<?php echo $config['quiet_hours_enabled'] ? '' : 'display:none'; ?>">
							<th><?php echo esc_html__( 'Quiet hours range', 'coordinator-core' ); ?></th>
							<td>
								<input id="quiet_start" name="quiet_start" type="time" value="<?php echo esc_attr( (string) $config['quiet_start'] ); ?>" style="width:100px"> <?php echo esc_html__( 'to', 'coordinator-core' ); ?>
								<input id="quiet_end" name="quiet_end" type="time" value="<?php echo esc_attr( (string) $config['quiet_end'] ); ?>" style="width:100px">
								<select id="quiet_timezone" name="quiet_timezone" style="min-height:40px">
									<?php $common_tzs = array( 'America/Chicago', 'America/New_York', 'America/Denver', 'America/Los_Angeles', 'Europe/London', 'UTC' ); ?>
									<?php foreach ( $common_tzs as $tz ) : ?>
										<option value="<?php echo esc_attr( $tz ); ?>" <?php echo $config['quiet_timezone'] === $tz ? 'selected' : ''; ?>><?php echo esc_html( $tz ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php echo esc_html__( 'Free providers are still used during quiet hours. Only paid spending is paused.', 'coordinator-core' ); ?></p>
							</td>
						</tr>
					</table>
					<?php submit_button( esc_html__( 'Save Budget Settings', 'coordinator-core' ) ); ?>
				</form>
				<script>
				(function () {
					var cb = document.getElementById('quiet_hours_enabled');
					var times = document.getElementById('cc_quiet_times');
					if (!cb || !times) return;
					cb.addEventListener('change', function () {
						times.style.display = cb.checked ? '' : 'none';
					});
				})();
				</script>
			</div>
		</div>
		<?php
	}
}
