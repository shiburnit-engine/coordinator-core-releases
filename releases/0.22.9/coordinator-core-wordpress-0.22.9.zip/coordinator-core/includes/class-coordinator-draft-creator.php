<?php
/**
 * Approval-controlled creation of nonpublic WordPress drafts.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Draft_Creator {
	private const AUDIT_OPTION          = 'coordinator_core_draft_creation_audit_v1';
	private const FINGERPRINT_META_KEY = '_coordinator_core_draft_fingerprint';
	private const AUDIT_KEY_META_KEY   = '_coordinator_core_draft_audit_key';
	private const MAX_AUDIT_RECEIPTS   = 100;
	private const MAX_TITLE_BYTES      = 1000;
	private const MAX_EXCERPT_BYTES    = 10000;
	private const MAX_CONTENT_BYTES    = 200000;
	private const ALLOWED_POST_TYPES   = array( 'page', 'post' );
	private const ALLOWED_STATUSES     = array( 'draft', 'pending' );

	public static function create_nonpublic_draft( array $arguments, int $actor_id ) {
		if ( true !== ( $arguments['confirmed'] ?? false ) ) {
			return new WP_Error( 'coordinator_draft_not_confirmed', 'Explicit confirmation is required.' );
		}

		$idempotency_key = (string) ( $arguments['idempotency_key'] ?? '' );
		if ( 1 !== preg_match( '/^[A-Za-z0-9._:-]{16,128}$/', $idempotency_key ) ) {
			return new WP_Error( 'coordinator_invalid_idempotency_key', 'idempotency_key must contain 16 to 128 safe characters.' );
		}

		$post_type   = sanitize_key( (string) ( $arguments['post_type'] ?? '' ) );
		$post_status = sanitize_key( (string) ( $arguments['post_status'] ?? '' ) );
		$post_title  = $arguments['post_title'] ?? null;
		$post_excerpt = $arguments['post_excerpt'] ?? '';
		$post_content = $arguments['post_content'] ?? '';

		if ( ! in_array( $post_type, self::ALLOWED_POST_TYPES, true ) ) {
			return new WP_Error( 'coordinator_invalid_draft_type', 'post_type must be page or post.' );
		}
		if ( ! in_array( $post_status, self::ALLOWED_STATUSES, true ) ) {
			return new WP_Error( 'coordinator_invalid_draft_status', 'post_status must be draft or pending.' );
		}
		if ( ! is_string( $post_title ) || '' === trim( $post_title ) || strlen( $post_title ) > self::MAX_TITLE_BYTES || str_contains( $post_title, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_draft_title', 'post_title must be non-empty, contain no null byte, and be at most 1000 bytes.' );
		}
		if ( ! is_string( $post_excerpt ) || strlen( $post_excerpt ) > self::MAX_EXCERPT_BYTES || str_contains( $post_excerpt, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_draft_excerpt', 'post_excerpt must contain no null byte and be at most 10000 bytes.' );
		}
		if ( ! is_string( $post_content ) || strlen( $post_content ) > self::MAX_CONTENT_BYTES || str_contains( $post_content, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_draft_content', 'post_content must contain no null byte and be at most 200000 bytes.' );
		}
		if ( $actor_id < 1 || ! user_can( $actor_id, 'manage_options' ) ) {
			return new WP_Error( 'coordinator_invalid_draft_actor', 'A valid administrator is required.' );
		}

		$request = array(
			'post_type'    => $post_type,
			'post_status'  => $post_status,
			'post_title'   => $post_title,
			'post_excerpt' => $post_excerpt,
			'post_content' => $post_content,
		);
		$request_fingerprint = hash( 'sha256', wp_json_encode( $request, JSON_UNESCAPED_SLASHES ) );
		$duplicate_identity  = $request;
		unset( $duplicate_identity['post_status'] );
		$duplicate_fingerprint = hash( 'sha256', wp_json_encode( $duplicate_identity, JSON_UNESCAPED_SLASHES ) );
		$audit_key = hash_hmac( 'sha256', $idempotency_key, wp_salt( 'auth' ) );
		$audit       = get_option( self::AUDIT_OPTION, array() );
		$audit       = is_array( $audit ) ? $audit : array();

		if ( isset( $audit[ $audit_key ] ) ) {
			$stored = $audit[ $audit_key ];
			if ( ! is_array( $stored ) || ! hash_equals( (string) ( $stored['request_fingerprint'] ?? '' ), $request_fingerprint ) ) {
				return new WP_Error( 'coordinator_idempotency_conflict', 'The idempotency key was already used for a different draft request.' );
			}
			$response = is_array( $stored['response'] ?? null ) ? $stored['response'] : array();
			$verified = self::verified_response( (int) ( $response['post_id'] ?? 0 ), $request, $actor_id, $audit_key, true, false );
			if ( is_wp_error( $verified ) ) {
				return $verified;
			}
			$response['idempotent_replay'] = true;
			$response['write_performed']   = false;
			return $response;
		}

		$duplicates = get_posts(
			array(
				'post_type'      => $post_type,
				'post_status'    => self::ALLOWED_STATUSES,
				'posts_per_page' => 2,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_key'       => self::FINGERPRINT_META_KEY,
				'meta_value'     => $duplicate_fingerprint,
			)
		);
		$duplicates = is_array( $duplicates ) ? array_values( array_map( 'intval', $duplicates ) ) : array();
		if ( array() !== $duplicates ) {
			$existing_id = $duplicates[0];
			if ( 1 === count( $duplicates ) && hash_equals( $audit_key, (string) get_post_meta( $existing_id, self::AUDIT_KEY_META_KEY, true ) ) ) {
				$response = self::verified_response( $existing_id, $request, $actor_id, $audit_key, true, true );
				if ( is_wp_error( $response ) ) {
					return $response;
				}
				self::store_audit( $audit, $audit_key, $request_fingerprint, $response );
				return $response;
			}
			return new WP_Error( 'coordinator_duplicate_draft', 'An identical nonpublic draft already exists.', array( 'existing_post_id' => $existing_id ) );
		}

		$post_id = wp_insert_post(
			array(
				'post_type'    => $post_type,
				'post_status'  => $post_status,
				'post_title'   => $post_title,
				'post_excerpt' => $post_excerpt,
				'post_content' => $post_content,
				'post_author'  => $actor_id,
				'meta_input'   => array(
					self::FINGERPRINT_META_KEY => $duplicate_fingerprint,
					self::AUDIT_KEY_META_KEY   => $audit_key,
				),
			),
			true
		);
		if ( is_wp_error( $post_id ) || ! is_int( $post_id ) || $post_id < 1 ) {
			return new WP_Error( 'coordinator_draft_creation_failed', 'WordPress rejected the nonpublic draft.' );
		}

		$response = self::verified_response( $post_id, $request, $actor_id, $audit_key, false, false );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		self::store_audit( $audit, $audit_key, $request_fingerprint, $response );
		return $response;
	}

	private static function verified_response( int $post_id, array $request, int $actor_id, string $audit_key, bool $idempotent_replay, bool $recovered_after_interruption ) {
		$post = get_post( $post_id );
		if ( ! is_object( $post ) ) {
			return new WP_Error( 'coordinator_draft_readback_failed', 'The created draft could not be read back.' );
		}
		$actual = array(
			'post_type'    => sanitize_key( (string) ( $post->post_type ?? '' ) ),
			'post_status'  => sanitize_key( (string) ( $post->post_status ?? '' ) ),
			'post_title'   => (string) ( $post->post_title ?? '' ),
			'post_excerpt' => (string) ( $post->post_excerpt ?? '' ),
			'post_content' => (string) ( $post->post_content ?? '' ),
		);
		if ( ! in_array( $actual['post_status'], self::ALLOWED_STATUSES, true ) ) {
			return new WP_Error( 'coordinator_draft_status_verification_failed', 'The created item did not remain draft or pending.', array( 'post_id' => $post_id ) );
		}
		if ( $actual !== $request ) {
			return new WP_Error( 'coordinator_draft_content_verification_failed', 'The created nonpublic draft did not match the approved request.', array( 'post_id' => $post_id ) );
		}

		$readback_hash = hash( 'sha256', wp_json_encode( $actual, JSON_UNESCAPED_SLASHES ) );
		return array(
			'status'                       => 'created',
			'post_id'                      => $post_id,
			'post_type'                    => $actual['post_type'],
			'post_status'                  => $actual['post_status'],
			'readback_sha256'              => $readback_hash,
			'receipt_id'                   => 'ccd_' . substr( hash( 'sha256', $audit_key . '|' . $post_id . '|' . $readback_hash ), 0, 24 ),
			'actor_id'                     => $actor_id,
			'created_at_utc'                => gmdate( 'c' ),
			'idempotent_replay'             => $idempotent_replay,
			'recovered_after_interruption' => $recovered_after_interruption,
			'write_performed'               => ! $idempotent_replay,
			'published'                     => false,
			'existing_content_changed'      => false,
		);
	}

	private static function store_audit( array $audit, string $audit_key, string $fingerprint, array $response ): void {
		$audit[ $audit_key ] = array( 'request_fingerprint' => $fingerprint, 'response' => $response );
		if ( count( $audit ) > self::MAX_AUDIT_RECEIPTS ) {
			$audit = array_slice( $audit, -self::MAX_AUDIT_RECEIPTS, null, true );
		}
		update_option( self::AUDIT_OPTION, $audit, false );
	}
}
