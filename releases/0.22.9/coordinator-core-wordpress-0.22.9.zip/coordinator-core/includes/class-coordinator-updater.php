<?php
/**
 * Fail-closed Coordinator Core updater.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Updater {
	private const SLUG = 'coordinator-core';
	private const PLUGIN_FILE = 'coordinator-core/coordinator-core.php';
	private const METADATA_URL = 'https://raw.githubusercontent.com/shiburnit-engine/coordinator-core-releases/main/update.json';
	private const RELEASE_PREFIX = 'https://raw.githubusercontent.com/shiburnit-engine/coordinator-core-releases/';
	private const PUBLIC_KEY = 'f4LGxWM2hUcAcz+bMFl1Jy2TN/t1Fkn4fURDXHF5q/E=';
	private const CACHE_KEY = 'coordinator_core_verified_update_v1';
	private const PACKAGE_CACHE_PREFIX = 'coordinator_core_verified_package_';

	public static function boot(): void {
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'offer_update' ) );
		add_filter( 'plugins_api', array( self::class, 'plugin_information' ), 20, 3 );
		add_filter( 'upgrader_pre_download', array( self::class, 'verify_download' ), 10, 4 );
	}

	public static function offer_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$metadata = self::get_verified_metadata();
		if ( is_wp_error( $metadata ) || version_compare( COORDINATOR_CORE_VERSION, $metadata['version'], '>=' ) ) {
			return $transient;
		}

		set_site_transient( self::package_cache_key( $metadata['package_url'] ), $metadata, 30 * MINUTE_IN_SECONDS );

		$transient->response[ self::PLUGIN_FILE ] = (object) array(
			'id'           => self::SLUG,
			'slug'         => self::SLUG,
			'plugin'       => self::PLUGIN_FILE,
			'new_version'  => $metadata['version'],
			'url'          => 'https://github.com/shiburnit-engine/coordinator-core-releases',
			'package'      => $metadata['package_url'],
			'requires'     => $metadata['requires'],
			'requires_php' => $metadata['requires_php'],
			'tested'       => $metadata['tested'],
		);

		return $transient;
	}

	public static function plugin_information( $result, string $action, $args ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) || self::SLUG !== ( $args->slug ?? '' ) ) {
			return $result;
		}

		$metadata = self::get_verified_metadata();
		if ( is_wp_error( $metadata ) ) {
			return $result;
		}

		return (object) array(
			'name'          => 'Coordinator Core',
			'slug'          => self::SLUG,
			'version'       => $metadata['version'],
			'author'        => 'Coordinator Core',
			'homepage'      => 'https://github.com/shiburnit-engine/coordinator-core-releases',
			'requires'      => $metadata['requires'],
			'requires_php'  => $metadata['requires_php'],
			'tested'        => $metadata['tested'],
			'last_updated'  => $metadata['published_at'],
			'download_link' => $metadata['package_url'],
			'sections'      => array( 'description' => 'A signed, administrator-approved Coordinator Core release.' ),
		);
	}

	public static function verify_download( $reply, string $package, $upgrader, array $hook_extra ) {
		if ( ! empty( $reply ) || self::PLUGIN_FILE !== ( $hook_extra['plugin'] ?? '' ) ) {
			return $reply;
		}

		$metadata = get_site_transient( self::package_cache_key( $package ) );
		if ( ! is_array( $metadata ) || ! isset( $metadata['package_url'] ) || ! hash_equals( (string) $metadata['package_url'], $package ) ) {
			$metadata = self::get_verified_metadata( true );
			if ( is_wp_error( $metadata ) ) {
				return $metadata;
			}
			if ( ! hash_equals( $metadata['package_url'], $package ) ) {
				return new WP_Error( 'coordinator_update_package_mismatch', 'Coordinator Core blocked an unrecognized update package.' );
			}
		}

		$temporary_file = download_url( $package, 300 );
		if ( is_wp_error( $temporary_file ) ) {
			return $temporary_file;
		}

		$actual_checksum = hash_file( 'sha256', $temporary_file );
		if ( ! is_string( $actual_checksum ) || ! hash_equals( $metadata['package_sha256'], strtolower( $actual_checksum ) ) ) {
			wp_delete_file( $temporary_file );
			return new WP_Error( 'coordinator_update_checksum_failed', 'Coordinator Core blocked an update whose package checksum did not match its signed metadata.' );
		}

		return $temporary_file;
	}

	private static function package_cache_key( string $package ): string {
		return self::PACKAGE_CACHE_PREFIX . hash( 'sha256', $package );
	}

	public static function get_verified_metadata( bool $force = false ) {
		if ( ! $force ) {
			$cached = get_site_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$response = wp_safe_remote_get(
			self::METADATA_URL,
			array( 'timeout' => 15, 'redirection' => 0, 'headers' => array( 'Accept' => 'application/json' ) )
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'coordinator_update_metadata_unavailable', 'Coordinator Core update metadata is unavailable.' );
		}

		$metadata = json_decode( wp_remote_retrieve_body( $response ), true );
		$verified = self::validate_metadata( $metadata );
		if ( is_wp_error( $verified ) ) {
			return $verified;
		}

		set_site_transient( self::CACHE_KEY, $verified, 15 * MINUTE_IN_SECONDS );
		return $verified;
	}

	public static function validate_metadata( $metadata ) {
		$fields = array( 'schema_version', 'slug', 'version', 'package_url', 'package_sha256', 'requires', 'requires_php', 'tested', 'published_at' );
		if ( ! is_array( $metadata ) || ! isset( $metadata['signature'] ) ) {
			return new WP_Error( 'coordinator_update_metadata_invalid', 'Coordinator Core update metadata is incomplete.' );
		}

		$signed = array();
		foreach ( $fields as $field ) {
			if ( ! array_key_exists( $field, $metadata ) || ! is_scalar( $metadata[ $field ] ) ) {
				return new WP_Error( 'coordinator_update_metadata_invalid', 'Coordinator Core update metadata is incomplete.' );
			}
			$signed[ $field ] = $metadata[ $field ];
		}

		if ( 1 !== $signed['schema_version'] || self::SLUG !== $signed['slug'] || ! preg_match( '/^\d+\.\d+\.\d+$/', (string) $signed['version'] ) ) {
			return new WP_Error( 'coordinator_update_metadata_invalid', 'Coordinator Core update metadata has invalid identity or version fields.' );
		}
		if ( ! preg_match( '/^[a-f0-9]{64}$/', (string) $signed['package_sha256'] ) || ! str_starts_with( (string) $signed['package_url'], self::RELEASE_PREFIX ) ) {
			return new WP_Error( 'coordinator_update_metadata_invalid', 'Coordinator Core update metadata has an invalid package location or checksum.' );
		}
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return new WP_Error( 'coordinator_update_signature_unavailable', 'Coordinator Core cannot verify updates because Ed25519 support is unavailable.' );
		}

		$signature = base64_decode( (string) $metadata['signature'], true );
		$public_key = base64_decode( self::PUBLIC_KEY, true );
		$payload = wp_json_encode( $signed, JSON_UNESCAPED_SLASHES );
		if ( false === $signature || false === $public_key || ! is_string( $payload ) || ! sodium_crypto_sign_verify_detached( $signature, $payload, $public_key ) ) {
			return new WP_Error( 'coordinator_update_signature_failed', 'Coordinator Core blocked update metadata with an invalid signature.' );
		}

		return $signed;
	}
}
