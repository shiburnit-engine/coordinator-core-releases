<?php
/**
 * Coordinator Core foundation.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Core {
	private const REST_NAMESPACE = 'coordinator-core/v1';

	public static function boot(): void {
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
		add_action( 'admin_menu', array( self::class, 'register_admin_page' ) );
		Coordinator_Operational_State::boot();
		Coordinator_Workbench::boot();
		Coordinator_Updater::boot();
		Coordinator_OAuth_Foundation::boot();
	}

	public static function register_rest_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/health',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'health_response' ),
				'permission_callback' => array( self::class, 'can_view_coordinator' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/continue-work',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'continue_work_response' ),
				'permission_callback' => array( self::class, 'can_view_coordinator' ),
			)
		);
	}

	public static function register_admin_page(): void {
		add_menu_page(
			esc_html__( 'Coordinator', 'coordinator-core' ),
			esc_html__( 'Coordinator', 'coordinator-core' ),
			'manage_options',
			'coordinator-core',
			array( self::class, 'render_admin_page' ),
			'dashicons-clipboard',
			58
		);
	}

	public static function can_view_coordinator(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function health_response() {
		$summary = self::get_continue_work_summary();

		return rest_ensure_response(
			array(
				'service'               => 'coordinator-core',
				'version'               => COORDINATOR_CORE_VERSION,
				'status'                => 'ready',
				'permission_boundary'   => 'administrator',
				'continue_work_adapter' => null === $summary ? 'waiting' : 'ready',
				'status_source'         => Coordinator_Operational_State::OPTION,
				'writes_enabled'        => false,
				'operational_state_writes_available' => true,
				'nonpublic_draft_creation_available' => true,
				'rendered_page_verification_available' => true,
				'media_upload_available' => true,
				'connector_mode'        => 'mcp-streamable-http-scoped',
				'ai_router'             => Coordinator_AI_Router::status(),
				'workbench'             => Coordinator_Workbench::status(),
			)
		);
	}

	public static function continue_work_response() {
		$summary = self::get_continue_work_summary();

		return rest_ensure_response(
			array(
				'service'        => 'coordinator-core',
				'connected'      => null !== $summary,
				'status'         => null === $summary ? 'waiting' : 'ready',
				'summary'        => $summary,
				'writes_enabled' => false,
			)
		);
	}

	public static function get_continue_work_summary(): ?array {
		return Coordinator_Operational_State::get();
	}

	public static function render_admin_page(): void {
		if ( ! self::can_view_coordinator() ) {
			wp_die( esc_html__( 'You do not have permission to view Coordinator.', 'coordinator-core' ) );
		}

		$summary = self::get_continue_work_summary();
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( 'Coordinator — Continue Work', 'coordinator-core' ); ?></h1>
			<h2><?php echo esc_html__( 'Built-in WordPress Connector', 'coordinator-core' ); ?></h2>
			<p><?php echo esc_html__( 'Secure read-only handshake active. HTTPS and administrator permission are required, and all Connector writes remain disabled.', 'coordinator-core' ); ?></p>
			<p><?php echo esc_html__( 'OAuth 2.1 authorization-code flow active with administrator consent, PKCE S256, short-lived one-time codes, durable hashed token storage, rotating refresh tokens, audience binding, reuse detection, and revocation.', 'coordinator-core' ); ?></p>
			<p><?php echo esc_html__( 'OAuth access is limited to approved Coordinator scopes. Paid advisory AI delegation requires its own scope and explicit confirmation.', 'coordinator-core' ); ?></p>
			<p><?php echo esc_html__( 'The MCP Streamable HTTP endpoint is active with authenticated profile, Coordinator status, site inventory, and Continue Work tools.', 'coordinator-core' ); ?></p>
			<p><?php echo esc_html__( 'Native updates use a credential-free public release channel. Signed metadata and the downloaded package checksum must both pass verification before WordPress can install an administrator-approved update.', 'coordinator-core' ); ?></p>
			<p><?php echo esc_html__( 'Approval-controlled writes are limited to validated Coordinator operational state, one exact-match hash-bound content edit with revision recovery, and one new page or post in draft or pending status with duplicate protection and readback, and one allowlisted image upload to a selected nonpublic draft with required alt text, file-signature validation, duplicate protection, and readback. Read-only rendered verification is limited to one selected nonpublic page or post and a same-site administrator preview URL without credentials. AI delegation is advisory-only and budget-capped. Publishing-status changes, plugins, themes, deployment, files, users, and deletion remain unavailable.', 'coordinator-core' ); ?></p>
			<?php if ( null === $summary ) : ?>
				<div class="notice notice-info inline">
					<p><?php echo esc_html__( 'Coordinator is ready. Valid Continue Work data has not been connected yet.', 'coordinator-core' ); ?></p>
				</div>
			<?php else : ?>
				<p><strong><?php echo esc_html__( 'Project:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $summary['project_key'] ); ?></p>
				<p><strong><?php echo esc_html__( 'Status:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $summary['status'] ); ?></p>
				<p><strong><?php echo esc_html__( 'Progress:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $summary['progress']['percent_complete'] ); ?>%</p>
				<p><strong><?php echo esc_html__( 'Next:', 'coordinator-core' ); ?></strong> <?php echo esc_html( (string) $summary['exact_next_action'] ); ?></p>
				<?php $continue = $summary['continue_work']; ?>
				<?php if ( ! empty( $continue['enabled'] ) && ! empty( $continue['url'] ) ) : ?>
					<p><a class="button button-primary" href="<?php echo esc_url( (string) $continue['url'] ); ?>"><?php echo esc_html( (string) $continue['label'] ); ?></a></p>
				<?php else : ?>
					<p class="description"><?php echo esc_html( (string) ( $continue['reason'] ?: 'Continue Work is not ready.' ) ); ?></p>
				<?php endif; ?>
			<?php endif; ?>
			<?php Coordinator_Workbench::render_admin_section( $summary ); ?>
			<hr>
			<h2><?php echo esc_html__( 'Operational State', 'coordinator-core' ); ?></h2>
			<p><?php echo esc_html__( 'Administrators can maintain the verified state used by Continue Work. This does not enable Connector writes.', 'coordinator-core' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="coordinator_save_operational_state">
				<?php wp_nonce_field( 'coordinator_save_operational_state' ); ?>
				<table class="form-table" role="presentation">
					<tr><th><label for="project_key"><?php echo esc_html__( 'Project key', 'coordinator-core' ); ?></label></th><td><input class="regular-text" id="project_key" name="project_key" required value="<?php echo esc_attr( (string) ( $summary['project_key'] ?? '' ) ); ?>"></td></tr>
					<tr><th><label for="project_name"><?php echo esc_html__( 'Project name', 'coordinator-core' ); ?></label></th><td><input class="regular-text" id="project_name" name="project_name" value="<?php echo esc_attr( (string) ( $summary['project_name'] ?? '' ) ); ?>"></td></tr>
					<tr><th><label for="status"><?php echo esc_html__( 'Status', 'coordinator-core' ); ?></label></th><td><select id="status" name="status"><?php foreach ( array( 'working', 'waiting', 'needs_you', 'failed', 'completed' ) as $state ) : ?><option value="<?php echo esc_attr( $state ); ?>" <?php selected( $summary['status'] ?? 'waiting', $state ); ?>><?php echo esc_html( ucwords( str_replace( '_', ' ', $state ) ) ); ?></option><?php endforeach; ?></select></td></tr>
					<tr><th><label for="phase"><?php echo esc_html__( 'Phase', 'coordinator-core' ); ?></label></th><td><input class="regular-text" id="phase" name="phase" value="<?php echo esc_attr( (string) ( $summary['phase'] ?? '' ) ); ?>"></td></tr>
					<tr><th><label for="stage"><?php echo esc_html__( 'Stage', 'coordinator-core' ); ?></label></th><td><input class="regular-text" id="stage" name="stage" value="<?php echo esc_attr( (string) ( $summary['stage'] ?? '' ) ); ?>"></td></tr>
					<tr><th><label for="percent_complete"><?php echo esc_html__( 'Checkpoint progress', 'coordinator-core' ); ?></label></th><td><input id="percent_complete" name="percent_complete" type="number" min="0" max="100" step="0.01" required value="<?php echo esc_attr( (string) ( $summary['progress']['percent_complete'] ?? 0 ) ); ?>">%</td></tr>
					<tr><th><label for="current_work"><?php echo esc_html__( 'Current work', 'coordinator-core' ); ?></label></th><td><textarea class="large-text" id="current_work" name="current_work" rows="3"><?php echo esc_textarea( (string) ( $summary['current_work'] ?? '' ) ); ?></textarea></td></tr>
					<tr><th><label for="blockers"><?php echo esc_html__( 'Blockers', 'coordinator-core' ); ?></label></th><td><textarea class="large-text" id="blockers" name="blockers" rows="3"><?php echo esc_textarea( implode( "\n", $summary['blockers'] ?? array() ) ); ?></textarea><p class="description"><?php echo esc_html__( 'One blocker per line.', 'coordinator-core' ); ?></p></td></tr>
					<tr><th><label for="exact_next_action"><?php echo esc_html__( 'Exact next action', 'coordinator-core' ); ?></label></th><td><textarea class="large-text" id="exact_next_action" name="exact_next_action" rows="3" required><?php echo esc_textarea( (string) ( $summary['exact_next_action'] ?? '' ) ); ?></textarea></td></tr>
					<tr><th><label for="continue_url"><?php echo esc_html__( 'Continue Work URL', 'coordinator-core' ); ?></label></th><td><input class="large-text" id="continue_url" name="continue_url" type="url" value="<?php echo esc_attr( (string) ( $summary['continue_work']['url'] ?? '' ) ); ?>"></td></tr>
					<tr><th><label for="continue_label"><?php echo esc_html__( 'Button label', 'coordinator-core' ); ?></label></th><td><input class="regular-text" id="continue_label" name="continue_label" value="<?php echo esc_attr( (string) ( $summary['continue_work']['label'] ?? 'Continue Work' ) ); ?>"></td></tr>
				</table>
				<?php submit_button( esc_html__( 'Save Operational State', 'coordinator-core' ) ); ?>
			</form>
			<?php Coordinator_AI_Router::render_admin_section(); ?>
			<?php Coordinator_Provider_Registry::render_admin_section(); ?>
			<?php Coordinator_Budget_Manager::render_admin_section(); ?>
		</div>
		<?php
	}
}
