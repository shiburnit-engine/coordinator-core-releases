<?php
/**
 * Conflict-safe, approval-controlled WordPress content edits.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Content_Editor {
	private const AUDIT_OPTION = 'coordinator_core_content_edit_audit_v1';
	private const MAX_AUDIT_RECEIPTS = 100;

	public static function apply_exact_edit( array $arguments, int $actor_id ) {
		if ( true !== ( $arguments['confirmed'] ?? false ) ) {
			return new WP_Error( 'coordinator_content_edit_not_confirmed', 'Explicit confirmation is required.' );
		}

		$expected_hash = strtolower( (string) ( $arguments['expected_content_sha256'] ?? '' ) );
		$idempotency_key = (string) ( $arguments['idempotency_key'] ?? '' );
		if ( 1 !== preg_match( '/^[a-f0-9]{64}$/', $expected_hash ) ) {
			return new WP_Error( 'coordinator_invalid_expected_hash', 'expected_content_sha256 must be a 64-character SHA-256 value.' );
		}
		if ( 1 !== preg_match( '/^[A-Za-z0-9._:-]{16,128}$/', $idempotency_key ) ) {
			return new WP_Error( 'coordinator_invalid_idempotency_key', 'idempotency_key must contain 16 to 128 safe characters.' );
		}

		$request = array(
			'post_id' => $arguments['post_id'] ?? null,
			'field' => $arguments['field'] ?? 'post_content',
			'old_content' => $arguments['old_content'] ?? null,
			'new_content' => $arguments['new_content'] ?? null,
			'expected_content_sha256' => $expected_hash,
		);
		$fingerprint = hash( 'sha256', wp_json_encode( $request, JSON_UNESCAPED_SLASHES ) );
		$audit_key = hash_hmac( 'sha256', $idempotency_key, wp_salt( 'auth' ) );
		$audit = get_option( self::AUDIT_OPTION, array() );
		$audit = is_array( $audit ) ? $audit : array();

		if ( isset( $audit[ $audit_key ] ) ) {
			$stored = $audit[ $audit_key ];
			if ( ! is_array( $stored ) || ! hash_equals( (string) ( $stored['request_fingerprint'] ?? '' ), $fingerprint ) ) {
				return new WP_Error( 'coordinator_idempotency_conflict', 'The idempotency key was already used for a different content edit.' );
			}
			$response = is_array( $stored['response'] ?? null ) ? $stored['response'] : array();
			$response['idempotent_replay'] = true;
			return $response;
		}

		$preview = Coordinator_Content_Reader::preview_content_edit( $request );
		if ( is_wp_error( $preview ) ) {
			return $preview;
		}
		if ( 'ready' !== ( $preview['status'] ?? '' ) ) {
			return new WP_Error( 'coordinator_content_edit_conflict', 'The exact-match edit is no longer safe to apply.', array( 'status' => $preview['status'] ?? 'conflict', 'occurrence_count' => $preview['occurrence_count'] ?? 0 ) );
		}
		if ( ! hash_equals( $expected_hash, (string) $preview['expected_content_sha256'] ) ) {
			return new WP_Error( 'coordinator_stale_content_state', 'WordPress content changed after preview. Create and approve a new preview.' );
		}

		$post = get_post( (int) $request['post_id'] );
		$field = (string) $request['field'];
		$current = (string) ( $post->{$field} ?? '' );
		$offset = strpos( $current, (string) $request['old_content'] );
		if ( false === $offset ) {
			return new WP_Error( 'coordinator_content_edit_conflict', 'The exact match disappeared before the edit could be applied.' );
		}
		$proposed = substr_replace( $current, (string) $request['new_content'], $offset, strlen( (string) $request['old_content'] ) );
		$expected_proposed_hash = hash( 'sha256', $proposed );

		if ( ! post_type_supports( (string) $post->post_type, 'revisions' ) ) {
			return new WP_Error( 'coordinator_revision_recovery_unavailable', 'The selected content type does not support WordPress revision recovery.' );
		}
		$force_revision = static function ( bool $check_for_changes ): bool {
			return false;
		};
		add_filter( 'wp_save_post_revision_check_for_changes', $force_revision, PHP_INT_MAX, 1 );
		try {
			$revision_id = wp_save_post_revision( (int) $post->ID );
		} finally {
			remove_filter( 'wp_save_post_revision_check_for_changes', $force_revision, PHP_INT_MAX );
		}
		if ( is_wp_error( $revision_id ) || ! is_int( $revision_id ) || 1 > $revision_id ) {
			return new WP_Error( 'coordinator_revision_backup_failed', 'A recovery revision could not be created, so the edit was not attempted.' );
		}

		$updated = wp_update_post( array( 'ID' => (int) $post->ID, $field => $proposed ), true );
		if ( is_wp_error( $updated ) || (int) $post->ID !== (int) $updated ) {
			return new WP_Error( 'coordinator_content_update_failed', 'WordPress rejected the content edit. The saved revision remains available.' );
		}

		$verified_post = get_post( (int) $post->ID );
		$verified = is_object( $verified_post ) ? (string) ( $verified_post->{$field} ?? '' ) : '';
		$verified_hash = hash( 'sha256', $verified );
		if ( ! hash_equals( $expected_proposed_hash, $verified_hash ) ) {
			$restored = wp_restore_post_revision( $revision_id );
			return new WP_Error(
				'coordinator_content_verification_failed',
				true === $restored || (int) $post->ID === (int) $restored
					? 'The saved value did not verify and WordPress restored the recovery revision.'
					: 'The saved value did not verify and automatic revision recovery must be checked by an administrator.'
			);
		}

		$receipt_id = 'ccw_' . substr( hash( 'sha256', $audit_key . '|' . $verified_hash ), 0, 24 );
		$response = array(
			'status' => 'applied',
			'post_id' => (int) $post->ID,
			'post_type' => sanitize_key( (string) $post->post_type ),
			'post_status' => sanitize_key( (string) $post->post_status ),
			'field' => $field,
			'before_sha256' => $expected_hash,
			'after_sha256' => $verified_hash,
			'recovery_revision_id' => $revision_id,
			'receipt_id' => $receipt_id,
			'actor_id' => $actor_id,
			'applied_at_utc' => gmdate( 'c' ),
			'idempotent_replay' => false,
			'published_status_changed' => false,
		);

		$audit[ $audit_key ] = array( 'request_fingerprint' => $fingerprint, 'response' => $response );
		if ( count( $audit ) > self::MAX_AUDIT_RECEIPTS ) {
			$audit = array_slice( $audit, -self::MAX_AUDIT_RECEIPTS, null, true );
		}
		update_option( self::AUDIT_OPTION, $audit, false );

		return $response;
	}
}
