<?php
/**
 * Administrator-only, read-only WordPress content access.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Content_Reader {
	private const REST_NAMESPACE     = 'coordinator-core/v1';
	private const ALLOWED_FIELDS     = array( 'post_title', 'post_excerpt', 'post_content' );
	private const DEFAULT_MAX_LENGTH = 50000;
	private const MAX_LENGTH         = 100000;
	private const DEFAULT_RESULTS    = 20;
	private const MAX_RESULTS        = 100;
	private const SNIPPET_LENGTH     = 400;
	private const CONTEXT_LENGTH     = 200;
	private const MAX_EDIT_FIELD_BYTES = 1000000;
	private const MAX_OLD_CONTENT_BYTES = 10000;
	private const MAX_NEW_CONTENT_BYTES = 50000;

	public static function register_rest_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/connector/content/read',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'read_rest_response' ),
				'permission_callback' => array( Coordinator_Connector::class, 'can_read_connector' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/connector/content/search',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( self::class, 'search_rest_response' ),
				'permission_callback' => array( Coordinator_Connector::class, 'can_read_connector' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/connector/content/edit-preview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( self::class, 'preview_edit_rest_response' ),
				'permission_callback' => array( Coordinator_Connector::class, 'can_read_connector' ),
			)
		);
	}

	public static function read_rest_response( WP_REST_Request $request ) {
		$result = self::read_content( $request->get_params() );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function search_rest_response( WP_REST_Request $request ) {
		$result = self::search_content( $request->get_params() );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function preview_edit_rest_response( WP_REST_Request $request ) {
		$result = self::preview_content_edit( $request->get_json_params() );
		return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
	}

	public static function read_content( array $arguments ) {
		$target = self::resolve_target( $arguments );
		if ( is_wp_error( $target ) ) {
			return $target;
		}

		$max_length = self::bounded_integer(
			$arguments['max_length'] ?? self::DEFAULT_MAX_LENGTH,
			1,
			self::MAX_LENGTH
		);
		if ( null === $max_length ) {
			return new WP_Error( 'coordinator_invalid_max_length', 'max_length must be an integer between 1 and 100000.' );
		}

		$value     = $target['value'];
		$truncated = strlen( $value ) > $max_length;

		return array(
			'post_id'        => $target['post_id'],
			'post_type'      => $target['post_type'],
			'post_status'    => $target['post_status'],
			'field'          => $target['field'],
			'content'        => $truncated ? substr( $value, 0, $max_length ) : $value,
			'content_bytes'  => strlen( $value ),
			'returned_bytes' => $truncated ? $max_length : strlen( $value ),
			'truncated'      => $truncated,
			'read_only'      => true,
		);
	}

	public static function search_content( array $arguments ) {
		$target = self::resolve_target( $arguments );
		if ( is_wp_error( $target ) ) {
			return $target;
		}

		$pattern = $arguments['pattern'] ?? null;
		if ( ! is_string( $pattern ) || '' === $pattern || strlen( $pattern ) > 500 || str_contains( $pattern, "\0" ) || str_contains( $pattern, "\n" ) || str_contains( $pattern, "\r" ) ) {
			return new WP_Error( 'coordinator_invalid_pattern', 'pattern must be one non-empty line of at most 500 bytes.' );
		}

		$case_sensitive = $arguments['case_sensitive'] ?? false;
		if ( ! is_bool( $case_sensitive ) ) {
			return new WP_Error( 'coordinator_invalid_case_setting', 'case_sensitive must be a boolean.' );
		}

		$max_results = self::bounded_integer(
			$arguments['max_results'] ?? self::DEFAULT_RESULTS,
			1,
			self::MAX_RESULTS
		);
		if ( null === $max_results ) {
			return new WP_Error( 'coordinator_invalid_result_limit', 'max_results must be an integer between 1 and 100.' );
		}

		$normalized = str_replace( array( "\r\n", "\r" ), "\n", $target['value'] );
		$lines      = explode( "\n", $normalized );
		$matches    = array();
		$total      = 0;

		foreach ( $lines as $index => $line ) {
			$found = $case_sensitive ? false !== strpos( $line, $pattern ) : false !== stripos( $line, $pattern );
			if ( ! $found ) {
				continue;
			}

			++$total;
			if ( count( $matches ) >= $max_results ) {
				continue;
			}

			$matches[] = array(
				'line'                     => $index + 1,
				'content'                  => self::truncate( $line, self::SNIPPET_LENGTH ),
				'snippet_truncated'        => strlen( $line ) > self::SNIPPET_LENGTH,
				'line_bytes'               => strlen( $line ),
				'context_before'           => 0 < $index ? self::truncate( $lines[ $index - 1 ], self::CONTEXT_LENGTH ) : '',
				'context_before_truncated' => 0 < $index && strlen( $lines[ $index - 1 ] ) > self::CONTEXT_LENGTH,
				'context_after'            => $index + 1 < count( $lines ) ? self::truncate( $lines[ $index + 1 ], self::CONTEXT_LENGTH ) : '',
				'context_after_truncated'  => $index + 1 < count( $lines ) && strlen( $lines[ $index + 1 ] ) > self::CONTEXT_LENGTH,
			);
		}

		return array(
			'post_id'       => $target['post_id'],
			'post_type'     => $target['post_type'],
			'post_status'   => $target['post_status'],
			'field'         => $target['field'],
			'pattern'       => $pattern,
			'case_sensitive'=> $case_sensitive,
			'matches'       => $matches,
			'total_matches' => $total,
			'total_lines'   => count( $lines ),
			'truncated'     => $total > count( $matches ),
			'read_only'     => true,
		);
	}

	public static function preview_content_edit( array $arguments ) {
		$target = self::resolve_target( $arguments );
		if ( is_wp_error( $target ) ) {
			return $target;
		}

		$old_content = $arguments['old_content'] ?? null;
		$new_content = $arguments['new_content'] ?? null;
		if ( ! is_string( $old_content ) || '' === $old_content || strlen( $old_content ) > self::MAX_OLD_CONTENT_BYTES || str_contains( $old_content, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_old_content', 'old_content must be non-empty, contain no null byte, and be at most 10000 bytes.' );
		}
		if ( ! is_string( $new_content ) || strlen( $new_content ) > self::MAX_NEW_CONTENT_BYTES || str_contains( $new_content, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_new_content', 'new_content must contain no null byte and be at most 50000 bytes.' );
		}

		$current = $target['value'];
		if ( strlen( $current ) > self::MAX_EDIT_FIELD_BYTES ) {
			return new WP_Error( 'coordinator_content_too_large', 'The selected field exceeds the 1000000-byte preview limit.' );
		}

		$occurrences = substr_count( $current, $old_content );
		$status      = 1 === $occurrences ? 'ready' : ( 0 === $occurrences ? 'no_match' : 'multiple_matches' );
		$result      = array(
			'post_id'                 => $target['post_id'],
			'post_type'               => $target['post_type'],
			'post_status'             => $target['post_status'],
			'field'                   => $target['field'],
			'status'                  => $status,
			'can_apply_exactly_once'  => 1 === $occurrences,
			'occurrence_count'        => $occurrences,
			'expected_content_sha256' => hash( 'sha256', $current ),
			'old_content_bytes'       => strlen( $old_content ),
			'new_content_bytes'       => strlen( $new_content ),
			'byte_delta'              => strlen( $new_content ) - strlen( $old_content ),
			'current_preview'         => '',
			'proposed_preview'        => '',
			'proposed_content_sha256' => '',
			'write_performed'         => false,
			'read_only'               => true,
		);

		if ( 1 !== $occurrences ) {
			return $result;
		}

		$offset   = strpos( $current, $old_content );
		$start    = max( 0, $offset - self::CONTEXT_LENGTH );
		$prefix   = substr( $current, $start, $offset - $start );
		$suffix   = substr( $current, $offset + strlen( $old_content ), self::CONTEXT_LENGTH );
		$proposed = substr_replace( $current, $new_content, $offset, strlen( $old_content ) );

		$result['current_preview']         = self::truncate( $prefix . $old_content . $suffix, 1000 );
		$result['proposed_preview']        = self::truncate( $prefix . $new_content . $suffix, 1000 );
		$result['proposed_content_sha256'] = hash( 'sha256', $proposed );

		return $result;
	}

	private static function resolve_target( array $arguments ) {
		$post_id = self::bounded_integer( $arguments['post_id'] ?? null, 1, PHP_INT_MAX );
		if ( null === $post_id ) {
			return new WP_Error( 'coordinator_invalid_post_id', 'post_id must be a positive integer.' );
		}

		$field = $arguments['field'] ?? 'post_content';
		if ( ! is_string( $field ) || ! in_array( $field, self::ALLOWED_FIELDS, true ) ) {
			return new WP_Error( 'coordinator_invalid_content_field', 'field must be post_title, post_excerpt, or post_content.' );
		}

		$post = get_post( $post_id );
		if ( ! is_object( $post ) || ! isset( $post->ID ) ) {
			return new WP_Error( 'coordinator_content_not_found', 'The requested WordPress content item was not found.' );
		}

		return array(
			'post_id'     => (int) $post->ID,
			'post_type'   => sanitize_key( (string) ( $post->post_type ?? '' ) ),
			'post_status' => sanitize_key( (string) ( $post->post_status ?? '' ) ),
			'field'       => $field,
			'value'       => (string) ( $post->{$field} ?? '' ),
		);
	}

	private static function bounded_integer( $value, int $minimum, int $maximum ): ?int {
		if ( is_string( $value ) && preg_match( '/^\d+$/', $value ) ) {
			$value = (int) $value;
		}
		if ( ! is_int( $value ) || $value < $minimum || $value > $maximum ) {
			return null;
		}
		return $value;
	}

	private static function truncate( string $value, int $limit ): string {
		return strlen( $value ) > $limit ? substr( $value, 0, $limit ) : $value;
	}
}
