<?php
/**
 * Read-only verification of rendered nonpublic WordPress content.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Rendered_Page_Verifier {
	private const ALLOWED_POST_TYPES = array( 'page', 'post' );
	private const ALLOWED_STATUSES   = array( 'draft', 'pending', 'private' );
	private const DEFAULT_MAX_LENGTH = 50000;
	private const MAX_LENGTH         = 100000;

	public static function verify( array $arguments ) {
		$post_id = self::bounded_integer( $arguments['post_id'] ?? null, 1, PHP_INT_MAX );
		if ( null === $post_id ) {
			return new WP_Error( 'coordinator_invalid_post_id', 'post_id must be a positive integer.' );
		}

		$max_length = self::bounded_integer(
			$arguments['max_length'] ?? self::DEFAULT_MAX_LENGTH,
			1,
			self::MAX_LENGTH
		);
		if ( null === $max_length ) {
			return new WP_Error( 'coordinator_invalid_max_length', 'max_length must be an integer between 1 and 100000.' );
		}

		$post = get_post( $post_id );
		if ( ! is_object( $post ) || ! isset( $post->ID ) ) {
			return new WP_Error( 'coordinator_content_not_found', 'The requested WordPress content item was not found.' );
		}

		$post_type   = sanitize_key( (string) ( $post->post_type ?? '' ) );
		$post_status = sanitize_key( (string) ( $post->post_status ?? '' ) );
		if ( ! in_array( $post_type, self::ALLOWED_POST_TYPES, true ) ) {
			return new WP_Error( 'coordinator_render_type_not_allowed', 'Rendered verification is limited to pages and posts.' );
		}
		if ( ! in_array( $post_status, self::ALLOWED_STATUSES, true ) ) {
			return new WP_Error( 'coordinator_render_status_not_allowed', 'Rendered verification is limited to draft, pending, or private content.' );
		}

		$raw_content = (string) ( $post->post_content ?? '' );
		$rendered    = self::render_content( $post, $raw_content );
		if ( ! is_string( $rendered ) ) {
			return new WP_Error( 'coordinator_render_failed', 'WordPress did not return rendered content as text.' );
		}

		$preview_url = self::safe_preview_url( $post );
		if ( is_wp_error( $preview_url ) ) {
			return $preview_url;
		}

		$visible_text = html_entity_decode( wp_strip_all_tags( $rendered, true ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$visible_text = preg_replace( '/\s+/u', ' ', trim( $visible_text ) );
		$visible_text = is_string( $visible_text ) ? $visible_text : '';
		$truncated    = strlen( $rendered ) > $max_length;
		$warnings     = array();
		if ( '' === $visible_text ) {
			$warnings[] = 'Rendered output has no visible text.';
		}
		if ( $truncated ) {
			$warnings[] = 'Rendered HTML exceeded max_length and was truncated in this response.';
		}

		return array(
			'post_id'                          => (int) $post->ID,
			'post_type'                        => $post_type,
			'post_status'                      => $post_status,
			'nonpublic'                        => true,
			'raw_content_sha256'               => hash( 'sha256', $raw_content ),
			'rendered_html_sha256'             => hash( 'sha256', $rendered ),
			'rendered_html'                    => $truncated ? substr( $rendered, 0, $max_length ) : $rendered,
			'rendered_html_bytes'              => strlen( $rendered ),
			'returned_html_bytes'              => $truncated ? $max_length : strlen( $rendered ),
			'truncated'                        => $truncated,
			'visible_text'                     => self::truncate( $visible_text, $max_length ),
			'visible_text_bytes'               => strlen( $visible_text ),
			'heading_count'                    => self::count_pattern( '/<h[1-6]\b/i', $rendered ),
			'link_count'                       => self::count_pattern( '/<a\b/i', $rendered ),
			'image_count'                      => self::count_pattern( '/<img\b/i', $rendered ),
			'preview_url'                      => $preview_url,
			'preview_access'                   => 'authenticated_administrator',
			'preview_public'                   => false,
			'preview_url_contains_credentials' => false,
			'warnings'                         => $warnings,
			'write_performed'                  => false,
			'read_only'                        => true,
		);
	}

	private static function render_content( object $post, string $content ) {
		$had_global_post = array_key_exists( 'post', $GLOBALS );
		$previous_post   = $GLOBALS['post'] ?? null;
		$GLOBALS['post'] = $post;

		if ( function_exists( 'setup_postdata' ) ) {
			setup_postdata( $post );
		}

		try {
			return apply_filters( 'the_content', $content );
		} finally {
			if ( $had_global_post ) {
				$GLOBALS['post'] = $previous_post;
				if ( is_object( $previous_post ) && function_exists( 'setup_postdata' ) ) {
					setup_postdata( $previous_post );
				}
			} else {
				unset( $GLOBALS['post'] );
				if ( function_exists( 'wp_reset_postdata' ) ) {
					wp_reset_postdata();
				}
			}
		}
	}

	private static function safe_preview_url( object $post ) {
		$url = get_preview_post_link( $post );
		if ( ! is_string( $url ) || '' === $url ) {
			return new WP_Error( 'coordinator_preview_unavailable', 'WordPress did not provide a preview URL for this item.' );
		}

		$parts = wp_parse_url( $url );
		$home  = wp_parse_url( home_url( '/' ) );
		if ( ! is_array( $parts ) || ! is_array( $home ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) || empty( $home['host'] ) ) {
			return new WP_Error( 'coordinator_unsafe_preview_url', 'The preview URL could not be validated.' );
		}
		if ( ! in_array( strtolower( (string) $parts['scheme'] ), array( 'http', 'https' ), true ) || 0 !== strcasecmp( (string) $parts['host'], (string) $home['host'] ) ) {
			return new WP_Error( 'coordinator_unsafe_preview_url', 'The preview URL is not on this WordPress site.' );
		}
		if ( isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['fragment'] ) ) {
			return new WP_Error( 'coordinator_unsafe_preview_url', 'The preview URL contains disallowed credential or fragment data.' );
		}

		$query = array();
		parse_str( (string) ( $parts['query'] ?? '' ), $query );
		foreach ( array_keys( $query ) as $key ) {
			if ( preg_match( '/(?:nonce|token|secret|password|pass|key)/i', (string) $key ) ) {
				return new WP_Error( 'coordinator_unsafe_preview_url', 'The preview URL contains a token-like query parameter.' );
			}
		}

		return $url;
	}

	private static function bounded_integer( $value, int $minimum, int $maximum ): ?int {
		if ( is_string( $value ) && preg_match( '/^\d+$/', $value ) ) {
			$value = (int) $value;
		}
		if ( ! is_int( $value ) || $value < $minimum || $value > $maximum ) {
			return null;
		}
		return $value;
	}

	private static function count_pattern( string $pattern, string $value ): int {
		$count = preg_match_all( $pattern, $value );
		return false === $count ? 0 : $count;
	}

	private static function truncate( string $value, int $limit ): string {
		return strlen( $value ) > $limit ? substr( $value, 0, $limit ) : $value;
	}
}
