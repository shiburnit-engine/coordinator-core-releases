<?php
/**
 * Multi-provider AI registry with usage tracking and task-based optimization.
 *
 * Lets the Project Owner add AI providers one at a time from a pre-researched catalog,
 * tracks free-tier usage and remaining quota, and automatically selects the best
 * available provider for each task type.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Provider_Registry {
	public const OPTION = 'coordinator_core_providers_v1';
	public const USAGE_OPTION = 'coordinator_core_provider_usage_v1';

	private const TASK_TYPES = array( 'summarize', 'classify', 'draft', 'review' );
	private const CATALOG_PATH = 'shared-rules/schemas/provider-catalog.json';

	/**
	 * Boot — register admin actions.
	 */
	public static function boot(): void {
		add_action( 'admin_post_coordinator_save_provider', array( self::class, 'handle_admin_save' ) );
		add_action( 'admin_post_coordinator_delete_provider', array( self::class, 'handle_admin_delete' ) );
		add_action( 'admin_post_coordinator_reset_provider_usage', array( self::class, 'handle_admin_reset_usage' ) );
	}

	// ─── Status ──────────────────────────────────────────────────────────

	/**
	 * Get the current provider registry status for health/REST endpoints.
	 */
	public static function status(): array {
		$providers = self::get_configured_providers();
		$usage     = self::get_usage();
		$available  = array();
		$exhausted  = array();

		foreach ( $providers as $provider ) {
			$remaining = self::remaining_quota( $provider, $usage );
			if ( $remaining['available'] ) {
				$available[] = array(
					'id'         => $provider['id'],
					'name'       => $provider['name'],
					'model'      => $provider['model'] ?? '',
					'task_fit'   => $provider['task_fit'] ?? array(),
					'remaining'  => $remaining,
				);
			} else {
				$exhausted[] = array(
					'id'    => $provider['id'],
					'name'  => $provider['name'],
					'reason' => $remaining['reason'] ?? 'Quota exhausted',
				);
			}
		}

		return array(
			'configured_count' => count( $providers ),
			'available_count'  => count( $available ),
			'exhausted_count'  => count( $exhausted ),
			'available'        => $available,
			'exhausted'        => $exhausted,
			'optimizer_enabled' => count( $providers ) > 0,
		);
	}

	// ─── Optimizer ───────────────────────────────────────────────────────

	/**
	 * Soft-limit threshold: when usage exceeds this percentage of quota,
	 * the optimizer starts preferring other providers.
	 */
	const SOFT_LIMIT_PCT = 80;

	/**
	 * Select the best available platform and model for a given task type.
	 *
	 * Scoring considers:
	 * 1. Model task-fit score (0-100) — how well the specific model on this platform handles the task
	 * 2. Remaining quota — providers approaching limits are deprioritized before they run out
	 * 3. Cost preference — free tiers get a bonus, paid models are used only when free options are insufficient
	 * 4. Reliability — historical success rate for this provider on this task type
	 * 5. Threshold-based switching — rotates away from providers before they hit hard limits
	 *
	 * @param string $task_type One of: summarize, classify, draft, review.
	 * @return array|null Selected provider+model or null if none available.
	 */
	public static function select_provider( string $task_type ): ?array {
		if ( ! in_array( $task_type, self::TASK_TYPES, true ) ) {
			return null;
		}

		$providers = self::get_configured_providers();
		if ( empty( $providers ) ) {
			return null;
		}

		$usage = self::get_usage();
		$candidates = array();

		foreach ( $providers as $provider ) {
			$remaining = self::remaining_quota( $provider, $usage );
			if ( ! $remaining['available'] ) {
				continue;
			}

			// Determine the best model on this platform for the task
			$model = self::best_model_for_task( $provider, $task_type );
			$model_fit = self::model_task_fit( $provider, $model, $task_type );

			// Availability factor: 1.0 when fresh, drops as quota is consumed
			$availability = self::availability_factor( $remaining );

			// Quota state: fresh, degrading, or nearly exhausted
			$quota_state = self::quota_state( $remaining );
			$quota_factor = self::QUOTA_STATE_FACTORS[ $quota_state ];

			// Cost factor: free tiers preferred, paid models penalized unless no free option
			$cost_factor = $provider['free_tier']['available'] ? 1.20 : 0.60;
			$model_paid = self::model_is_paid_only( $provider, $model );
			if ( $model_paid ) {
				$cost_factor *= 0.50; // Paid-only models get extra penalty when free tier exists
			}

			// Reliability factor: based on historical success rate for this provider on this task
			$reliability = self::reliability_factor( $provider['id'], $task_type, $usage );

			// Already-connected bonus: existing infrastructure gets a small edge
			$infra_bonus = ! empty( $provider['already_connected'] ) ? 1.05 : 1.0;

			$score = $model_fit * $availability * $quota_factor * $cost_factor * $reliability * $infra_bonus;

			$candidates[] = array(
				'id'              => $provider['id'],
				'name'            => $provider['name'],
				'model'           => $model,
				'api_base'        => $provider['api_base'],
				'auth_type'       => $provider['auth_type'],
				'auth_header'     => $provider['auth_header'],
				'auth_prefix'     => $provider['auth_prefix'] ?? '',
				'compatibility'   => $provider['compatibility'],
				'task_fit_score'  => $model_fit,
				'availability'    => $availability,
				'quota_state'     => $quota_state,
				'cost_factor'     => $cost_factor,
				'reliability'     => $reliability,
				'selection_score' => round( $score, 2 ),
				'free_tier'       => $provider['free_tier']['available'],
				'model_paid_only' => $model_paid,
				'remaining'       => $remaining,
			);
		}

		if ( empty( $candidates ) ) {
			return null;
		}

		// Sort by score descending — best combination wins
		usort( $candidates, static function ( $a, $b ) {
			return $b['selection_score'] <=> $a['selection_score'];
		} );

		return $candidates[0];
	}

	/**
	 * Get all ranked candidates for a task (not just the winner).
	 * Useful for failover — the caller can try candidates in order.
	 *
	 * @param string $task_type One of: summarize, classify, draft, review.
	 * @return array[] Ranked candidates, best first.
	 */
	public static function ranked_candidates( string $task_type ): array {
		$selected = self::select_provider( $task_type );
		if ( null === $selected ) {
			return array();
		}

		// Re-run the scoring to get all candidates ranked
		$providers = self::get_configured_providers();
		$usage = self::get_usage();
		$candidates = array();

		foreach ( $providers as $provider ) {
			$remaining = self::remaining_quota( $provider, $usage );
			if ( ! $remaining['available'] ) {
				continue;
			}
			$model = self::best_model_for_task( $provider, $task_type );
			$model_fit = self::model_task_fit( $provider, $model, $task_type );
			$availability = self::availability_factor( $remaining );
			$quota_state = self::quota_state( $remaining );
			$quota_factor = self::QUOTA_STATE_FACTORS[ $quota_state ];
			$cost_factor = $provider['free_tier']['available'] ? 1.20 : 0.60;
			if ( self::model_is_paid_only( $provider, $model ) ) {
				$cost_factor *= 0.50;
			}
			$reliability = self::reliability_factor( $provider['id'], $task_type, $usage );
			$infra_bonus = ! empty( $provider['already_connected'] ) ? 1.05 : 1.0;
			$score = $model_fit * $availability * $quota_factor * $cost_factor * $reliability * $infra_bonus;

			$candidates[] = array(
				'id' => $provider['id'],
				'name' => $provider['name'],
				'model' => $model,
				'selection_score' => round( $score, 2 ),
				'quota_state' => $quota_state,
				'free_tier' => $provider['free_tier']['available'],
			);
		}

		usort( $candidates, static function ( $a, $b ) {
			return $b['selection_score'] <=> $a['selection_score'];
		} );

		return $candidates;
	}

	/**
	 * Record usage after a provider completes a job.
	 *
	 * @param string $provider_id Provider ID.
	 * @param string $task_type Task type.
	 * @param int    $input_tokens Input tokens used.
	 * @param int    $output_tokens Output tokens used.
	 * @param float  $cost_usd Actual cost (0 for free tier).
	 * @param bool   $success Whether the job succeeded.
	 */
	public static function record_usage( string $provider_id, string $task_type, int $input_tokens, int $output_tokens, float $cost_usd, bool $success ): void {
		$usage = self::get_usage();
		$today = gmdate( 'Y-m-d' );
		$month = gmdate( 'Y-m' );

		if ( ! isset( $usage[ $provider_id ] ) ) {
			$usage[ $provider_id ] = array(
				'total_requests' => 0,
				'total_input_tokens' => 0,
				'total_output_tokens' => 0,
				'total_cost_usd' => 0.0,
				'successful' => 0,
				'failed' => 0,
				'daily' => array(),
				'monthly' => array(),
				'by_task' => array(),
			);
		}

		$entry = &$usage[ $provider_id ];
		$entry['total_requests'] += 1;
		$entry['total_input_tokens'] += $input_tokens;
		$entry['total_output_tokens'] += $output_tokens;
		$entry['total_cost_usd'] = round( $entry['total_cost_usd'] + $cost_usd, 6 );
		$entry[ $success ? 'successful' : 'failed' ] += 1;

		if ( ! isset( $entry['daily'][ $today ] ) ) {
			$entry['daily'][ $today ] = array( 'requests' => 0, 'tokens' => 0, 'cost_usd' => 0.0 );
		}
		$entry['daily'][ $today ]['requests'] += 1;
		$entry['daily'][ $today ]['tokens'] += $input_tokens + $output_tokens;
		$entry['daily'][ $today ]['cost_usd'] = round( $entry['daily'][ $today ]['cost_usd'] + $cost_usd, 6 );

		if ( ! isset( $entry['monthly'][ $month ] ) ) {
			$entry['monthly'][ $month ] = array( 'requests' => 0, 'tokens' => 0, 'cost_usd' => 0.0 );
		}
		$entry['monthly'][ $month ]['requests'] += 1;
		$entry['monthly'][ $month ]['tokens'] += $input_tokens + $output_tokens;
		$entry['monthly'][ $month ]['cost_usd'] = round( $entry['monthly'][ $month ]['cost_usd'] + $cost_usd, 6 );

		if ( ! isset( $entry['by_task'][ $task_type ] ) ) {
			$entry['by_task'][ $task_type ] = array( 'requests' => 0, 'success' => 0 );
		}
		$entry['by_task'][ $task_type ]['requests'] += 1;
		if ( $success ) {
			$entry['by_task'][ $task_type ]['success'] += 1;
		}

		// Keep only last 90 days of daily data
		$cutoff = gmdate( 'Y-m-d', time() - 90 * DAY_IN_SECONDS );
		foreach ( $entry['daily'] as $date => $data ) {
			if ( $date < $cutoff ) {
				unset( $entry['daily'][ $date ] );
			}
		}

		unset( $entry );
		update_option( self::USAGE_OPTION, $usage, false );
	}

	// ─── Admin handlers ──────────────────────────────────────────────────

	public static function handle_admin_save(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_save_provider' );

		$provider_id = sanitize_key( wp_unslash( $_POST['provider_id'] ?? '' ) );
		$api_key     = trim( (string) wp_unslash( $_POST['provider_api_key'] ?? '' ) );
		$model       = sanitize_text_field( wp_unslash( $_POST['provider_model'] ?? '' ) );

		$catalog = self::get_catalog();
		$catalog_provider = null;
		foreach ( $catalog['providers'] as $p ) {
			if ( $p['id'] === $provider_id ) {
				$catalog_provider = $p;
				break;
			}
		}

		if ( null === $catalog_provider ) {
			wp_die( esc_html__( 'Unknown provider.', 'coordinator-core' ), '', array( 'response' => 400 ) );
		}

		if ( '' === $api_key || strlen( $api_key ) < 10 || strlen( $api_key ) > 200 ) {
			wp_die( esc_html__( 'A valid API key is required (10 to 200 characters).', 'coordinator-core' ), '', array( 'response' => 400 ) );
		}

		$encrypted = self::encrypt_secret( $api_key );
		if ( is_wp_error( $encrypted ) ) {
			wp_die( esc_html( $encrypted->get_error_message() ), '', array( 'response' => 500 ) );
		}

		$providers = self::get_configured_providers();
		$providers[ $provider_id ] = array(
			'id'            => $provider_id,
			'name'          => $catalog_provider['name'],
			'description'   => $catalog_provider['description'],
			'api_base'      => $catalog_provider['api_base'],
			'auth_type'     => $catalog_provider['auth_type'],
			'auth_header'   => $catalog_provider['auth_header'],
			'auth_prefix'   => $catalog_provider['auth_prefix'] ?? '',
			'compatibility' => $catalog_provider['compatibility'],
			'model'         => '' !== $model ? $model : ( $catalog_provider['models'][0]['id'] ?? '' ),
			'models'        => $catalog_provider['models'],
			'task_fit'      => $catalog_provider['task_fit'],
			'free_tier'     => $catalog_provider['free_tier'],
			'paid_tiers'    => $catalog_provider['paid_tiers'],
			'key_nonce'     => $encrypted['nonce'],
			'key_ciphertext'=> $encrypted['ciphertext'],
			'configured_at' => gmdate( 'c' ),
		);

		update_option( self::OPTION, $providers, false );
		wp_safe_redirect( add_query_arg( array( 'page' => 'coordinator-core', 'provider_added' => $provider_id ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function handle_admin_delete(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_delete_provider' );

		$provider_id = sanitize_key( wp_unslash( $_POST['provider_id'] ?? '' ) );
		$providers = self::get_configured_providers();
		unset( $providers[ $provider_id ] );
		update_option( self::OPTION, $providers, false );

		wp_safe_redirect( add_query_arg( array( 'page' => 'coordinator-core', 'provider_removed' => $provider_id ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function handle_admin_reset_usage(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Administrator permission is required.', 'coordinator-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'coordinator_reset_provider_usage' );

		delete_option( self::USAGE_OPTION );
		wp_safe_redirect( add_query_arg( array( 'page' => 'coordinator-core', 'usage_reset' => '1' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	// ─── Admin render ───────────────────────────────────────────────────

	public static function render_admin_section(): void {
		$catalog    = self::get_catalog();
		$providers  = self::get_configured_providers();
		$usage      = self::get_usage();
		$added_id   = sanitize_key( wp_unslash( $_GET['provider_added'] ?? '' ) );
		$removed_id = sanitize_key( wp_unslash( $_GET['provider_removed'] ?? '' ) );
		$usage_reset = '1' === sanitize_key( wp_unslash( $_GET['usage_reset'] ?? '' ) );

		$configured_ids = array_keys( $providers );
		$available_from_catalog = array_filter( $catalog['providers'], static function ( $p ) use ( $configured_ids ) {
			return ! in_array( $p['id'], $configured_ids, true );
		} );
		?>
		<style>
			#coordinator-providers { max-width: 1000px; margin: 28px 0; color: #172033; }
			#coordinator-providers * { box-sizing: border-box; }
			.cc-provider-hero { padding: 24px; border: 1px solid #c7d2fe; border-radius: 18px; background: linear-gradient(135deg, #eff6ff 0%, #eef2ff 52%, #faf5ff 100%); box-shadow: 0 12px 30px rgba(30, 64, 175, .08); }
			.cc-provider-hero h2 { margin: 0 0 8px; font-size: clamp(24px, 5vw, 34px); line-height: 1.15; }
			.cc-provider-hero p { max-width: 720px; margin: 0; color: #475569; font-size: 15px; line-height: 1.6; }
			.cc-provider-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; margin-top: 24px; }
			.cc-provider-card { padding: 20px; border: 1px solid #dbe4f0; border-radius: 16px; background: #fff; box-shadow: 0 8px 24px rgba(15, 23, 42, .06); transition: box-shadow .2s; }
			.cc-provider-card:hover { box-shadow: 0 12px 32px rgba(15, 23, 42, .1); }
			.cc-provider-card.configured { border-color: #86efac; background: linear-gradient(135deg, #f0fdf4 0%, #f7fee7 100%); }
			.cc-provider-card.recommended { border-color: #93c5fd; }
			.cc-provider-badge { display: inline-flex; align-items: center; min-height: 26px; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; }
			.cc-badge-free { background: #16a34a; color: #fff; }
			.cc-badge-paid { background: #6b7280; color: #fff; }
			.cc-badge-recommended { background: #1d4ed8; color: #fff; }
			.cc-badge-connected { background: #7c3aed; color: #fff; }
			.cc-provider-card h3 { margin: 12px 0 6px; font-size: 18px; color: #0f172a; }
			.cc-provider-card .cc-provider-desc { color: #64748b; font-size: 13px; line-height: 1.5; margin: 0 0 14px; }
			.cc-provider-limits { font-size: 12px; color: #475569; line-height: 1.6; }
			.cc-provider-limits strong { color: #0f172a; }
			.cc-provider-usage { margin-top: 14px; padding: 12px; border-radius: 10px; background: #f8fafc; font-size: 12px; color: #334155; line-height: 1.5; }
			.cc-usage-bar { height: 6px; margin: 8px 0 4px; border-radius: 999px; background: #e2e8f0; overflow: hidden; }
			.cc-usage-bar span { display: block; height: 100%; border-radius: inherit; }
			.cc-usage-bar .cc-bar-green { background: #22c55e; }
			.cc-usage-bar .cc-bar-yellow { background: #eab308; }
			.cc-usage-bar .cc-bar-red { background: #ef4444; }
			.cc-provider-actions { margin-top: 14px; display: flex; gap: 8px; flex-wrap: wrap; }
			.cc-provider-actions .button { min-height: 40px; padding: 8px 16px; border-radius: 10px; font-size: 13px; font-weight: 600; }
			.cc-add-provider { margin-top: 24px; padding: 24px; border: 1px solid #dbe4f0; border-radius: 16px; background: #fff; }
			.cc-add-provider h3 { margin: 0 0 16px; font-size: 18px; color: #0f172a; }
			.cc-add-provider select, .cc-add-provider input { min-height: 40px; border-radius: 10px; }
			.cc-optimizer { margin-top: 24px; padding: 20px; border: 1px solid #bfdbfe; border-radius: 14px; background: #eff6ff; }
			.cc-optimizer h3 { margin: 0 0 8px; font-size: 16px; color: #1e3a8a; }
			.cc-optimizer p { margin: 0; color: #1e40af; font-size: 13px; line-height: 1.5; }
			@media (max-width: 600px) {
				.cc-provider-grid { grid-template-columns: 1fr; }
				.cc-provider-hero { padding: 20px; border-radius: 14px; }
			}
		</style>
		<div id="coordinator-providers">
			<div class="cc-provider-hero">
				<h2><?php echo esc_html__( 'AI Provider Registry', 'coordinator-core' ); ?></h2>
				<p><?php echo esc_html__( 'Add AI platforms one at a time, starting with the best free options. The optimizer automatically selects the best available provider for each task and switches when one hits its limit. Track usage, costs, and which platform produces results.', 'coordinator-core' ); ?></p>
			</div>

			<?php if ( $added_id ) : ?>
				<div class="notice notice-success inline"><p><?php echo esc_html__( 'Provider added successfully.', 'coordinator-core' ); ?></p></div>
			<?php elseif ( $removed_id ) : ?>
				<div class="notice notice-info inline"><p><?php echo esc_html__( 'Provider removed.', 'coordinator-core' ); ?></p></div>
			<?php elseif ( $usage_reset ) : ?>
				<div class="notice notice-success inline"><p><?php echo esc_html__( 'Usage statistics reset.', 'coordinator-core' ); ?></p></div>
			<?php endif; ?>

			<?php if ( ! empty( $providers ) ) : ?>
				<div class="cc-optimizer">
					<h3><?php echo esc_html__( 'Automatic Provider Optimizer', 'coordinator-core' ); ?></h3>
					<p>
						<?php
						$status = self::status();
						echo esc_html( sprintf(
							/* translators: 1: available count, 2: total count */
							__( '%1$d of %2$d providers available. The optimizer selects the best platform and model for each task, switches before limits are reached, and prefers free tiers to minimize cost.', 'coordinator-core' ),
							$status['available_count'],
							$status['configured_count']
						) );
						?>
					</p>
					<?php if ( $status['exhausted_count'] > 0 ) : ?>
						<p style="margin-top:8px;color:#b91c1c"><?php echo esc_html( sprintf( __( '%d provider(s) have exhausted their free quota. The optimizer will skip them until quotas reset.', 'coordinator-core' ), $status['exhausted_count'] ) ); ?></p>
					<?php endif; ?>
					<?php
					// Show the optimizer's current best selection for each task type
					if ( $status['available_count'] > 0 ) :
						$task_labels = array(
							'summarize' => 'Summarize',
							'classify'  => 'Classify',
							'draft'     => 'Draft',
							'review'    => 'Review',
						);
						?>
						<table class="widefat striped" style="margin-top:14px;max-width:600px">
							<thead><tr><th>Task</th><th>Best platform</th><th>Model</th><th>Score</th><th>Quota</th></tr></thead>
							<tbody>
								<?php foreach ( self::TASK_TYPES as $task_type ) : ?>
									<?php $pick = self::select_provider( $task_type ); ?>
									<?php if ( null !== $pick ) : ?>
										<tr>
											<td><strong><?php echo esc_html( $task_labels[ $task_type ] ?? ucfirst( $task_type ) ); ?></strong></td>
											<td><?php echo esc_html( $pick['name'] ); ?></td>
											<td><code><?php echo esc_html( $pick['model'] ); ?></code></td>
											<td><?php echo esc_html( (string) $pick['selection_score'] ); ?></td>
											<td style="color:<?php echo $pick['quota_state'] === 'fresh' ? '#15803d' : ( $pick['quota_state'] === 'degrading' ? '#b45309' : '#b91c1c' ); ?>"><?php echo esc_html( ucfirst( $pick['quota_state'] ) ); ?></td>
										</tr>
									<?php else : ?>
										<tr><td><strong><?php echo esc_html( $task_labels[ $task_type ] ?? ucfirst( $task_type ) ); ?></strong></td><td colspan="4"><em>No provider available</em></td></tr>
									<?php endif; ?>
								<?php endforeach; ?>
							</tbody>
						</table>
						<p class="description" style="margin-top:6px"><?php echo esc_html__( 'The optimizer scores each platform and model combination based on task fit, remaining quota, cost, and reliability. It switches automatically before a provider reaches its limit.', 'coordinator-core' ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $providers ) ) : ?>
				<h3 style="margin-top:24px;font-size:18px;color:#0f172a"><?php echo esc_html__( 'Connected Providers', 'coordinator-core' ); ?></h3>
				<div class="cc-provider-grid">
					<?php foreach ( $providers as $provider ) : ?>
						<?php self::render_provider_card( $provider, $usage, true ); ?>
					<?php endforeach; ?>
				</div>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:16px">
					<input type="hidden" name="action" value="coordinator_reset_provider_usage">
					<?php wp_nonce_field( 'coordinator_reset_provider_usage' ); ?>
					<button class="button" type="submit" onclick="return confirm('<?php echo esc_js( __( 'Reset all usage statistics?', 'coordinator-core' ) ); ?>')"><?php echo esc_html__( 'Reset Usage Statistics', 'coordinator-core' ); ?></button>
				</form>
			<?php endif; ?>

			<?php if ( ! empty( $available_from_catalog ) ) : ?>
				<div class="cc-add-provider">
					<h3><?php echo esc_html__( 'Add a Provider', 'coordinator-core' ); ?></h3>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="coordinator_save_provider">
						<?php wp_nonce_field( 'coordinator_save_provider' ); ?>
						<table class="form-table" role="presentation">
							<tr>
								<th><label for="provider_id"><?php echo esc_html__( 'Choose provider', 'coordinator-core' ); ?></label></th>
								<td>
									<select id="provider_id" name="provider_id" required onchange="ccUpdateProviderInfo()">
										<option value=""><?php echo esc_html__( '— Select —', 'coordinator-core' ); ?></option>
										<?php foreach ( $available_from_catalog as $p ) : ?>
											<option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['name'] ); ?><?php echo $p['free_tier']['available'] ? ' (Free)' : ' (Paid)'; ?><?php echo ! empty( $p['recommended'] ) ? ' — Recommended' : ''; ?></option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							<tr id="cc_provider_info_row" style="display:none">
								<th><?php echo esc_html__( 'Limits & cost', 'coordinator-core' ); ?></th>
								<td id="cc_provider_info" style="font-size:13px;color:#475569;line-height:1.6"></td>
							</tr>
							<tr>
								<th><label for="provider_api_key"><?php echo esc_html__( 'API key', 'coordinator-core' ); ?></label></th>
								<td>
									<input class="large-text code" id="provider_api_key" name="provider_api_key" type="password" autocomplete="new-password" minlength="10" maxlength="200" required placeholder="<?php echo esc_attr( 'Paste your API key from the provider dashboard' ); ?>">
									<p class="description"><?php echo esc_html__( 'The key is encrypted and never displayed again. Store it only in this site\'s protected storage.', 'coordinator-core' ); ?></p>
								</td>
							</tr>
							<tr>
								<th><label for="provider_model"><?php echo esc_html__( 'Default model', 'coordinator-core' ); ?></label></th>
								<td>
									<select id="provider_model" name="provider_model">
										<option value=""><?php echo esc_html__( 'Use provider default', 'coordinator-core' ); ?></option>
									</select>
									<p class="description"><?php echo esc_html__( 'The optimizer will still choose the best model per task.', 'coordinator-core' ); ?></p>
								</td>
							</tr>
						</table>
						<?php submit_button( esc_html__( 'Add Provider', 'coordinator-core' ) ); ?>
					</form>
					<script>
					(function () {
						var catalog = <?php echo wp_json_encode( $available_from_catalog ); ?>;
						var select = document.getElementById('provider_id');
						var infoRow = document.getElementById('cc_provider_info_row');
						var infoCell = document.getElementById('cc_provider_info');
						var modelSelect = document.getElementById('provider_model');
						if (!select || !infoRow || !infoCell) return;

						window.ccUpdateProviderInfo = function () {
							var id = select.value;
							if (!id) {
								infoRow.style.display = 'none';
								modelSelect.innerHTML = '<option value="">Use provider default</option>';
								return;
							}
							var provider = catalog.find(function (p) { return p.id === id; });
							if (!provider) return;
							infoRow.style.display = 'table-row';

							var ft = provider.free_tier || {};
							var html = '<strong>Free tier:</strong> ' + (ft.available ? 'Yes' : 'No');
							if (ft.available) {
								if (ft.rate_limit_rpm) html += ' &middot; ' + ft.rate_limit_rpm + ' req/min';
								if (ft.rate_limit_rpd) html += ' &middot; ' + ft.rate_limit_rpd + ' req/day';
								if (ft.tokens_per_day) html += ' &middot; ' + (ft.tokens_per_day / 1000000).toFixed(1) + 'M tokens/day';
								if (ft.calls_per_month) html += ' &middot; ' + ft.calls_per_month + ' calls/month';
								if (ft.credit_card_required) html += ' &middot; <span style="color:#b91c1c">Credit card required</span>';
								if (ft.notes) html += '<br><em>' + ft.notes + '</em>';
							}

							if (provider.paid_tiers && provider.paid_tiers.length) {
								html += '<br><strong>Paid option:</strong> ';
								var pt = provider.paid_tiers[0];
								if (pt.cost_per_million_input_tokens) html += '$' + pt.cost_per_million_input_tokens + '/M input tokens';
								if (pt.cost_per_million_output_tokens) html += ' &middot; $' + pt.cost_per_million_output_tokens + '/M output tokens';
								if (pt.notes) html += '<br><em>' + pt.notes + '</em>';
							}

							if (provider.signup_url) html += '<br><a href="' + provider.signup_url + '" target="_blank" rel="noopener noreferrer">Get API key &rarr;</a>';
							if (provider.docs_url) html += ' &middot; <a href="' + provider.docs_url + '" target="_blank" rel="noopener noreferrer">Docs</a>';

							infoCell.innerHTML = html;

							// Update model options
							var models = provider.models || [];
							var modelHtml = '<option value="">Use provider default</option>';
							models.forEach(function (m) {
								var label = m.id;
								if (m.paid_only) label += ' (paid only)';
								modelHtml += '<option value="' + m.id + '">' + label + '</option>';
							});
							modelSelect.innerHTML = modelHtml;
						};

						select.addEventListener('change', window.ccUpdateProviderInfo);
					})();
					</script>
				</div>
			<?php elseif ( empty( $providers ) ) : ?>
				<div class="notice notice-info inline" style="margin-top:20px">
					<p><?php echo esc_html__( 'No providers configured yet. Add your first AI provider below to enable automatic provider optimization.', 'coordinator-core' ); ?></p>
				</div>
			<?php endif; ?>

			<?php if ( empty( $available_from_catalog ) && ! empty( $providers ) ) : ?>
				<div class="notice notice-success inline" style="margin-top:20px">
					<p><?php echo esc_html__( 'All known providers are configured. The optimizer will select the best one for each task automatically.', 'coordinator-core' ); ?></p>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	// ─── Internal helpers ────────────────────────────────────────────────

	private static function render_provider_card( array $provider, array $usage, bool $configured ): void {
		$u = $usage[ $provider['id'] ] ?? array();
		$remaining = self::remaining_quota( $provider, $usage );
		$today = gmdate( 'Y-m-d' );
		$today_requests = (int) ( $u['daily'][ $today ]['requests'] ?? 0 );
		$today_tokens = (int) ( $u['daily'][ $today ]['tokens'] ?? 0 );
		$today_cost = (float) ( $u['daily'][ $today ]['cost_usd'] ?? 0.0 );
		$total_requests = (int) ( $u['total_requests'] ?? 0 );
		$total_cost = (float) ( $u['total_cost_usd'] ?? 0.0 );
		$success_rate = $total_requests > 0 ? round( ( (int) ( $u['successful'] ?? 0 ) / $total_requests * 100 ) ) : 0;

		// Usage bar percentage and quota state
		$daily_limit = $provider['free_tier']['rate_limit_rpd'] ?? 0;
		$bar_pct = $daily_limit > 0 ? min( 100, round( $today_requests / $daily_limit * 100 ) ) : 0;
		$quota_state = $remaining['available'] ? self::quota_state( $remaining ) : 'exhausted';
		$bar_class = 'cc-bar-green';
		$state_label = 'Available';
		$state_color = '#15803d';
		if ( ! $remaining['available'] ) {
			$bar_class = 'cc-bar-red';
			$state_label = 'Exhausted';
			$state_color = '#b91c1c';
		} elseif ( $quota_state === self::QUOTA_STATE_DEGRADING ) {
			$bar_class = 'cc-bar-yellow';
			$state_label = 'Approaching limit';
			$state_color = '#b45309';
		} elseif ( $quota_state === self::QUOTA_STATE_CRITICAL ) {
			$bar_class = 'cc-bar-red';
			$state_label = 'Nearly exhausted';
			$state_color = '#b91c1c';
		}
		// Optimize the bar to show a minimum width so it's always visible
		$bar_width = max( $bar_pct, 2 );
		?>
		<div class="cc-provider-card<?php echo $configured ? ' configured' : ''; ?><?php echo ! empty( $provider['recommended'] ) ? ' recommended' : ''; ?>">
			<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
				<?php if ( $provider['free_tier']['available'] ) : ?>
					<span class="cc-provider-badge cc-badge-free">Free</span>
				<?php else : ?>
					<span class="cc-provider-badge cc-badge-paid">Paid</span>
				<?php endif; ?>
				<?php if ( ! empty( $provider['recommended'] ) ) : ?>
					<span class="cc-provider-badge cc-badge-recommended">Recommended</span>
				<?php endif; ?>
				<?php if ( ! empty( $provider['already_connected'] ) ) : ?>
					<span class="cc-provider-badge cc-badge-connected">Connected</span>
				<?php endif; ?>
			</div>
			<h3><?php echo esc_html( $provider['name'] ); ?></h3>
			<p class="cc-provider-desc"><?php echo esc_html( $provider['description'] ?? '' ); ?></p>

			<div class="cc-provider-limits">
				<?php $ft = $provider['free_tier'] ?? array(); ?>
				<?php if ( ! empty( $ft['available'] ) ) : ?>
					<strong>Free:</strong>
					<?php if ( ! empty( $ft['rate_limit_rpm'] ) ) : ?><?php echo esc_html( (int) $ft['rate_limit_rpm'] ); ?> req/min<?php endif; ?>
					<?php if ( ! empty( $ft['rate_limit_rpd'] ) ) : ?> &middot; <?php echo esc_html( (int) $ft['rate_limit_rpd'] ); ?> req/day<?php endif; ?>
					<?php if ( ! empty( $ft['tokens_per_day'] ) ) : ?> &middot; <?php echo esc_html( number_format( (int) $ft['tokens_per_day'] ) ); ?> tokens/day<?php endif; ?>
					<?php if ( ! empty( $ft['calls_per_month'] ) ) : ?> &middot; <?php echo esc_html( (int) $ft['calls_per_month'] ); ?> calls/month<?php endif; ?>
				<?php else : ?>
					<strong>No free tier.</strong>
				<?php endif; ?>
				<?php if ( ! empty( $provider['paid_tiers'] ) ) : ?>
					<?php $pt = $provider['paid_tiers'][0]; ?>
					<br><strong>Paid:</strong>
					<?php if ( isset( $pt['cost_per_million_input_tokens'] ) && is_numeric( $pt['cost_per_million_input_tokens'] ) ) : ?>
						$<?php echo esc_html( $pt['cost_per_million_input_tokens'] ); ?>/M input
					<?php endif; ?>
					<?php if ( isset( $pt['cost_per_million_output_tokens'] ) && is_numeric( $pt['cost_per_million_output_tokens'] ) ) : ?>
						&middot; $<?php echo esc_html( $pt['cost_per_million_output_tokens'] ); ?>/M output
					<?php endif; ?>
				<?php endif; ?>
			</div>

			<?php if ( $configured && $total_requests > 0 ) : ?>
				<div class="cc-provider-usage">
					<strong>Today:</strong> <?php echo esc_html( (string) $today_requests ); ?> requests &middot; <?php echo esc_html( number_format( $today_tokens ) ); ?> tokens &middot; $<?php echo esc_html( number_format( $today_cost, 6 ) ); ?><br>
					<strong>Total:</strong> <?php echo esc_html( (string) $total_requests ); ?> requests &middot; <?php echo esc_html( number_format( (int) ( $u['total_input_tokens'] ?? 0 ) ) ); ?> in &middot; <?php echo esc_html( number_format( (int) ( $u['total_output_tokens'] ?? 0 ) ) ); ?> out &middot; $<?php echo esc_html( number_format( $total_cost, 6 ) ); ?><br>
					<strong>Success rate:</strong> <?php echo esc_html( (string) $success_rate ); ?>%
					<?php if ( $daily_limit > 0 ) : ?>
						<div class="cc-usage-bar"><span class="<?php echo esc_attr( $bar_class ); ?>" style="width:<?php echo esc_attr( (string) $bar_width ); ?>%"></span></div>
						<?php echo esc_html( (string) $today_requests ); ?> / <?php echo esc_html( (string) $daily_limit ); ?> daily requests used
					<?php endif; ?>
					<br><span style="color:<?php echo esc_attr( $state_color ); ?>;font-weight:600"><?php echo esc_html( $state_label ); ?></span>
				</div>
			<?php elseif ( $configured ) : ?>
				<div class="cc-provider-usage">
					<em><?php echo esc_html__( 'No usage recorded yet.', 'coordinator-core' ); ?></em>
					<br><span style="color:<?php echo esc_attr( $state_color ); ?>;font-weight:600"><?php echo esc_html( $state_label ); ?></span>
				</div>
			<?php endif; ?>

			<?php if ( $configured ) : ?>
				<div class="cc-provider-actions">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="coordinator_delete_provider">
						<input type="hidden" name="provider_id" value="<?php echo esc_attr( $provider['id'] ); ?>">
						<?php wp_nonce_field( 'coordinator_delete_provider' ); ?>
						<button class="button" type="submit" onclick="return confirm('<?php echo esc_js( sprintf( /* translators: provider name */ __( 'Remove %s?', 'coordinator-core' ), $provider['name'] ) ); ?>')"><?php echo esc_html__( 'Remove', 'coordinator-core' ); ?></button>
					</form>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function get_configured_providers(): array {
		$providers = get_option( self::OPTION, array() );
		return is_array( $providers ) ? $providers : array();
	}

	private static function get_usage(): array {
		$usage = get_option( self::USAGE_OPTION, array() );
		return is_array( $usage ) ? $usage : array();
	}

	private static function get_catalog(): array {
		// Try reading from the repository file first, then fall back to a built-in default.
		$path = COORDINATOR_CORE_DIR . '../../shared-rules/schemas/provider-catalog.json';
		if ( file_exists( $path ) ) {
			$contents = file_get_contents( $path );
			$decoded = json_decode( $contents, true );
			if ( is_array( $decoded ) && isset( $decoded['providers'] ) ) {
				return $decoded;
			}
		}

		// Built-in fallback with the top free providers.
		return array(
			'schema_version' => '1.0.0',
			'updated_at' => '2026-09-23',
			'providers' => array(
				array(
					'id' => 'google-gemini',
					'name' => 'Google Gemini',
					'description' => "Google's Gemini API with a generous free tier.",
					'api_base' => 'https://generativelanguage.googleapis.com/v1beta',
					'auth_type' => 'api_key',
					'auth_header' => 'x-goog-api-key',
					'auth_prefix' => '',
					'compatibility' => 'google',
					'signup_url' => 'https://aistudio.google.com/apikey',
					'docs_url' => 'https://ai.google.dev/gemini-api/docs',
					'free_tier' => array( 'available' => true, 'rate_limit_rpm' => 10, 'rate_limit_rpd' => 1500, 'credit_card_required' => false, 'notes' => 'Gemini 3 Flash free tier.' ),
					'paid_tiers' => array(),
					'models' => array( array( 'id' => 'gemini-3-flash', 'context' => 1000000, 'strengths' => array( 'summarize', 'draft', 'review' ) ) ),
					'task_fit' => array( 'summarize' => 85, 'classify' => 80, 'draft' => 90, 'review' => 88 ),
					'recommended' => true,
					'recommended_order' => 1,
				),
				array(
					'id' => 'groq',
					'name' => 'Groq',
					'description' => 'Ultra-fast LLM inference with open-source models.',
					'api_base' => 'https://api.groq.com/openai/v1',
					'auth_type' => 'api_key',
					'auth_header' => 'Authorization',
					'auth_prefix' => 'Bearer ',
					'compatibility' => 'openai',
					'signup_url' => 'https://console.groq.com/keys',
					'docs_url' => 'https://console.groq.com/docs',
					'free_tier' => array( 'available' => true, 'rate_limit_rpm' => 30, 'rate_limit_rpd' => 14400, 'credit_card_required' => false, 'notes' => 'Free, gated by rate limits.' ),
					'paid_tiers' => array(),
					'models' => array( array( 'id' => 'llama-4-scout-17b-16e-instruct', 'context' => 131072, 'strengths' => array( 'summarize', 'classify', 'draft' ) ) ),
					'task_fit' => array( 'summarize' => 82, 'classify' => 85, 'draft' => 80, 'review' => 78 ),
					'recommended' => true,
					'recommended_order' => 2,
				),
			),
		);
	}

	private static function remaining_quota( array $provider, array $usage ): array {
		$u = $usage[ $provider['id'] ] ?? array();
		$ft = $provider['free_tier'] ?? array();
		$today = gmdate( 'Y-m-d' );

		$today_requests = (int) ( $u['daily'][ $today ]['requests'] ?? 0 );

		// Check daily request limit
		$rpd = (int) ( $ft['rate_limit_rpd'] ?? 0 );
		if ( $rpd > 0 && $today_requests >= $rpd ) {
			return array( 'available' => false, 'reason' => 'Daily request limit reached' );
		}

		// Check monthly call limit (Cohere)
		$month = gmdate( 'Y-m' );
		$month_requests = (int) ( $u['monthly'][ $month ]['requests'] ?? 0 );
		$cpm = (int) ( $ft['calls_per_month'] ?? 0 );
		if ( $cpm > 0 && $month_requests >= $cpm ) {
			return array( 'available' => false, 'reason' => 'Monthly call limit reached' );
		}

		// Check daily token limit
		$tpd = (int) ( $ft['tokens_per_day'] ?? 0 );
		$today_tokens = (int) ( $u['daily'][ $today ]['tokens'] ?? 0 );
		if ( $tpd > 0 && $today_tokens >= $tpd ) {
			return array( 'available' => false, 'reason' => 'Daily token limit reached' );
		}

		$remaining_requests = $rpd > 0 ? max( 0, $rpd - $today_requests ) : null;
		$remaining_tokens = $tpd > 0 ? max( 0, $tpd - $today_tokens ) : null;

		return array(
			'available' => true,
			'remaining_requests' => $remaining_requests,
			'remaining_tokens' => $remaining_tokens,
			'used_today_requests' => $today_requests,
			'used_today_tokens' => $today_tokens,
		);
	}

	/**
	 * Quota state labels and their scoring factors.
	 * fresh: plenty of quota, full priority
	 * degrading: approaching soft limit, deprioritized
	 * critical: nearly exhausted, last resort only
	 */
	const QUOTA_STATE_FRESH = 'fresh';
	const QUOTA_STATE_DEGRADING = 'degrading';
	const QUOTA_STATE_CRITICAL = 'critical';
	const QUOTA_STATE_FACTORS = array(
		'fresh'     => 1.00,
		'degrading' => 0.65,
		'critical'  => 0.30,
	);

	/**
	 * Determine the quota state: fresh, degrading, or critical.
	 * Uses percentage of daily quota consumed.
	 */
	private static function quota_state( array $remaining ): string {
		$used_pct = self::usage_percentage( $remaining );
		if ( $used_pct >= 95 ) {
			return self::QUOTA_STATE_CRITICAL;
		}
		if ( $used_pct >= self::SOFT_LIMIT_PCT ) {
			return self::QUOTA_STATE_DEGRADING;
		}
		return self::QUOTA_STATE_FRESH;
	}

	/**
	 * Calculate what percentage of quota has been used today.
	 */
	private static function usage_percentage( array $remaining ): float {
		$used_requests = (float) ( $remaining['used_today_requests'] ?? 0 );
		$remaining_requests = $remaining['remaining_requests'] ?? null;
		$used_tokens = (float) ( $remaining['used_today_tokens'] ?? 0 );
		$remaining_tokens = $remaining['remaining_tokens'] ?? null;

		$pct_requests = 0.0;
		$pct_tokens = 0.0;

		if ( null !== $remaining_requests ) {
			$total = $used_requests + $remaining_requests;
			if ( $total > 0 ) {
				$pct_requests = ( $used_requests / $total ) * 100;
			}
		}

		if ( null !== $remaining_tokens ) {
			$total = $used_tokens + $remaining_tokens;
			if ( $total > 0 ) {
				$pct_tokens = ( $used_tokens / $total ) * 100;
			}
		}

		// Use whichever is higher — the most constrained resource drives the state
		return max( $pct_requests, $pct_tokens );
	}

	private static function availability_factor( array $remaining ): float {
		if ( ! $remaining['available'] ) {
			return 0.0;
		}

		$used_pct = self::usage_percentage( $remaining );
		// Fresh (0-60% used): factor 1.0
		// Mid (60-80% used): factor degrades gradually from 1.0 to 0.7
		// Degrading (80-95% used): factor 0.65 → 0.35
		// Critical (95-100% used): factor 0.30 → 0.05

		if ( $used_pct < 60 ) {
			return 1.0;
		} elseif ( $used_pct < 80 ) {
			// Linear from 1.0 at 60% to 0.7 at 80%
			return 1.0 - ( ( $used_pct - 60 ) / 20 ) * 0.30;
		} elseif ( $used_pct < 95 ) {
			// Linear from 0.65 at 80% to 0.35 at 95%
			return 0.65 - ( ( $used_pct - 80 ) / 15 ) * 0.30;
		} else {
			// Near zero at 100%
			return max( 0.05, 0.30 - ( ( $used_pct - 95 ) / 5 ) * 0.25 );
		}
	}

	/**
	 * Get the task-fit score for a specific model on a specific provider.
	 * Falls back to the provider-level score if model-level isn't available.
	 */
	private static function model_task_fit( array $provider, string $model_id, string $task_type ): float {
		$models = $provider['models'] ?? array();

		// Look for model-specific scoring
		foreach ( $models as $model ) {
			if ( $model['id'] === $model_id ) {
				// If the model lists this task as a strength, it's well-suited
				if ( is_array( $model['strengths'] ) && in_array( $task_type, $model['strengths'], true ) ) {
					// Check if there's a provider-level task_fit to modulate with
					$provider_fit = (float) ( $provider['task_fit'][ $task_type ] ?? 85 );
					// Model is specifically strong for this task — use provider score
					return $provider_fit;
				}
				// Model exists but doesn't list this task as a strength — moderate fit
				$provider_fit = (float) ( $provider['task_fit'][ $task_type ] ?? 50 );
				return $provider_fit * 0.65; // Not its specialty
			}
		}

		// Model not found — use provider-level score
		return (float) ( $provider['task_fit'][ $task_type ] ?? 50 );
	}

	/**
	 * Check if a model is paid-only on this provider.
	 */
	private static function model_is_paid_only( array $provider, string $model_id ): bool {
		foreach ( $provider['models'] ?? array() as $model ) {
			if ( $model['id'] === $model_id ) {
				return ! empty( $model['paid_only'] );
			}
		}
		return false;
	}

	/**
	 * Calculate reliability factor based on historical success rate.
	 * Providers with a track record of success on a task get a bonus.
	 * New providers start neutral.
	 */
	private static function reliability_factor( string $provider_id, string $task_type, array $usage ): float {
		$u = $usage[ $provider_id ] ?? array();
		$task_stats = $u['by_task'][ $task_type ] ?? array();
		$requests = (int) ( $task_stats['requests'] ?? 0 );
		$successes = (int) ( $task_stats['success'] ?? 0 );

		if ( $requests < 3 ) {
			return 1.0; // Not enough data — neutral
		}

		$rate = $successes / $requests;
		// Scale: 100% success → 1.10, 80% success → 1.0, 60% → 0.85, 40% → 0.60
		if ( $rate >= 0.90 ) {
			return 1.10;
		} elseif ( $rate >= 0.80 ) {
			return 1.0;
		} elseif ( $rate >= 0.70 ) {
			return 0.90;
		} elseif ( $rate >= 0.60 ) {
			return 0.80;
		} elseif ( $rate >= 0.50 ) {
			return 0.65;
		}
		return 0.50; // Poor track record
	}

	private static function best_model_for_task( array $provider, string $task_type ): string {
		$models = $provider['models'] ?? array();
		if ( empty( $models ) ) {
			return '';
		}

		$best = $models[0]['id'] ?? '';
		$best_score = -1;

		foreach ( $models as $model ) {
			// Skip paid-only models when the provider has a free tier
			if ( ! empty( $model['paid_only'] ) && $provider['free_tier']['available'] ) {
				continue;
			}

			// Score this model for the task
			$fit = 50;
			if ( is_array( $model['strengths'] ) && in_array( $task_type, $model['strengths'], true ) ) {
				// Model is specifically strong for this task — high score
				$fit = 90;
				// Further refine using the provider's task_fit score
				$provider_fit = (float) ( $provider['task_fit'][ $task_type ] ?? 85 );
				$fit = max( $fit, $provider_fit );
			} else {
				// Model doesn't list this task as a strength — use provider score at a discount
				$provider_fit = (float) ( $provider['task_fit'][ $task_type ] ?? 50 );
				$fit = $provider_fit * 0.65;
			}

			if ( $fit > $best_score ) {
				$best_score = $fit;
				$best = $model['id'];
			}
		}

		return $best;
	}

	private static function encrypt_secret( string $secret ) {
		if ( ! function_exists( 'sodium_crypto_secretbox' ) ) {
			return new WP_Error( 'encryption_unavailable', 'Secure encryption is unavailable on this server.' );
		}
		$nonce      = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		$ciphertext = sodium_crypto_secretbox( $secret, $nonce, self::encryption_key() );
		return array(
			'nonce'      => base64_encode( $nonce ),
			'ciphertext' => base64_encode( $ciphertext ),
		);
	}

	public static function decrypt_secret( array $provider ): string {
		if ( ! function_exists( 'sodium_crypto_secretbox_open' ) ) {
			return '';
		}
		$nonce      = base64_decode( (string) ( $provider['key_nonce'] ?? '' ), true );
		$ciphertext = base64_decode( (string) ( $provider['key_ciphertext'] ?? '' ), true );
		if ( false === $nonce || false === $ciphertext || SODIUM_CRYPTO_SECRETBOX_NONCEBYTES !== strlen( $nonce ) ) {
			return '';
		}
		$secret = sodium_crypto_secretbox_open( $ciphertext, $nonce, self::encryption_key() );
		return false === $secret ? '' : $secret;
	}

	private static function encryption_key(): string {
		return hash( 'sha256', wp_salt( 'auth' ) . '|' . wp_salt( 'secure_auth' ), true );
	}
}
