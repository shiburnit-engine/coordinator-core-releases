<?php
/**
 * Approval-controlled image upload for one nonpublic WordPress draft.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Media_Uploader {
	private const AUDIT_OPTION        = 'coordinator_core_media_upload_audit_v1';
	private const HASH_META_KEY       = '_coordinator_core_media_sha256';
	private const TARGET_META_KEY     = '_coordinator_core_media_target_post';
	private const AUDIT_KEY_META_KEY = '_coordinator_core_media_audit_key';
	private const MAX_AUDIT_RECEIPTS = 100;
	private const MAX_FILE_BYTES     = 5242880;
	private const MAX_ALT_BYTES      = 2000;
	private const MAX_FILENAME_BYTES = 240;
	private const ALLOWED_STATUSES   = array( 'draft', 'pending', 'private' );
	private const ALLOWED_MIMES      = array(
		'image/jpeg' => 'jpg',
		'image/png'  => 'png',
		'image/webp' => 'webp',
		'image/gif'  => 'gif',
	);

	public static function upload_image( array $arguments, int $actor_id ) {
		if ( true !== ( $arguments['confirmed'] ?? false ) ) {
			return new WP_Error( 'coordinator_media_not_confirmed', 'Explicit confirmation is required.' );
		}
		if ( $actor_id < 1 || ! user_can( $actor_id, 'manage_options' ) ) {
			return new WP_Error( 'coordinator_invalid_media_actor', 'A valid administrator is required.' );
		}

		$idempotency_key = (string) ( $arguments['idempotency_key'] ?? '' );
		if ( 1 !== preg_match( '/^[A-Za-z0-9._:-]{16,128}$/', $idempotency_key ) ) {
			return new WP_Error( 'coordinator_invalid_idempotency_key', 'idempotency_key must contain 16 to 128 safe characters.' );
		}

		$post_id = absint( $arguments['post_id'] ?? 0 );
		$post    = get_post( $post_id );
		if ( ! is_object( $post ) || ! in_array( (string) ( $post->post_type ?? '' ), array( 'page', 'post' ), true ) ) {
			return new WP_Error( 'coordinator_invalid_media_target', 'The target must be an existing page or post.' );
		}
		if ( ! in_array( (string) ( $post->post_status ?? '' ), self::ALLOWED_STATUSES, true ) ) {
			return new WP_Error( 'coordinator_public_media_target', 'Media uploads are limited to draft, pending, or private content.' );
		}

		$filename = sanitize_file_name( (string) ( $arguments['filename'] ?? '' ) );
		$mime     = strtolower( trim( (string) ( $arguments['mime_type'] ?? '' ) ) );
		$alt_text = trim( (string) ( $arguments['alt_text'] ?? '' ) );
		$source_url = esc_url_raw( (string) ( $arguments['source_url'] ?? '' ) );
		if ( '' === $filename || strlen( $filename ) > self::MAX_FILENAME_BYTES || str_contains( $filename, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_media_filename', 'A safe filename of at most 240 bytes is required.' );
		}
		if ( ! isset( self::ALLOWED_MIMES[ $mime ] ) ) {
			return new WP_Error( 'coordinator_invalid_media_mime', 'Only JPEG, PNG, WebP, and GIF images are allowed.' );
		}
		if ( '' === $alt_text || strlen( $alt_text ) > self::MAX_ALT_BYTES || str_contains( $alt_text, "\0" ) ) {
			return new WP_Error( 'coordinator_invalid_media_alt_text', 'Non-empty alt text of at most 2000 bytes is required.' );
		}
		if ( '' === $source_url || strlen( $source_url ) > 2048 || 'https' !== strtolower( (string) wp_parse_url( $source_url, PHP_URL_SCHEME ) ) || ! wp_http_validate_url( $source_url ) ) {
			return new WP_Error( 'coordinator_invalid_media_source', 'A safe HTTPS image URL is required.' );
		}
		$response = wp_safe_remote_get(
			$source_url,
			array(
				'timeout'             => 20,
				'redirection'         => 3,
				'limit_response_size' => self::MAX_FILE_BYTES + 1,
				'user-agent'          => 'Coordinator-Core/' . COORDINATOR_CORE_VERSION,
			)
		);
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'coordinator_media_download_failed', 'WordPress could not safely download the approved image.' );
		}
		$bytes = wp_remote_retrieve_body( $response );
		if ( ! is_string( $bytes ) || '' === $bytes || strlen( $bytes ) > self::MAX_FILE_BYTES ) {
			return new WP_Error( 'coordinator_invalid_media_data', 'The downloaded image is empty or exceeds the 5 MiB limit.' );
		}

		$detected = self::detect_mime( $bytes );
		if ( ! is_string( $detected ) || ! hash_equals( $mime, $detected ) ) {
			return new WP_Error( 'coordinator_media_type_mismatch', 'The declared MIME type does not match the uploaded image bytes.' );
		}
		$expected_extension = self::ALLOWED_MIMES[ $mime ];
		$actual_extension   = strtolower( (string) pathinfo( $filename, PATHINFO_EXTENSION ) );
		if ( 'jpeg' === $actual_extension ) {
			$actual_extension = 'jpg';
		}
		if ( ! hash_equals( $expected_extension, $actual_extension ) ) {
			return new WP_Error( 'coordinator_media_extension_mismatch', 'The filename extension does not match the verified image type.' );
		}

		$file_hash = hash( 'sha256', $bytes );
		$request   = array(
			'post_id'     => $post_id,
			'filename'    => $filename,
			'mime_type'   => $mime,
			'alt_text'    => $alt_text,
			'file_sha256' => $file_hash,
			'file_bytes'  => strlen( $bytes ),
		);
		$request_fingerprint = hash( 'sha256', wp_json_encode( $request, JSON_UNESCAPED_SLASHES ) );
		$audit_key           = hash_hmac( 'sha256', $idempotency_key, wp_salt( 'auth' ) );
		$audit               = get_option( self::AUDIT_OPTION, array() );
		$audit               = is_array( $audit ) ? $audit : array();

		if ( isset( $audit[ $audit_key ] ) ) {
			$stored = $audit[ $audit_key ];
			if ( ! is_array( $stored ) || ! hash_equals( (string) ( $stored['request_fingerprint'] ?? '' ), $request_fingerprint ) ) {
				return new WP_Error( 'coordinator_media_idempotency_conflict', 'The idempotency key was already used for a different media request.' );
			}
			return self::verified_response( (int) ( $stored['attachment_id'] ?? 0 ), $request, $actor_id, $audit_key, true, false );
		}

		$duplicates = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_parent'    => $post_id,
				'posts_per_page' => 2,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array(
					array( 'key' => self::HASH_META_KEY, 'value' => $file_hash ),
					array( 'key' => self::TARGET_META_KEY, 'value' => (string) $post_id ),
				),
			)
		);
		$duplicates = is_array( $duplicates ) ? array_values( array_map( 'intval', $duplicates ) ) : array();
		if ( array() !== $duplicates ) {
			$existing_id = $duplicates[0];
			if ( 1 === count( $duplicates ) && hash_equals( $audit_key, (string) get_post_meta( $existing_id, self::AUDIT_KEY_META_KEY, true ) ) ) {
				$response = self::verified_response( $existing_id, $request, $actor_id, $audit_key, true, true );
				if ( ! is_wp_error( $response ) ) {
					self::store_audit( $audit, $audit_key, $request_fingerprint, $existing_id );
				}
				return $response;
			}
			return new WP_Error( 'coordinator_duplicate_media', 'This exact image is already attached to the selected draft.', array( 'existing_attachment_id' => $existing_id ) );
		}

		$upload = wp_upload_bits( $filename, null, $bytes );
		if ( ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['file'] ) || empty( $upload['url'] ) ) {
			return new WP_Error( 'coordinator_media_upload_failed', 'WordPress could not store the approved image.' );
		}

		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $mime,
				'post_title'     => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
				'post_content'   => '',
				'post_status'    => 'inherit',
				'post_author'    => $actor_id,
				'post_parent'    => $post_id,
			),
			$upload['file'],
			$post_id,
			true
		);
		if ( is_wp_error( $attachment_id ) || ! is_int( $attachment_id ) || $attachment_id < 1 ) {
			wp_delete_file( $upload['file'] );
			return new WP_Error( 'coordinator_media_attachment_failed', 'WordPress could not create the media attachment.' );
		}

		update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt_text );
		update_post_meta( $attachment_id, self::HASH_META_KEY, $file_hash );
		update_post_meta( $attachment_id, self::TARGET_META_KEY, (string) $post_id );
		update_post_meta( $attachment_id, self::AUDIT_KEY_META_KEY, $audit_key );
		if ( function_exists( 'wp_generate_attachment_metadata' ) ) {
			$metadata = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
			if ( is_array( $metadata ) ) {
				wp_update_attachment_metadata( $attachment_id, $metadata );
			}
		}

		$response = self::verified_response( $attachment_id, $request, $actor_id, $audit_key, false, false );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		self::store_audit( $audit, $audit_key, $request_fingerprint, $attachment_id );
		return $response;
	}

	private static function detect_mime( string $bytes ): ?string {
		if ( str_starts_with( $bytes, "\xFF\xD8\xFF" ) ) {
			return 'image/jpeg';
		}
		if ( str_starts_with( $bytes, "\x89PNG\x0D\x0A\x1A\x0A" ) ) {
			return 'image/png';
		}
		if ( str_starts_with( $bytes, 'GIF87a' ) || str_starts_with( $bytes, 'GIF89a' ) ) {
			return 'image/gif';
		}
		if ( strlen( $bytes ) >= 12 && 'RIFF' === substr( $bytes, 0, 4 ) && 'WEBP' === substr( $bytes, 8, 4 ) ) {
			return 'image/webp';
		}
		return null;
	}

	private static function verified_response( int $attachment_id, array $request, int $actor_id, string $audit_key, bool $idempotent_replay, bool $recovered_after_interruption ) {
		$attachment = get_post( $attachment_id );
		if ( ! is_object( $attachment ) || 'attachment' !== (string) ( $attachment->post_type ?? '' ) ) {
			return new WP_Error( 'coordinator_media_readback_failed', 'The uploaded attachment could not be read back.' );
		}
		$actual = array(
			'post_parent' => (int) ( $attachment->post_parent ?? 0 ),
			'mime_type'   => (string) ( $attachment->post_mime_type ?? '' ),
			'alt_text'    => (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
			'file_sha256' => (string) get_post_meta( $attachment_id, self::HASH_META_KEY, true ),
		);
		if ( $actual['post_parent'] !== $request['post_id'] || ! hash_equals( $request['mime_type'], $actual['mime_type'] ) || ! hash_equals( $request['alt_text'], $actual['alt_text'] ) || ! hash_equals( $request['file_sha256'], $actual['file_sha256'] ) ) {
			return new WP_Error( 'coordinator_media_verification_failed', 'The uploaded attachment did not match the approved request.' );
		}
		$url = wp_get_attachment_url( $attachment_id );
		if ( ! is_string( $url ) || '' === $url ) {
			return new WP_Error( 'coordinator_media_url_failed', 'The uploaded attachment URL could not be verified.' );
		}
		return array(
			'status'                       => 'uploaded',
			'attachment_id'                => $attachment_id,
			'target_post_id'               => $request['post_id'],
			'mime_type'                    => $request['mime_type'],
			'file_bytes'                   => $request['file_bytes'],
			'file_sha256'                  => $request['file_sha256'],
			'alt_text_sha256'              => hash( 'sha256', $request['alt_text'] ),
			'attachment_url'               => esc_url_raw( $url ),
			'receipt_id'                   => 'ccm_' . substr( hash( 'sha256', $audit_key . '|' . $attachment_id . '|' . $request['file_sha256'] ), 0, 24 ),
			'actor_id'                     => $actor_id,
			'uploaded_at_utc'              => gmdate( 'c' ),
			'idempotent_replay'             => $idempotent_replay,
			'recovered_after_interruption' => $recovered_after_interruption,
			'write_performed'               => ! $idempotent_replay,
			'published'                     => false,
			'existing_content_changed'      => false,
		);
	}

	private static function store_audit( array $audit, string $audit_key, string $fingerprint, int $attachment_id ): void {
		$audit[ $audit_key ] = array( 'request_fingerprint' => $fingerprint, 'attachment_id' => $attachment_id );
		if ( count( $audit ) > self::MAX_AUDIT_RECEIPTS ) {
			$audit = array_slice( $audit, -self::MAX_AUDIT_RECEIPTS, null, true );
		}
		update_option( self::AUDIT_OPTION, $audit, false );
	}
}
