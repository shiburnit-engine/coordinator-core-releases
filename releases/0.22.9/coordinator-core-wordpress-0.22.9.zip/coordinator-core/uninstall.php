<?php
/**
 * Coordinator Core uninstall safety.
 *
 * The plugin may store project-neutral operational state. Nothing is deleted automatically.
 * A later removal screen must require an explicit owner choice before deleting
 * or exporting project records.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
