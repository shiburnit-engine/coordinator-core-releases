<?php
/**
 * Read-only verified Knowledge Base search for supervisor diagnosis.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Knowledge_Search {
	private const MAX_RESULTS = 5;

	public static function search_verified( string $problem, string $component = '' ): array {
		$root = dirname( COORDINATOR_CORE_DIR, 2 ) . '/knowledge-base/';
		$index_path = $root . 'index.json';
		if ( ! is_readable( $index_path ) ) {
			return array();
		}
		$index = json_decode( (string) file_get_contents( $index_path ), true );
		if ( ! is_array( $index ) ) {
			return array();
		}
		$problem_tokens = self::tokens( $problem );
		$component_tokens = self::tokens( $component );
		$matches = array();
		foreach ( (array) ( $index['lessons'] ?? array() ) as $item ) {
			$relative = is_array( $item ) ? (string) ( $item['path'] ?? '' ) : '';
			if ( '' === $relative || 0 !== strpos( $relative, 'knowledge-base/' ) || false !== strpos( $relative, '..' ) ) {
				continue;
			}
			$path = dirname( COORDINATOR_CORE_DIR, 2 ) . '/' . $relative;
			if ( ! is_readable( $path ) ) {
				continue;
			}
			$lesson = json_decode( (string) file_get_contents( $path ), true );
			if ( ! self::verified_safe_lesson( $lesson ) ) {
				continue;
			}
			$haystack = implode( ' ', array(
				(string) ( $lesson['title'] ?? '' ),
				(string) ( $lesson['category'] ?? '' ),
				(string) ( $lesson['component'] ?? '' ),
				(string) ( $lesson['problem_signature'] ?? '' ),
				implode( ' ', (array) ( $lesson['tags'] ?? array() ) ),
			) );
			$score = self::score( $problem_tokens, self::tokens( $haystack ) );
			$score += 2 * self::score( $component_tokens, self::tokens( (string) ( $lesson['component'] ?? '' ) ) );
			if ( $score < 1 ) {
				continue;
			}
			$matches[] = array(
				'lesson_id' => (string) $lesson['lesson_id'],
				'title' => (string) $lesson['title'],
				'problem_signature' => (string) $lesson['problem_signature'],
				'cause' => (string) $lesson['cause'],
				'correction_steps' => (array) $lesson['correction_steps'],
				'verification_steps' => (array) $lesson['verification_steps'],
				'confidence' => (string) $lesson['confidence'],
				'score' => $score,
			);
		}
		usort( $matches, static function ( array $a, array $b ): int {
			return ( $b['score'] <=> $a['score'] ) ?: strcmp( $a['lesson_id'], $b['lesson_id'] );
		} );
		return array_slice( $matches, 0, self::MAX_RESULTS );
	}

	private static function verified_safe_lesson( $lesson ): bool {
		return is_array( $lesson )
			&& 'Verified' === (string) ( $lesson['status'] ?? '' )
			&& true === ( $lesson['privacy_reviewed'] ?? false )
			&& true === ( $lesson['project_neutral'] ?? false )
			&& '' !== (string) ( $lesson['lesson_id'] ?? '' );
	}

	private static function tokens( string $value ): array {
		$value = strtolower( preg_replace( '/[^a-z0-9]+/', ' ', $value ) ?? '' );
		$tokens = array_filter( preg_split( '/\s+/', trim( $value ) ) ?: array(), static function ( string $token ): bool {
			return strlen( $token ) >= 4;
		} );
		return array_values( array_unique( $tokens ) );
	}

	private static function score( array $needles, array $haystack ): int {
		return count( array_intersect( $needles, $haystack ) );
	}
}
