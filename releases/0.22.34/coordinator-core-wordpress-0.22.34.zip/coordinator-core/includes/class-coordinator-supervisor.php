<?php
/**
 * Deterministic supervisor decisions for autonomous Coordinator work.
 *
 * AI workers do not control these transitions.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Supervisor {
	public const MODE_EXECUTING = 'executing';
	public const MODE_DIAGNOSING = 'diagnosing';
	public const MODE_RESEARCHING = 'researching';
	public const MODE_REPAIR_AUTHORIZED = 'repair_authorized';

	public static function failure_record( array $job, string $category, string $message, array $evidence = array() ): array {
		$attempts = is_array( $job['supervisor_attempts'] ?? null ) ? $job['supervisor_attempts'] : array();
		$previous = ! empty( $attempts ) && is_array( end( $attempts ) ) ? end( $attempts ) : array();
		$current = array(
			'at' => gmdate( 'c' ),
			'category' => self::clean( $category ),
			'message' => self::clean( $message ),
			'commit_sha' => self::clean( $evidence['commit_sha'] ?? '' ),
			'stage' => self::clean( $job['stage'] ?? '' ),
			'checkpoint' => self::clean( $evidence['checkpoint'] ?? '' ),
			'accepted_changes' => ! empty( $evidence['accepted_changes'] ),
			'result' => 'failed',
		);
		$current['progress'] = self::progress_result( $previous, $current );
		$attempts[] = $current;
		return array_slice( $attempts, -20 );
	}

	public static function progress_result( array $previous, array $current ): string {
		if ( empty( $previous ) ) {
			return 'unknown';
		}
		$same_commit = '' !== self::clean( $current['commit_sha'] ?? '' )
			&& self::clean( $current['commit_sha'] ?? '' ) === self::clean( $previous['commit_sha'] ?? '' );
		$same_stage = self::clean( $current['stage'] ?? '' ) === self::clean( $previous['stage'] ?? '' );
		$same_checkpoint = self::clean( $current['checkpoint'] ?? '' ) === self::clean( $previous['checkpoint'] ?? '' );
		$no_changes = empty( $current['accepted_changes'] );
		return ( $same_stage && $same_checkpoint && $no_changes && ( $same_commit || '' === self::clean( $current['commit_sha'] ?? '' ) ) )
			? 'no_progress'
			: 'progress';
	}

	public static function failure_mode( array $attempts ): string {
		if ( empty( $attempts ) ) {
			return self::MODE_DIAGNOSING;
		}
		$latest = end( $attempts );
		return is_array( $latest ) && 'no_progress' === self::clean( $latest['progress'] ?? '' )
			? self::MODE_DIAGNOSING
			: self::MODE_DIAGNOSING;
	}

	public static function diagnosis_decision( array $job ): array {
		$matches = is_array( $job['supervisor_memory_matches'] ?? null ) ? $job['supervisor_memory_matches'] : array();
		foreach ( $matches as $match ) {
			if ( ! is_array( $match ) ) {
				continue;
			}
			$lesson_id = self::clean( $match['lesson_id'] ?? '' );
			$score = (int) ( $match['score'] ?? 0 );
			$correction_steps = $match['correction_steps'] ?? array();
			$verification_steps = $match['verification_steps'] ?? array();
			$has_correction = is_array( $correction_steps ) ? ! empty( $correction_steps ) : '' !== self::clean( $correction_steps );
			$has_verification = is_array( $verification_steps ) ? ! empty( $verification_steps ) : '' !== self::clean( $verification_steps );
			if ( '' !== $lesson_id && $score >= 3 && $has_correction && $has_verification ) {
				return array(
					'mode' => self::MODE_REPAIR_AUTHORIZED,
					'verified_lesson_id' => $lesson_id,
					'reason' => 'verified_lesson',
				);
			}
		}

		return array(
			'mode' => self::MODE_RESEARCHING,
			'verified_lesson_id' => '',
			'reason' => 'verified_knowledge_insufficient',
		);
	}

	public static function apply_diagnosis_decision( array &$job ): array {
		$decision = self::diagnosis_decision( $job );
		if ( self::MODE_REPAIR_AUTHORIZED === $decision['mode'] ) {
			self::authorize_repair( $job, '', $decision['verified_lesson_id'] );
		} else {
			$job['supervisor_mode'] = self::MODE_RESEARCHING;
			$job['supervisor_verified_lesson_id'] = '';
		}
		return $decision;
	}

	public static function can_execute_repair( array $job ): bool {
		if ( self::MODE_REPAIR_AUTHORIZED !== self::clean( $job['supervisor_mode'] ?? '' ) ) {
			return false;
		}
		$hypothesis = self::clean( $job['supervisor_hypothesis'] ?? '' );
		$lesson_id = self::clean( $job['supervisor_verified_lesson_id'] ?? '' );
		return '' !== $hypothesis || '' !== $lesson_id;
	}

	public static function authorize_repair( array &$job, string $hypothesis = '', string $verified_lesson_id = '' ): bool {
		$hypothesis = self::clean( $hypothesis );
		$verified_lesson_id = self::clean( $verified_lesson_id );
		if ( '' === $hypothesis && '' === $verified_lesson_id ) {
			return false;
		}
		$job['supervisor_hypothesis'] = $hypothesis;
		$job['supervisor_verified_lesson_id'] = $verified_lesson_id;
		$job['supervisor_mode'] = self::MODE_REPAIR_AUTHORIZED;
		return true;
	}

	private static function clean( $value ): string {
		return is_string( $value ) ? trim( $value ) : '';
	}
}
