<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Coordinator_Budget_Authority {
 public const OPTION = 'coordinator_core_budget_authority_v1';

 public static function state(): array {
  $state=get_option(self::OPTION,array());
  return is_array($state) ? $state : array();
 }

 public static function discover_original_admin_id(): int {
  $users=get_users(array('role'=>'administrator','orderby'=>'ID','order'=>'ASC','number'=>1,'fields'=>'ID'));
  if(!is_array($users) || empty($users)) return 0;
  $user_id=(int)$users[0];
  return $user_id>0 && user_can($user_id,'manage_options') ? $user_id : 0;
 }

 public static function establish_initial_admin(): bool {
  if(self::initial_admin_id()>0) return true;
  $user_id=self::discover_original_admin_id();
  if($user_id<=0) return false;
  return add_option(self::OPTION,array('schema_version'=>2,'initial_admin_user_id'=>$user_id,'budget_manager_user_ids'=>array(),'established_at'=>gmdate('c'),'establishment_method'=>'original_wordpress_administrator'),' ',false);
 }

 public static function initial_admin_id(): int {
  return (int)(self::state()['initial_admin_user_id'] ?? 0);
 }

 public static function is_initial_admin(int $user_id): bool {
  return $user_id>0 && self::initial_admin_id()===$user_id;
 }

 public static function is_budget_manager(int $user_id): bool {
  if(self::is_initial_admin($user_id)) return true;
  return in_array($user_id,array_map('intval',self::state()['budget_manager_user_ids'] ?? array()),true);
 }

 public static function set_budget_manager(int $actor_id,int $target_id,bool $enabled): bool {
  if(!self::is_initial_admin($actor_id) || $target_id<=0 || self::is_initial_admin($target_id) || !user_can($target_id,'manage_options')) return false;
  $state=self::state();
  $ids=array_values(array_unique(array_map('intval',$state['budget_manager_user_ids'] ?? array())));
  $ids=$enabled ? array_values(array_unique(array_merge($ids,array($target_id)))) : array_values(array_diff($ids,array($target_id)));
  $state['budget_manager_user_ids']=$ids;
  $state['updated_at']=gmdate('c');
  $state['updated_by']=$actor_id;
  update_option(self::OPTION,$state,false);
  return true;
 }
}
