# Coordinator Core WordPress Plugin

This folder contains the clean, project-neutral WordPress plugin.

## Foundation behavior

- Version: 0.12.0
- Adds an administrator-only Coordinator page.
- Adds a nonce-protected administrator editor for project-neutral operational state: status, phase, stage, checkpoint progress, current work, blockers, exact next action, and an optional Continue Work link.
- Adds an administrator-only read-only health route at `/wp-json/coordinator-core/v1/health`.
- Adds administrator-only read-only Connector capability, safe site-inventory, and HTTPS-only connection-handshake routes.
- Adds an administrator-only read-only Continue Work status route.
- Uses WordPress native cookie-session or application-password authentication over HTTPS before checking administrator capability.
- Grants only the explicit `coordinator:read` handshake scope and exposes no credential material.
- Implements the OAuth 2.1 authorization-code flow for trusted ChatGPT Client ID Metadata Documents.
- Requires an authenticated WordPress administrator to approve a clear read-only consent screen.
- Requires PKCE S256 and binds each one-time, five-minute authorization code to its client, redirect URI, and MCP resource.
- Issues one-hour bearer tokens, stores only keyed hashes at rest, rechecks the authorizing administrator's permission, and supports revocation.
- Publishes protected-resource and authorization-server metadata over HTTPS with issuer validation enabled.
- Grants OAuth clients only `coordinator:read`; no write scope exists.
- Adds a stateless MCP Streamable HTTP endpoint at `/wp-json/coordinator-core/v1/mcp` with `initialize`, `ping`, `tools/list`, and `tools/call`.
- Exposes authenticated profile, Coordinator status, site inventory, and Continue Work as explicitly read-only MCP tools.
- Preserves the `coordinator_core_continue_work_summary` adapter filter and adds the `coordinator_core_operational_state` filter.
- Performs no content, plugin, theme, file, user, publishing, deployment, or deletion action. The only external action is explicitly confirmed advisory AI delegation through the bounded router.
- Stores operational state separately and, when configured, stores only the router access token encrypted with WordPress salts. The OpenAI provider key remains exclusively in Cloudflare.
- Deletes no project record during uninstall.
- Uses a public distribution-only repository without storing GitHub credentials in WordPress.
- Accepts update metadata only when its Ed25519 signature, Coordinator identity, release URL, and version fields validate.
- Downloads an approved update through WordPress, verifies its SHA-256 checksum against the signed metadata, and blocks installation on any mismatch.
- Relies on WordPress's administrator approval and native update recovery instead of silently installing releases.
- Adds a separate `coordinator:write:operational-state` OAuth scope and two MCP tools limited to previewing and saving validated Coordinator operational state.
- Requires explicit confirmation and the last-known update timestamp before saving, and returns a non-secret audit receipt.
- Does not expose content, publishing, plugin, theme, deployment, file, user, or deletion tools.
- Stores only hashed access and refresh tokens in a non-autoloaded durable WordPress option so cache purges do not disconnect ChatGPT.
- Issues rotating 30-day refresh tokens, retains one-hour access tokens, and revokes the token family when refresh-token reuse is detected.

This foundation must pass its offline tests before any practice installation.

- Adds an administrator-only Bounded AI Router setup panel with browser-generated access tokens encrypted at rest using WordPress salts.
- Adds a separate `coordinator:delegate:ai` OAuth scope and MCP preview/run tools for advisory summarize, classify, draft, and review jobs.
- Requires explicit confirmation for paid AI runs and preserves the router's model allowlist, idempotency, per-job budget, and monthly budget enforcement.
- Never stores the OpenAI API key in WordPress or GitHub; only the Cloudflare router holds that provider key.
