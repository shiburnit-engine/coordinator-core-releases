<?php
/**
 * Authentication boundary for the scoped WordPress Connector.
 *
 * @package CoordinatorCore
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Coordinator_Authentication {
	public const READ_SCOPE = 'coordinator:read';
	public const WRITE_OPERATIONAL_STATE_SCOPE = 'coordinator:write:operational-state';
	public const DELEGATE_AI_SCOPE = 'coordinator:delegate:ai';

	public static function can_read() {
		if ( ! self::is_secure_request() ) {
			return false;
		}

		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}

		return Coordinator_OAuth_Foundation::authenticate_bearer_token();
	}

	public static function can_write_operational_state( $authorization ): bool {
		if ( ! self::is_secure_request() ) {
			return false;
		}
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		if ( ! is_array( $authorization ) || ! user_can( (int) ( $authorization['user_id'] ?? 0 ), 'manage_options' ) ) {
			return false;
		}
		$scopes = preg_split( '/\s+/', trim( (string) ( $authorization['scope'] ?? '' ) ) ) ?: array();
		return in_array( self::WRITE_OPERATIONAL_STATE_SCOPE, $scopes, true );
	}

	public static function can_delegate_ai( $authorization ): bool {
		if ( ! self::is_secure_request() ) {
			return false;
		}
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		if ( ! is_array( $authorization ) || ! user_can( (int) ( $authorization['user_id'] ?? 0 ), 'manage_options' ) ) {
			return false;
		}
		$scopes = preg_split( '/\\s+/', trim( (string) ( $authorization['scope'] ?? '' ) ) ) ?: array();
		return in_array( self::DELEGATE_AI_SCOPE, $scopes, true );
	}

	public static function is_secure_request(): bool {
		return is_ssl();
	}

	public static function handshake_response() {
		$user         = wp_get_current_user();
		$token_record = Coordinator_OAuth_Foundation::authenticate_bearer_token();
		$actor_id     = current_user_can( 'manage_options' ) ? (int) $user->ID : ( is_array( $token_record ) ? (int) $token_record['user_id'] : 0 );

		return rest_ensure_response(
			array(
				'service'                    => 'coordinator-core-connector',
				'version'                    => COORDINATOR_CORE_VERSION,
				'connected'                  => true,
				'authenticated'              => true,
				'authorization_boundary'     => current_user_can( 'manage_options' ) ? 'wordpress-native' : 'oauth-2.1-bearer',
				'accepted_methods'           => array( 'cookie-session', 'application-password', 'oauth-2.1-bearer' ),
				'required_capability'         => 'manage_options',
				'granted_scopes'              => is_array( $token_record ) ? preg_split( '/\s+/', (string) $token_record['scope'] ) : array( self::READ_SCOPE ),
				'transport_security'          => 'https-required',
				'actor'                       => array(
					'id' => $actor_id,
				),
				'mcp_authorization_target'    => 'oauth-2.1-authorization-code-pkce-s256',
				'mcp_oauth_ready'             => true,
				'writes_enabled'              => is_array( $token_record ) && self::can_write_operational_state( $token_record ),
				'ai_delegation_enabled'       => is_array( $token_record ) && self::can_delegate_ai( $token_record ),
			)
		);
	}
}
